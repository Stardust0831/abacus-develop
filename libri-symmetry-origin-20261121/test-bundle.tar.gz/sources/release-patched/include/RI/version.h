// ===================
//  Author: Peize Lin
//  date: 2024.09.06
// ===================

#pragma once

#define __LIBRI_VERSION_MAJOR		3
#define __LIBRI_VERSION_MINOR		0
#define __LIBRI_VERSION_PATCH		0

#define __LIBRI_VERSION				(  __LIBRI_VERSION_MAJOR * 10000 \
									 + __LIBRI_VERSION_MINOR * 100 \
									 + __LIBRI_VERSION_PATCH)
