from pathlib import Path
from collections import Counter
import json
import re

root = Path(__file__).resolve().parent
report = {}
for variant in ('abacus', 'debug'):
    entries = json.loads((root / 'build' / variant / 'compile_commands.json').read_text())
    rows = []
    for entry in entries:
        standard = re.findall(r'-std=(?:gnu|c)\+\+(\d+)', entry['command'])
        if '17' in standard:
            rows.append({'file': entry['file'], 'command': entry['command']})
    report[variant] = {'total': len(entries), 'cxx17_entries': rows}
(root / 'logs/standard-investigation.json').write_text(json.dumps(report, indent=2) + '\n')
for name, data in report.items():
    print(name, 'total entries', data['total'], 'C++17 entries', len(data['cxx17_entries']))
    targets = Counter(re.findall(r'CMakeFiles/([^/ ]+)\.dir', entry['command'])[-1]
                      for entry in data['cxx17_entries'])
    print('targets:', dict(targets))
    print('first C++17 file:', data['cxx17_entries'][0]['file'] if data['cxx17_entries'] else None)
