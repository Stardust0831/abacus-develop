from pathlib import Path
import hashlib
import json
import tarfile

root = Path(__file__).resolve().parent
paths = set()
for directory in ('logs', 'runs', 'cli-checks', 'cxx14-regression'):
    paths.update(p for p in (root / directory).rglob('*') if p.is_file() and not p.is_symlink())
for pattern in ('*.py', '*.sbatch', '*.patch', '*.json', 'dependency-*.log', 'application-*.log', 'runtime-*.log'):
    paths.update(root.glob(pattern))
for name in ('ddla-release', 'ddla-tag', 'review-comment'):
    paths.add(root / 'github' / (name + '.json'))
for name in ('ddla', 'ddla-consumer', 'baseline-consumer', 'consumer-cpu', 'consumer-gpu',
             'libri14', 'abacus', 'debug'):
    build = root / 'build' / name
    for relative in ('CMakeCache.txt', 'compile_commands.json', 'CMakeFiles/CMakeConfigureLog.yaml',
                     'Testing/Temporary/LastTest.log', 'installed-target.txt'):
        if (build / relative).is_file():
            paths.add(build / relative)
    if name in ('abacus', 'debug', 'libri14'):
        paths.update(p for p in build.rglob('link.txt') if any(s in str(p) for s in
            ('abacus_std_gpu.dir', 'MODULE_RI_exx_workspace.dir', 'test_lri_gpu_symmetry.dir')))
    if name in ('abacus', 'debug'):
        paths.update((build / 'source/CMakeFiles/abacus_std_gpu.dir').glob('*.rsp'))
paths.update(p for p in (root / 'install/ddla/lib/cmake/LibDDLA').glob('*') if p.is_file())
paths.add(root / 'install/ddla/include/ddla/ddla_config.h')
manifest_path = root / 'logs/evidence-manifest.json'
paths.discard(manifest_path)
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
manifest = {str(p.relative_to(root)): {'size': p.stat().st_size, 'sha256': digest(p)}
            for p in sorted(paths)}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
paths.add(manifest_path)
archive = root / 'ddla007-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for p in sorted(paths):
        tar.add(p, arcname=str(p.relative_to(root)), recursive=False)
summary = {'files': len(paths), 'bytes': archive.stat().st_size, 'sha256': digest(archive)}
(root / 'ddla007-evidence.tar.gz.sha256').write_text(summary['sha256'] + '  ' + archive.name + '\n')
print(json.dumps(summary, indent=2))
