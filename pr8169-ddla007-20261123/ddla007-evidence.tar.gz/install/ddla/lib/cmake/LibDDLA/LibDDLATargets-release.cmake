#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ddla::ddla" for configuration "Release"
set_property(TARGET ddla::ddla APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ddla::ddla PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libddla.so.0.0.7"
  IMPORTED_SONAME_RELEASE "libddla.so.0"
  )

list(APPEND _cmake_import_check_targets ddla::ddla )
list(APPEND _cmake_import_check_files_for_ddla::ddla "${_IMPORT_PREFIX}/lib/libddla.so.0.0.7" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
