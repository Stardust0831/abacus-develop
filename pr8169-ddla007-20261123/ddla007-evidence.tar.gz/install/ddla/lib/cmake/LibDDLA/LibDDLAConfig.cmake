
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was LibDDLAConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# The exported target carries the shared library's actual filename, SONAME,
# include directories, C++ standard and link interface from its build target.
# Public headers use MPI and the generated DDLA_HAS_GPU capability; consumers
# do not need private DDLA_USE_* vendor or communication definitions.
include(CMakeFindDependencyMacro)
find_dependency(MPI COMPONENTS CXX)
if(ON)
    find_dependency(CUDAToolkit)
endif()
if(OFF)
    find_dependency(NCCL)
endif()
include("${CMAKE_CURRENT_LIST_DIR}/LibDDLATargets.cmake")
check_required_components(LibDDLA)
