# ABACUS HSE06 with latest GPU libraries

Use the previous ABACUS source revision, Si64/Si216 structures, APNS data, thresholds, MPI/OpenMP binding, and 16V100 partition. Build an isolated executable against the recorded current upstream LibRI master, LibXC devel and DDLA main. No installed application module is replaced.

Enable actual GPU RI contractions and batch LibXC density-grid evaluation on device. The local experimental CPU switches permit same-binary CPU/GPU comparisons. Validate energy and nonzero forces on displaced Si64 before timing two independent runs per resource group. Compare to the previous CP2K/ABACUS measurements and include any baseline drift or incompatibility.

The timing protocol explicitly requires four OpenMP threads per MPI rank, overriding the repository default of one for generic runtime tests. Only CUDA HSE/PBE paths needed by this experiment will be claimed verified.

## Integration scope

- Experimental executable uses ABACUS commit 4e9f1636b7ca plus the retained patch. Inactive machine-learning features are disabled for this standalone build; all HSE/LCAO numerical settings are retained.
- Environment `SAI_RI_DEVICE=cpu|gpu` selects LibRI contraction mode at initialization; `SAI_LIBXC_DEVICE=cpu|gpu` selects whole-grid LDA/GGA LibXC evaluation. Both default to gpu in the experimental binary. `SAI_GPU_TRACE=1` records backend/device calls for validation only.
- Existing LibXC calls use explicit host initialization; the density-grid potential path alone initializes device handles and transfers arrays. Density preparation, masks, FFT gradients, accumulation, and force formulas remain unchanged.
- New LibXC adapter test compares CPU/device values and derivatives for LDA exchange, PBE exchange, PBE correlation and HSE06, spin 1/2 and 17/1025/8193 points. LibRI upstream GPU symmetry tests run with one rank and 1/4 threads, as required by that upstream test. Multiple ranks are checked by the end-to-end displaced-Si checks.
- First two allocation attempts failed before compilation due module nounset and minimal SIF utility binds. Both fixed. The next completed LibXC build but DDLA expected a different CUDA math-library layout; explicit library locations address it without changing the dependency source.
- Job 2654704 passed all 24 LibXC comparisons (maximum scaled error 5.74348e-14) and both one-rank LibRI symmetry checks. Its extra two-rank invocation was rejected because the upstream test explicitly requires one rank; the build driver now respects this restriction, without changing test assertions.

Before collecting end-to-end results, the same-binary CPU/GPU acceptance limits are fixed at 1e-6 eV/atom for total energy and 1e-5 eV/angstrom for the maximum atomic force-vector difference. All four runs must exit successfully, converge at the unchanged 1e-8 SCF threshold, print 64 forces, and show the requested backend trace. Differences from the old installed module are recorded separately.

A logging-only change to run-case.sh was transferred while the initial timing jobs were running. Bash resumed at the changed file offset after the timed ABACUS command and reported `.log: command not found`; the affected ABACUS commands themselves exited 0, with complete SCF and force output. Their recorded wall times remain usable, and only the remaining independent repetitions are rescheduled. Analysis must record the batch-driver failure separately from the exit code in the `/usr/bin/time` JSON. Future script updates use atomic replacement or wait until active readers finish. No numerical setting or executable changed.
