#!/usr/bin/env python3
"""Apply narrowly scoped integration edits to the recorded ABACUS source."""
from pathlib import Path
import difflib
import json
import tarfile

root=Path(__file__).resolve().parent
src=root/'src/abacus'
changes={}
base_files={'CMakeLists.txt','source/CMakeLists.txt',
            'source/source_lcao/module_ri/exx_lri.hpp'}
base_files.update('source/source_hamilt/module_xc/'+name for name in
                  ['CMakeLists.txt','libxc_abacus.h','libxc_setup.cpp','libxc_pot.cpp'])
with tarfile.open(root/'reference/abacus.tar.gz') as archive:
    for member in archive.getmembers():
        name='/'.join(Path(member.name).parts[1:])
        if name in base_files:
            (src/name).write_bytes(archive.extractfile(member).read())
def replace(name,old,new,count=1):
    p=src/name;s=p.read_text()
    assert s.count(old)==count,(name,s.count(old),old[:80])
    changes.setdefault(name,s)
    p.write_text(s.replace(old,new))

replace('CMakeLists.txt','  find_package(LibRI REQUIRED)',
        '  find_package(LibRI REQUIRED)\n  find_package(LibDDLA 0.0.6 REQUIRED CONFIG)\n  set_if_higher(CMAKE_CXX_STANDARD 17)')
replace('source/CMakeLists.txt','set(_abacus_feature_definitions\n',
        'set(_abacus_feature_definitions\n    __GPU_RI __DDLA_RI DDLA_USE_CUDA\n')
replace('source/CMakeLists.txt','set(_abacus_feature_libs\n',
        'set(_abacus_feature_libs\n    ddla::ddla\n')
replace('source/CMakeLists.txt','        Libxc::xc\n','        Libxc::xc\n        ddla::ddla\n')

xc='source/source_hamilt/module_xc/'
replace(xc+'CMakeLists.txt','  libxc_pot.cpp\n','  libxc_pot.cpp\n  libxc_gpu.cpp\n')
decl='''    extern std::vector<xc_func_type> init_func(
        const std::vector<int> &func_id,
        const int xc_polarized,
        const double hybrid_alpha,
        const double hse_omega);'''
replace(xc+'libxc_abacus.h',decl,decl+'''

    extern std::vector<xc_func_type> init_func(
        const std::vector<int>& func_id,
        int xc_polarized,
        double hybrid_alpha,
        double hse_omega,
        int execution_flags);''')
signature='''XC_Functional_Libxc::init_func(const std::vector<int> &func_id, 
                               const int xc_polarized,
                               const double hybrid_alpha,
                               const double hse_omega)
{'''
replace(xc+'libxc_setup.cpp',signature,signature+'''
    return init_func(func_id, xc_polarized, hybrid_alpha, hse_omega, XC_FLAGS_ON_HOST);
}

std::vector<xc_func_type>
XC_Functional_Libxc::init_func(const std::vector<int>& func_id,
                              int xc_polarized,
                              double hybrid_alpha,
                              double hse_omega,
                              int execution_flags)
{''')
replace(xc+'libxc_setup.cpp','        xc_func_init(&funcs.back(), id, xc_polarized); // instantiate the XC term',
'''        const int status = xc_func_init_flags(&funcs.back(), id, xc_polarized, execution_flags);
        if (status != 0)
        {
            throw std::runtime_error("LibXC functional initialization failed: " + std::to_string(id));
        }''')
replace(xc+'libxc_setup.cpp','#include <algorithm>','#include <algorithm>\n#include <stdexcept>')
replace(xc+'libxc_pot.cpp','#include "libxc_abacus.h"','#include "libxc_abacus.h"\n#include "libxc_gpu.h"\n#include <memory>')
start='''    std::vector<xc_func_type> funcs = XC_Functional_Libxc::init_func(
        /* func_id = */ func_id,
        /* xc_polarized = */ (1 == nspin) ? XC_UNPOLARIZED : XC_POLARIZED,
        /* hybrid_alpha = */ hybrid_alpha,
        /* hse_omega = */ hse_omega);'''
replace(xc+'libxc_pot.cpp',start,'''    const bool gpu_grid = XC_Functional_Libxc::use_gpu_grid();
    const int execution_flags = gpu_grid ? XC_FLAGS_ON_DEVICE : XC_FLAGS_ON_HOST;
    const int polarization = nspin == 1 ? XC_UNPOLARIZED : XC_POLARIZED;
    std::vector<xc_func_type> funcs = XC_Functional_Libxc::init_func(
        func_id, polarization, hybrid_alpha, hse_omega, execution_flags);''')
replace(xc+'libxc_pot.cpp','    double etxc = 0.0;\n    double vtxc = 0.0;\n    ModuleBase::matrix v(use_lca ? 4 : nspin, nrxx);', '''    std::unique_ptr<XC_Functional_Libxc::GpuGrid> device_grid;
    if (gpu_grid)
    {
        device_grid.reset(new XC_Functional_Libxc::GpuGrid(nspin, nrxx, rho, sigma));
    }

    double etxc = 0.0;
    double vtxc = 0.0;
    ModuleBase::matrix v(use_lca ? 4 : nspin, nrxx);''')
replace(xc+'libxc_pot.cpp','''        ModuleBase::timer::start("Libxc", "xc_lda/gga_exc_vxc");
        switch''','''        ModuleBase::timer::start("Libxc", "xc_lda/gga_exc_vxc");
        if (gpu_grid)
        {
            device_grid->evaluate(func, exc, vrho, vsigma);
        }
        else switch''')

exx='source/source_lcao/module_ri/exx_lri.hpp'
replace(exx,'#include <fstream>','#include <fstream>\n#include <cstdlib>\n#include <iostream>')
replace(exx,'    this->mpi_comm = mpi_comm_in;', '''#ifdef __GPU_RI
    const char* requested_backend = std::getenv("SAI_RI_DEVICE");
    const std::string backend = requested_backend == nullptr ? "gpu" : requested_backend;
    if (backend != "gpu" && backend != "cpu")
    {
        throw std::invalid_argument("SAI_RI_DEVICE must be cpu or gpu");
    }
    this->exx_lri.lri.cal_mode = backend == "gpu" ? RI::LRI_Cal_Mode::GPU : RI::LRI_Cal_Mode::CPU;
    if (std::getenv("SAI_GPU_TRACE") != nullptr)
    {
        std::clog << "LIBRI_CONTRACTION_BACKEND " << backend << '\\n';
    }
#endif
    this->mpi_comm = mpi_comm_in;''',count=2)

patch=''
for name,old in changes.items():
    patch+=''.join(difflib.unified_diff(old.splitlines(True),(src/name).read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
for name in [xc+'libxc_gpu.h',xc+'libxc_gpu.cpp',xc+'unittests/test_libxc_gpu.cpp']:
    patch+=''.join(difflib.unified_diff([],(src/name).read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+name))
(root/'abacus-gpu-libs.patch').write_text(patch)
(root/'modified-files.json').write_text(json.dumps(list(changes)+[xc+'libxc_gpu.h',xc+'libxc_gpu.cpp',xc+'unittests/test_libxc_gpu.cpp'],indent=2)+'\n')
print('Patched',len(changes)+3,'files')
