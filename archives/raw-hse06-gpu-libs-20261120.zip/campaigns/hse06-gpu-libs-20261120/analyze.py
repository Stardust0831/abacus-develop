#!/usr/bin/env python3
"""Extract independently auditable timings and scientific completion evidence."""
from pathlib import Path
import csv
import json
import math
import re
import sys

ROOT=Path(__file__).resolve().parent
HA_EV=27.211386245988
BOHR_A=0.529177210903
NUM=r'[-+]?\d+(?:\.\d*)?(?:[EeDd][-+]?\d+)?'

def text(path):
    return path.read_text(errors='replace') if path.exists() else ''

def last(pattern,s,default=None,flags=0):
    hits=re.findall(pattern,s,flags)
    return hits[-1] if hits else default

def cp_timing(s,name):
    v=last(r'^\s*'+re.escape(name)+r'\s+\d+\s+('+NUM+r')\s+('+NUM+r')\s+('+NUM+r')\s+('+NUM+r')\s+('+NUM+r')\s*$',s,flags=re.M)
    return float(v[-1]) if v else None

def ab_timing(s,cls,name):
    v=last(r'^\s*'+re.escape(cls)+r'\s+'+re.escape(name)+r'\s+('+NUM+r')\s+\d+\s+',s,flags=re.M)
    return float(v) if v else None

def elapsed(d,name='time.json'):
    raw=text(d/name)
    if raw:
        try:return json.loads(raw[raw.index('{'):])['wall_s']
        except (ValueError,KeyError):return None
    if name=='time.json':
        v=last(r'Elapsed \(wall clock\) time \(h:mm:ss or m:ss\): (\S+)',text(d/'time.txt'))
        if v:
            parts=list(map(float,v.split(':')))
            return sum(x*60**i for i,x in enumerate(reversed(parts)))
    return None

def parse(d, validate_exitcode=True):
    iscp=(d/'input.inp').exists()
    isab=(d/'INPUT').exists()
    if not(isab or iscp):return None
    s=text(d/'output.log') if iscp else text(d/'OUT.si/running_scf.log')
    stdout=text(d/'launcher.log') if (d/'launcher.log').exists() else text(d/'output.log')
    r={'case':str(d.relative_to(ROOT/'results')),'program':'cp2k' if iscp else 'abacus','complete':False}
    r['atoms']=int(last(r'si(\d+)',d.name,0))
    r['wall_s']=elapsed(d)
    r['pbe_wall_s']=elapsed(d,'time-pbe.json')
    if r['wall_s'] is not None:r['workflow_wall_s']=r['wall_s']+(r['pbe_wall_s'] or 0)
    if iscp:
        pbe=text(d/'pbe.log')
        ev=last(r'ENERGY\| Total FORCE_EVAL.*?\[hartree\]\s+('+NUM+')',s)
        r['energy_ev']=float(ev)*HA_EV if ev else None
        for label,name in [('program_s','CP2K'),('scf_s','scf_env_do_scf'),('exx_s','hfx_ks_matrix'),('exx_force_s','derivatives_four_center')]:r[label]=cp_timing(s,name)
        r['pbe_program_s']=cp_timing(pbe,'CP2K')
        r['pbe_scf_s']=cp_timing(pbe,'scf_env_do_scf')
        r['hse_iterations']=int(last(r'outer SCF loop converged in\s+\d+ iterations or\s+(\d+) steps',s,0))
        r['pbe_iterations']=int(last(r'outer SCF loop converged in\s+\d+ iterations or\s+(\d+) steps',pbe,0))
        forces=[tuple(float(x)*HA_EV/BOHR_A for x in m) for m in re.findall(r'^ FORCES\|\s+\d+\s+('+NUM+r')\s+('+NUM+r')\s+('+NUM+r')\s+'+NUM,s,re.M)]
        r['complete']=bool(ev and r['hse_iterations'] and 'PROGRAM ENDED AT' in s and (not pbe or 'PROGRAM ENDED AT' in pbe))
        inp=text(d/'input.inp')
        r['radius_A']=float(last(r'CUTOFF_RADIUS\s+('+NUM+')',inp,'nan'))
        r['grid_cutoff_Ry']=float(last(r'^\s*CUTOFF\s+('+NUM+')',inp,'nan',flags=re.M))
        r['eps_schwarz_forces']=float(last(r'EPS_SCHWARZ_FORCES\s+('+NUM+')',inp,'1e-4'))
        r['max_memory_MiB_per_rank']=int(last(r'MAX_MEMORY\s+(\d+)',inp,0))
        r['eri_on_the_fly']=int(last(r"Number of sph\. ERI's calculated on the fly:\s+(\d+)",s,0))
        r['screen_initial_p']='SCREEN_ON_INITIAL_P TRUE' in inp
        r['small_radius_warning']='smaller than what is necessary' in s
        r['cell_radius_warning']='larger than half the minimal cell' in s
    else:
        ev=last(r'!FINAL_ETOT_IS\s+('+NUM+')',s)
        r['energy_ev']=float(ev) if ev else None
        v=last(r'^\s*total\s+('+NUM+r')\s+\d+\s+',s,flags=re.M)
        r['program_s']=float(v) if v else None
        r['scf_s']=ab_timing(s,'ESolver_KS','scf_loop')
        r['exx_s']=ab_timing(s,'Exx_LRI','cal_exx_elec')
        r['exx_force_s']=ab_timing(s,'Exx_LRI','cal_exx_force')
        r['force_s']=ab_timing(s,'ESolver_KS_LCAO','cal_force')
        iterations=re.findall(r'^\s*[A-Z]{2}\d+\s+'+NUM+r'\s+'+NUM+r'\s+'+NUM+r'\s+('+NUM+')',stdout,re.M)
        r['total_iterations']=len(iterations)
        residual=last(r'^\s*[A-Z]{2}\d+\s+'+NUM+r'\s+'+NUM+r'\s+('+NUM+r')\s+'+NUM,stdout,flags=re.M)
        r['final_scf_residual']=float(residual) if residual else None
        # Automatic GGA warm start ends at the first second-SCF/EXX-update marker.
        marker=re.search(r'Entering 2nd SCF|Updating EXX and rerun SCF',stdout)
        first=stdout[:marker.start()] if marker else stdout
        r['pbe_iterations']=len(re.findall(r'^\s*[A-Z]{2}\d+\s+',first,re.M))
        r['hse_iterations']=r['total_iterations']-r['pbe_iterations']
        forces=[tuple(map(float,m)) for m in re.findall(r'^\s*Si\d+\s+('+NUM+r')\s+('+NUM+r')\s+('+NUM+r')\s*$',s,re.M)]
        r['complete']=bool(ev and '#SCF IS CONVERGED#' in s and 'Total  Time' in s)
        inp=text(d/'INPUT')
        r['solver']=last(r'^ks_solver\s+(\S+)',inp,flags=re.M)
        r['scf_threshold']=float(last(r'^scf_thr\s+('+NUM+')',inp,'nan',flags=re.M))
        r['complete']=r['complete'] and r['final_scf_residual'] is not None and r['final_scf_residual']<=r['scf_threshold']
        r['grid_cutoff_Ry']=float(last(r'^ecutwfc\s+('+NUM+')',inp,'nan',flags=re.M))
        r['separate_loop']=int(last(r'^exx_separate_loop\s+(\d)',inp,0,flags=re.M))
    r['force_count']=len(forces)
    if forces:
        r['max_force_ev_A']=max(math.sqrt(sum(x*x for x in f)) for f in forces)
        r['forces_ev_A']=forces
    if r.get('program_s') is not None:r['workflow_program_s']=r['program_s']+(r.get('pbe_program_s') or 0)
    if r.get('scf_s') is not None:r['workflow_scf_s']=r['scf_s']+(r.get('pbe_scf_s') or 0)
    r['complete']=r['complete'] and len(forces)==r['atoms']
    if validate_exitcode and (d/'exitcode.txt').exists():
        r['exitcode']=int((d/'exitcode.txt').read_text().strip())
        r['complete']=r['complete'] and r['exitcode']==0
    allocation=text(d.parent/'allocation.txt')
    r['ranks']=int(last(r'NumTasks=(\d+)',allocation,0))
    r['node']=last(r'\bNodeList=(\S+)',allocation)
    for key,value in list(r.items()):
        if isinstance(value,float) and not math.isfinite(value):r[key]=None
    return r

def main():
    dirs=sorted({p.parent for pattern in ['input.inp','INPUT'] for p in (ROOT/'results').rglob(pattern) if 'OUT.' not in str(p.parent)})
    rows=[r for d in dirs if (r:=parse(d))]
    (ROOT/'summary.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
    keys=['case','program','atoms','ranks','node','complete','exitcode','workflow_wall_s','workflow_program_s','workflow_scf_s','program_s','pbe_program_s','scf_s','pbe_scf_s','pbe_iterations','hse_iterations','final_scf_residual','scf_threshold','exx_s','exx_force_s','max_force_ev_A','energy_ev','solver','radius_A','grid_cutoff_Ry','eps_schwarz_forces','max_memory_MiB_per_rank','eri_on_the_fly']
    with (ROOT/'summary.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
    for r in rows:
        print(r['case'],r['complete'],'wall',r.get('workflow_wall_s'),'program',r.get('workflow_program_s'),'SCF',r.get('workflow_scf_s'),'iter',r.get('pbe_iterations'),r.get('hse_iterations'),'E',r.get('energy_ev'))

if __name__=='__main__':main()
