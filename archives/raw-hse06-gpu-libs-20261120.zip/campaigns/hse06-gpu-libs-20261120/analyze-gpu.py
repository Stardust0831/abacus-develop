#!/usr/bin/env python3
"""Compare library ablations and matched HSE workloads without conflating timers."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys

from analyze import ab_timing, parse, text

ROOT = Path(__file__).resolve().parent
OLD = ROOT / 'baseline'


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def difference(a, b):
    vectors = [sum((x - y) ** 2 for x, y in zip(fa, fb))
               for fa, fb in zip(a['forces_ev_A'], b['forces_ev_A'])]
    assert a['atoms'] == b['atoms'] == len(vectors)
    return {
        'energy_ev_atom': abs(a['energy_ev'] - b['energy_ev']) / a['atoms'],
        'max_force_delta_ev_A': math.sqrt(max(vectors)),
        'rms_force_delta_ev_A': math.sqrt(statistics.mean(vectors)),
    }


rows = []
for input_path in sorted((ROOT / 'results').rglob('INPUT')):
    if 'OUT.' in str(input_path.parent):
        continue
    directory = input_path.parent
    # The timed command has its own exit status. A later shell bookkeeping
    # error must remain visible without overwriting the scientific run status.
    row = parse(directory, validate_exitcode=False)
    request = json.loads((directory / 'request.json').read_text())
    row.update({key: request.get(key) for key in ['ri', 'xc', 'repeat', 'trace']})
    row['engine'] = request.get('engine', 'new')
    elapsed_text = text(directory / 'time.json')
    if '{' in elapsed_text:
        elapsed_record = json.loads(elapsed_text[elapsed_text.index('{'):])
        row['exitcode'] = elapsed_record['exitcode']
        row['complete'] = row['complete'] and row['exitcode'] == 0
    else:
        row['complete'] = False
    progress_path = directory.parent / 'progress.json'
    if progress_path.exists():
        progress = json.loads(progress_path.read_text())
        match = next((item for item in progress if Path(item['path']).name == directory.name), None)
        if match:
            row['driver_exitcode'] = match['exitcode']
    row['driver_recording_error'] = '.log: command not found' in text(directory / 'driver.log')
    if row.get('driver_exitcode', 0) != 0:
        row['complete'] = row['complete'] and row['driver_recording_error']
    output = text(directory / 'OUT.si/running_scf.log')
    row['xc_kernel_s'] = ab_timing(output, 'Libxc', 'xc_lda/gga_exc_vxc')
    row['xc_full_s'] = ab_timing(output, 'XC_Functional_Libxc', 'v_xc_libxc')
    launcher = text(directory / 'launcher.log')
    row['libri_trace'] = sorted(set(re.findall(r'LIBRI_CONTRACTION_BACKEND (cpu|gpu)', launcher)))
    row['libxc_gpu_calls'] = len(re.findall(r'LIBXC_GPU_EVAL', launcher))
    row['libxc_gpu_devices'] = sorted(set(re.findall(r'LIBXC_GPU_EVAL device=(\d+)', launcher)))
    row['input_sha256'] = {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                           for name in ['INPUT', 'STRU', 'KPT', 'Si.upf', 'Si_gga_7au_100Ry_2s2p1d.orb']}
    rows.append(row)
write_json('summary.json', rows)
keys = ['case', 'atoms', 'ranks', 'node', 'ri', 'xc', 'repeat', 'complete', 'exitcode',
        'workflow_wall_s', 'program_s', 'scf_s', 'exx_s', 'exx_force_s', 'force_s',
        'xc_kernel_s', 'xc_full_s', 'pbe_iterations', 'hse_iterations',
        'energy_ev', 'max_force_ev_A', 'final_scf_residual']
with (ROOT / 'summary.csv').open('w') as stream:
    writer = csv.DictWriter(stream, fieldnames=keys, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)

checks = {'limits': {'energy_ev_atom': 1e-6, 'max_force_delta_ev_A': 1e-5},
          'validation_complete': False, 'same_binary': [], 'old_module': []}
ablations = [row for row in rows if row['case'].startswith('validation-si64-g4-')]
reference = next((row for row in ablations if row['ri'] == row['xc'] == 'cpu' and row['complete']), None)
if reference:
    for row in ablations:
        if not row['complete']:
            continue
        delta = difference(row, reference)
        passed = all(delta[key] <= value for key, value in checks['limits'].items())
        checks['same_binary'].append(dict(case=row['case'], ri=row['ri'], xc=row['xc'],
                                          passed=passed, **delta))
    old_rows = json.loads((OLD / 'summary.json').read_text())
    old_reference = next(row for row in old_rows if row['case'] ==
                         'precision-check-2652081/02-abacus-si64-displaced-normal')
    checks['old_module'] = [dict(case=reference['case'], **difference(reference, old_reference))]
    checks['validation_complete'] = (
        len(ablations) == 4 and len(checks['same_binary']) == 4
        and all(item['passed'] for item in checks['same_binary'])
        and all(row['libri_trace'] == [row['ri']] for row in ablations)
        and all((row['libxc_gpu_calls'] > 0) == (row['xc'] == 'gpu') for row in ablations)
    )

old_groups = json.loads((OLD / 'aggregate.json').read_text())['groups']
groups = []
for atoms, ranks in [(64, 1), (64, 4), (216, 4), (216, 16)]:
    candidates = [row for row in rows if row['case'].startswith('benchmark-')
                  and row['atoms'] == atoms and row['ranks'] == ranks]
    if not candidates:
        continue
    done = [row for row in candidates if row['complete']]
    group = {'atoms': atoms, 'gpus': ranks, 'repeats': len(done),
             'complete': len(candidates) == len(done) == 2,
             'cases': [row['case'] for row in candidates]}
    if done:
        for key in ['workflow_wall_s', 'program_s', 'scf_s', 'exx_s', 'exx_force_s', 'xc_kernel_s', 'xc_full_s']:
            values = [row[key] for row in done if row[key] is not None]
            group[key] = statistics.median(values) if values else None
        group['wall_min_s'] = min(row['workflow_wall_s'] for row in done)
        group['wall_max_s'] = max(row['workflow_wall_s'] for row in done)
        group['nodes'] = sorted(set(row['node'] for row in done))
        group['pbe_iterations'] = sorted(set(row['pbe_iterations'] for row in done))
        group['hse_iterations'] = sorted(set(row['hse_iterations'] for row in done))
        group['energy_spread_ev_atom'] = (max(row['energy_ev'] for row in done)
                                         - min(row['energy_ev'] for row in done)) / atoms
        old_abacus = next(row for row in old_groups if row['atoms'] == atoms
                          and row['gpus'] == ranks and row['program'] == 'abacus')
        cp2k = next(row for row in old_groups if row['atoms'] == atoms
                    and row['gpus'] == ranks and row['program'] == 'cp2k')
        group['old_abacus_wall_s'] = old_abacus['workflow_wall_s']
        group['cp2k_wall_s'] = cp2k['workflow_wall_s']
        group['old_to_new_speedup'] = old_abacus['workflow_wall_s'] / group['workflow_wall_s']
        group['cp2k_to_new_speedup'] = cp2k['workflow_wall_s'] / group['workflow_wall_s']
        group['energy_vs_old_ev_atom'] = max(abs(row['energy_ev'] - old_abacus['energy_ev']) / atoms for row in done)
    groups.append(group)
checks['performance_complete'] = len(groups) == 4 and all(group['complete'] for group in groups)
write_json('validation.json', checks)
write_json('aggregate.json', {'groups': groups, 'ablations': ablations})
for row in rows:
    print(row['case'], row['complete'], 'wall', row.get('workflow_wall_s'),
          'E', row.get('energy_ev'), 'iter', row.get('pbe_iterations'), row.get('hse_iterations'))
print('Validation:', checks['validation_complete'], 'Performance:', checks['performance_complete'])
if '--require-validation' in sys.argv:
    assert checks['validation_complete'], checks
if '--require-complete' in sys.argv:
    assert checks['validation_complete'] and checks['performance_complete'], checks
