#!/usr/bin/env python3
"""Audit completed runs, exact baseline inputs, resources and loaded libraries."""
import itertools
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
rows = json.loads((ROOT / 'summary.json').read_text())
validation = json.loads((ROOT / 'validation.json').read_text())
assert validation['validation_complete'] and validation['performance_complete']
assert len(rows) == 13 and all(row['complete'] for row in rows)
old = json.loads((ROOT / 'baseline/aggregate.json').read_text())['groups']
old_rows = {row['case']: row for row in json.loads((ROOT / 'baseline/summary.json').read_text())}
old_hashes = json.loads((ROOT / 'baseline/executed-input-sha256.json').read_text())
binary_hash = (ROOT / 'logs/abacus-sha256.txt').read_text().split()[0]
audits = []
for row in rows:
    directory = ROOT / 'results' / row['case']
    allocation = (directory.parent / 'allocation.txt').read_text()
    assert 'Partition=16V100 ' in allocation
    assert f'NumTasks={row["ranks"]} ' in allocation
    assert f'NumCPUs={8 * row["ranks"]} ' in allocation
    assert f'TresPerNode=gres/gpu:{row["ranks"]}' in allocation
    assert row['exitcode'] == 0 and row['force_count'] == row['atoms']
    assert row['final_scf_residual'] <= 1e-8
    assert all(math.isfinite(value) for vector in row['forces_ev_A'] for value in vector)
    if row['engine'] == 'new':
        assert (directory / 'executable-sha256.txt').read_text().split()[0] == binary_hash
        linked = (directory / 'linked-libraries.txt').read_text()
        for library in ['libxc', 'ddla']:
            assert f'/hse06-gpu-libs-20261120/install/{library}/lib/' in linked
        settings = (directory / 'run-settings.txt').read_text()
        assert 'OMP_NUM_THREADS=4\n' in settings and 'OPENBLAS_NUM_THREADS=1\n' in settings
    if row['case'].startswith('benchmark-'):
        previous = next(group for group in old if group['program'] == 'abacus'
                        and group['atoms'] == row['atoms'] and group['gpus'] == row['ranks'])
        for filename, digest in row['input_sha256'].items():
            assert digest == old_hashes[f'results/{previous["cases"][0]}/{filename}']
        reference = old_rows[previous['cases'][0]]
        energy_delta = abs(row['energy_ev'] - reference['energy_ev']) / row['atoms']
        force_delta = max(math.sqrt(sum((a - b) ** 2 for a, b in zip(fa, fb)))
                          for fa, fb in zip(row['forces_ev_A'], reference['forces_ev_A']))
        assert energy_delta <= 1e-6 and force_delta <= 1e-5
        audits.append(dict(case=row['case'], energy_vs_old_ev_atom=energy_delta,
                           max_force_vs_old_ev_A=force_delta, inputs_identical=True,
                           executable_exitcode=row['exitcode'], driver_exitcode=row['driver_exitcode'],
                           driver_recording_error=row['driver_recording_error']))

consistency = {}
for atoms in [64, 216]:
    group = [row for row in rows if row['case'].startswith('benchmark-') and row['atoms'] == atoms]
    energy = (max(row['energy_ev'] for row in group) - min(row['energy_ev'] for row in group)) / atoms
    force = max(math.sqrt(sum((x - y) ** 2 for x, y in zip(fa, fb)))
                for a, b in itertools.combinations(group, 2)
                for fa, fb in zip(a['forces_ev_A'], b['forces_ev_A']))
    assert energy <= 1e-6 and force <= 1e-5
    consistency[f'Si{atoms}'] = dict(energy_spread_ev_atom=energy, max_force_delta_ev_A=force)

xc_test = (ROOT / 'logs/libxc-adapter-test.log').read_text()
assert 'PASS 24 ' in xc_test
for threads in [1, 4]:
    log = (ROOT / f'logs/libri-mpi1-omp{threads}.log').read_text()
    assert 'PASS real label=all' in log and 'PASS complex label=all' in log
    assert not re.search(r'FAIL|ERROR', log)
result = dict(passed=True, completed_calculations=13, benchmark_calculations=8,
              validation_calculations=4, fresh_module_controls=1,
              partition='16V100', numerical_limits=validation['limits'],
              binary_sha256=binary_hash, benchmark_audits=audits,
              parallel_consistency=consistency)
(ROOT / 'evidence-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
