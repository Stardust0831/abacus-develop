#!/usr/bin/env python3
"""Create the completed benchmark report and standalone scientific plots."""
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.mpl-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

aggregate = json.loads((ROOT / 'aggregate.json').read_text())
verified = json.loads((ROOT / 'evidence-validation.json').read_text())
validation = json.loads((ROOT / 'validation.json').read_text())
manifest = json.loads((ROOT / 'manifest.json').read_text())
rows = json.loads((ROOT / 'summary.json').read_text())
assert verified['passed'] and validation['performance_complete']
groups = aggregate['groups']
ablations = aggregate['ablations']
old = json.loads((ROOT / 'baseline/aggregate.json').read_text())['groups']
control = next(row for row in rows if row['engine'] == 'module')
cpu = next(row for row in ablations if row['ri'] == row['xc'] == 'cpu')
gpu = next(row for row in ablations if row['ri'] == row['xc'] == 'gpu')

plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False,
                     'svg.fonttype': 'none'})
fig, axes = plt.subplots(2, 2, figsize=(11, 7.6))
for ax, group in zip(axes.flat, groups):
    atoms, ranks = group['atoms'], group['gpus']
    old_ab = next(row for row in old if row['program'] == 'abacus'
                  and row['atoms'] == atoms and row['gpus'] == ranks)
    old_cp = next(row for row in old if row['program'] == 'cp2k'
                  and row['atoms'] == atoms and row['gpus'] == ranks)
    records = [old_cp, old_ab, group]
    values = [record['workflow_wall_s'] for record in records]
    lower = [value - record['wall_min_s'] for value, record in zip(values, records)]
    upper = [record['wall_max_s'] - value for value, record in zip(values, records)]
    ax.bar(range(3), values, color=['#386cb0', '#8e949c', '#168c68'],
           yerr=[lower, upper], capsize=4, width=0.64)
    ax.set_xticks(range(3), ['CP2K\nprior module', 'ABACUS\nprior module', 'ABACUS\nnew GPU libraries'])
    ax.set_title(f'Si{atoms} · {ranks} V100 + {ranks * 4} CPU cores')
    ax.set_ylabel('Wall time (s)')
    ax.set_ylim(0, max(values) * 1.21)
    ax.grid(axis='y', alpha=0.18)
    ax.set_axisbelow(True)
    for index, value in enumerate(values):
        ax.text(index, value + max(values) * 0.035, f'{value:.2f}', ha='center', fontsize=10)
fig.suptitle('HSE06 Si energy + forces on SAI 16V100', fontsize=16)
fig.text(0.5, 0.015,
         'Median and range of 2 independent starts; includes initial GGA/PBE SCF.\n'
         'Prior baselines use different nodes. CP2K and ABACUS use different numerical approximations.',
         ha='center', fontsize=9)
fig.tight_layout(rect=(0, 0.065, 1, 0.955))
fig.savefig(ROOT / 'timing.png', dpi=180)
fig.savefig(ROOT / 'timing.svg')
plt.close(fig)

fig, ax = plt.subplots(figsize=(9, 4.6))
labels = ['CPU RI\nCPU XC', 'GPU RI\nCPU XC', 'CPU RI\nGPU XC', 'GPU RI\nGPU XC']
values = [row['workflow_wall_s'] for row in ablations]
ax.bar(labels, values, color=['#8e949c', '#386cb0', '#d39237', '#168c68'], width=0.62)
for index, value in enumerate(values):
    ax.text(index, value + 2, f'{value:.2f} s', ha='center')
ax.set_ylabel('Wall time (s)')
ax.set_ylim(0, max(values) * 1.18)
ax.set_title('Displaced Si64 · 4 V100 · same executable and node')
ax.grid(axis='y', alpha=0.18)
ax.set_axisbelow(True)
fig.text(0.5, 0.02, 'One run per combination; identical SCF iterations and numerical thresholds.',
         ha='center', fontsize=9)
fig.tight_layout(rect=(0, 0.045, 1, 1))
fig.savefig(ROOT / 'ablation.png', dpi=180)
fig.savefig(ROOT / 'ablation.svg')
plt.close(fig)

def table(headers, entries):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |',
                      '| ' + ' | '.join(['---'] * len(headers)) + ' |']
                     + ['| ' + ' | '.join(map(str, entry)) + ' |' for entry in entries])

lines = [
    '# ABACUS 接入最新 LibRI / LibXC GPU 后的 HSE06 实测',
    '',
    '测试日期：2026-11-20，全部计算使用 SAI `16V100` 分区。独立构建与测试完成；8 次正式计时、4 次后端对照、1 次原模块复核均完成了自洽与力计算。',
    '',
    f'在扰动 Si64 的同一可执行文件对照中，两个库从 CPU 切到 GPU 后总耗时由 {cpu["workflow_wall_s"]:.2f} 秒降至 {gpu["workflow_wall_s"]:.2f} 秒，约 {cpu["workflow_wall_s"] / gpu["workflow_wall_s"]:.2f} 倍。主要收益来自 LibRI；LibXC 的 GPU 路径进一步缩短了交换关联势计算。',
    '',
    '下表沿用前次相同 Si 输入、APNS efficiency 轨道和数值阈值，列出含 GGA 初始自洽、HSE 自洽和最终原子力的总墙钟时间。每组两次独立启动，不复用前次 HSE 波函数；取中位数。CP2K 和原 ABACUS 模块数据来自同日前一轮，详见 `baseline/REPORT.md`。',
    '',
    table(['Si 原子数', 'GPU / CPU物理核', 'CP2K / s', '原 ABACUS / s',
           '新 ABACUS / s [范围]', '原/新耗时比', 'CP2K/新耗时比'], [
        [g['atoms'], f'{g["gpus"]} / {4 * g["gpus"]}', f'{g["cp2k_wall_s"]:.2f}',
         f'{g["old_abacus_wall_s"]:.2f}',
         f'{g["workflow_wall_s"]:.2f} [{g["wall_min_s"]:.2f}, {g["wall_max_s"]:.2f}]',
         f'{g["old_to_new_speedup"]:.2f}×', f'{g["cp2k_to_new_speedup"]:.2f}×'] for g in groups]),
    '',
    '![完整工作流计时](timing.png)',
    '',
    '**跨程序比较的精度范围沿用前次结论。** CP2K 为 DZVP-MOLOPT-SR-GTH + cFIT3 ADMM、Si64/Si216 交换半径 5/6 Å、力积分筛选 1e-6；ABACUS 为 APNS v1 efficiency 的 Si 赝势和 7 bohr 2s2p1d LCAO、100 Ry、RI PCA/C/V/DM=1e-4、SCF=1e-8。两者都为 HSE 25% 短程交换、ω=0.11 bohr⁻¹，Γ 点固定占据。不同基组、赝势及近似不能解释为已经证明等精度；不跨程序比较绝对总能量。',
    '',
    '每卡 1 个 MPI rank、4 个 OpenMP 线程，BLAS 线程数 1。Slurm 每卡分配 8 个硬件线程和 15 GiB 主机内存；MPI 绑定每 rank 4 个物理核。硬件为 AMD 5995WX + V100-SXM2 16 GB。单卡使用 cuSOLVER，多卡使用 ELPA。新旧主表使用同分区的不同节点；1/4 卡为共享节点，重复范围不能消除共用节点带来的波动。',
    '',
    table(['原子数', 'GPU', '新构建节点', '初始 GGA / HSE 迭代', 'SCF / s', '交换电子 / s', '交换力 / s'], [
        [g['atoms'], g['gpus'], ', '.join(g['nodes']),
         f'{", ".join(map(str, g["pbe_iterations"]))} / {", ".join(map(str, g["hse_iterations"]))}', f'{g["scf_s"]:.2f}',
         f'{g["exx_s"]:.2f}', f'{g["exx_force_s"]:.2f}'] for g in groups]),
    '',
    '程序内部计时器用来定位开销，主要比较指标仍是外部总墙钟时间。ABACUS 默认不打印低于总时间 1% 的计时项，因此 CSV 中缺失的 LibXC 小计不等于零耗时。',
    '',
    '**同一构建的 CPU/GPU 对照。** 第一个 Si 原子移动 (0.01, 0.02, -0.015) Å，以非零原子力检验 GPU 路径。四种组合都在 16v100n17 上依次运行，GGA/HSE 迭代数均为 12/12；每种一次，开启调用追踪，故这张表是功能对照与收益定位，不提供重复统计。',
    '',
    table(['LibRI', 'LibXC', '总耗时 / s', '相对 CPU/CPU', '交换电子 / s', '交换力 / s', '完整 LibXC 势 / s'], [
        [r['ri'], r['xc'], f'{r["workflow_wall_s"]:.2f}',
         f'{cpu["workflow_wall_s"] / r["workflow_wall_s"]:.2f}×', f'{r["exx_s"]:.2f}',
         f'{r["exx_force_s"]:.2f}', f'{r["xc_full_s"]:.2f}'] for r in ablations]),
    '',
    '![同一可执行文件后端对照](ablation.png)',
    '',
    f'原模块在同节点追加复核为 {control["workflow_wall_s"]:.2f} 秒，前次为 291.65 秒。新构建即使两个库都走 CPU，也为 {cpu["workflow_wall_s"]:.2f} 秒。因此主表的“原/新耗时比”同时包含依赖版本、构建与运行打包方式的差异，不能全部归因于 GPU。能隔离后端开关的收益来自上面的同一可执行文件对照；尚未进一步归因新构建 CPU 路径加快的原因。',
    '',
    '**数值与执行证据。** 所有计算均有退出码 0、最终 SCF 残差 ≤1e-8 和完整有限原子力。正式计时的 INPUT、STRU、KPT、赝势、轨道文件逐字节匹配前次对应算例。新可执行文件及动态库路径逐例核对，12 次新构建计算使用同一二进制 SHA256。',
    '',
    table(['对照', '能量绝对差 / eV·atom⁻¹', '最大力向量差 / eV·Å⁻¹'], [
        [f'{c["ri"]}/{c["xc"]} 相对 CPU/CPU', f'{c["energy_ev_atom"]:.3e}', f'{c["max_force_delta_ev_A"]:.3e}']
        for c in validation['same_binary']]
        + [['新 CPU/CPU 相对原模块', f'{validation["old_module"][0]["energy_ev_atom"]:.3e}',
            f'{validation["old_module"][0]["max_force_delta_ev_A"]:.3e}']]),
    '',
    f'正式计时相对原模块的最大能量差为 {max(a["energy_vs_old_ev_atom"] for a in verified["benchmark_audits"]):.3e} eV/atom，最大力向量差为 {max(a["max_force_vs_old_ev_A"] for a in verified["benchmark_audits"]):.3e} eV/Å。重复与 MPI 数量改变的能量/力一致性详见 `evidence-validation.json`。预先规定的验收界限为 1e-6 eV/atom 和 1e-5 eV/Å。',
    '',
    'LibXC GPU 单元对照覆盖 LDA_X、PBE_X、PBE_C、HSE06，spin=1/2，17/1025/8193 网格点，共24组，最大归一化差异 5.74348e-14。LibRI 上游 GPU 对称性测试在其要求的单 MPI rank 下，以 OpenMP=1/4 通过实数和复数检查；多 MPI rank 由上述4卡非零力及1/4/16卡正式算例验证。追踪日志记录 LibRI GPU 后端选择及 LibXC 在设备0、1、2、3上的实际调用。',
    '',
    '**构建与接入。** ABACUS 主程序固定前次的提交，使用未修改的最新 LibRI/LibXC/DDLA 上游源码及本目录保存的 ABACUS 适配补丁。源码分支在取样时固定为下列 SHA：',
    '',
    table(['组件', '分支', '提交'], [['ABACUS', '前次 module 源码', manifest['abacus_sha']]]
          + [[name, manifest[name]['branch'], manifest[name]['sha']] for name in ['libri', 'libxc', 'ddla']]),
    '',
    'LibRI 通过 DDLA 0.0.6 的 CUDA 后端执行张量收缩；`SAI_RI_DEVICE=cpu|gpu` 控制模式。LibXC 7.1.2 devel 使用显式 host/device functional 初始化；新增适配层一次上传整个本地密度网格，在 GPU 计算 LDA/GGA 后取回结果，密度处理、阈值屏蔽、梯度和势组装沿用原代码。`SAI_LIBXC_DEVICE=cpu|gpu` 控制该路径。两者在实验构建中默认 gpu；正式计时显式设置且关闭追踪。',
    '',
    '编译器 GCC 13.3、CUDA 12.9，目标 SM70，C++17（DDLA 要求）。独立构建关闭未使用的 ML 功能，保留 HSE/LCAO、CUDA、ELPA、cuSOLVERMp、cuBLASMp 和 NCCL。来源是固定源码归档，因此 `--info` 的 Git Commit 显示 N/A；来源 SHA、补丁和二进制校验值另行记录。没有复用此前的实验性同步删除补丁。',
    '',
    '当前验证范围是这些 Γ 点、无自旋极化的 Si HSE 能量与力算例，以及独立 LibXC 自旋单元测试。DFPT 等其他直接调用 LibXC 的路径尚未做 host/device 适配审计。这是独立实验构建，未替换公共 module。',
    '',
    '**资源效率。** 增加 GPU 数同时增加 CPU 核数；本轮小体系的资源扩展收益有限。下列 GPU 小时指分配卡数×程序总墙钟时间，不等于实际 GPU 忙碌时间，也不包含排队或构建：',
    '',
    table(['体系', '资源变化', '总耗时加速比', '分配GPU小时：前 → 后'], [
        [f'Si{atoms}', f'{small} → {large} 卡',
         f'{next(g["workflow_wall_s"] for g in groups if g["atoms"] == atoms and g["gpus"] == small) / next(g["workflow_wall_s"] for g in groups if g["atoms"] == atoms and g["gpus"] == large):.2f}×',
         f'{next(g["workflow_wall_s"] for g in groups if g["atoms"] == atoms and g["gpus"] == small) * small / 3600:.3f} → {next(g["workflow_wall_s"] for g in groups if g["atoms"] == atoms and g["gpus"] == large) * large / 3600:.3f}']
        for atoms, small, large in [(64, 1, 4), (216, 4, 16)]]),
    '',
    '**运行记录与复现。** 初始三个计时批次在 ABACUS 已成功退出后，因为运行期间更新了一条日志语句，Bash 续读脚本的位置发生变化，导致记录步骤报 `.log: command not found`。其 `/usr/bin/time` 独立记录的程序退出码为0，SCF、最终能量、力及结束标记完整；这些已完成计算进入主表。后续重复在同节点重新调度，脚本退出正常。`evidence-validation.json` 同时保留程序退出码和批处理驱动退出码，不把批处理失败隐藏为成功。',
    '',
    f'SAI 工作目录：`{manifest["remote"]}`；可执行文件：`{manifest["remote"]}/install/abacus/bin/abacus`。',
    '',
    '[复现说明](REPRODUCE.md) · [源码适配补丁](abacus-gpu-libs.patch) · [逐例CSV](summary.csv) · [数据验收](evidence-validation.json) · [复现包](reproduce-gpu-libs.tar.gz) · [原始证据包](evidence.tar.gz) · [校验值](SHA256SUMS)',
]
(ROOT / 'REPORT.md').write_text('\n'.join(lines) + '\n')
