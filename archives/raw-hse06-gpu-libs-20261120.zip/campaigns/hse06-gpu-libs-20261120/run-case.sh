#!/bin/bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
case_dir=$1
ranks=$2
ri=$3
xc=$4
trace=$5
engine=${6:-new}
if [[ "$engine" == module ]]; then
 exec bash "$root/baseline/run-case.sh" abacus "$case_dir" "$ranks"
fi
source "$root/build-env.sh"
export LD_LIBRARY_PATH="$root/install/ddla/lib:$root/install/libxc/lib:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=4 OMP_PLACES=cores OMP_PROC_BIND=close OMP_DYNAMIC=FALSE
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export SAI_RI_DEVICE="$ri" SAI_LIBXC_DEVICE="$xc"
unset SAI_GPU_TRACE
if [[ "$trace" == 1 ]]; then export SAI_GPU_TRACE=1; fi
test -f "$root/logs/abacus-complete"
binary="$root/install/abacus/bin/abacus"
cd "$case_dir"
(set +u; module -t list) > modules.txt 2>&1
ldd "$binary" > linked-libraries.txt
sha256sum "$binary" > executable-sha256.txt
printf 'SAI_RI_DEVICE=%s\nSAI_LIBXC_DEVICE=%s\nOMP_NUM_THREADS=%s\nOPENBLAS_NUM_THREADS=%s\n' \
 "$SAI_RI_DEVICE" "$SAI_LIBXC_DEVICE" "$OMP_NUM_THREADS" "$OPENBLAS_NUM_THREADS" > run-settings.txt
set +e
/usr/bin/time -f '{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kb":%M,"exitcode":%x}' \
 -o time.json timeout 3600 mpirun -np "$ranks" --map-by "ppr:$ranks:node:pe=4" \
 --bind-to core "$binary" > launcher.log 2>&1
status=$?
echo "$status" > exitcode.txt
exit "$status"
