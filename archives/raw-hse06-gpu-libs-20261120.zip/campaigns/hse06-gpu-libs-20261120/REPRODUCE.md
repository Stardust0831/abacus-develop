# 复现实验

`reproduce-gpu-libs.tar.gz` 包含固定上游源码归档 `sources.tar.gz`、完整 ABACUS 补丁、构建/运行/分析脚本、Si 输入与 APNS 文件，以及前次基准的解析数据。`evidence.tar.gz` 包含本轮原始输出、计时、分配信息和构建日志。

需要 SAI 上现有的 devtools modules，以及 `build-deps.sbatch` 中固定的原 ABACUS SIF（用于提取原有 LibComm、cereal 和 JSON 头文件）。所有作业均固定 `16V100` 分区，账户为 `proj-sai-hpc-software`。构建不修改系统软件或公共 module。

在一个新的、可写测试目录解压复现包，然后执行：

```bash
tar -xzf sources.tar.gz
patch -d src/abacus -p1 < abacus-gpu-libs.patch

# 先记录返回的 job ID；后一个构建等待依赖成功。
sbatch build-deps.sbatch
sbatch --dependency=afterok:依赖构建ID build-abacus.sbatch
```

构建脚本先运行 LibXC CPU/GPU 数值对照与 LibRI 上游 GPU 对称性测试，再编译 ABACUS。成功后存在 `logs/abacus-complete`，版本、动态库路径和二进制哈希记录在 `logs/`。源自归档的 ABACUS `--info` 会显示 Git Commit N/A；用 `manifest.json` 中的源码提交和 `source-sha256.json` 中的归档/补丁哈希确认身份。

先运行扰动 Si64 的四种后端组合：

```bash
sbatch campaign.sbatch validation-si64-g4.json
```

确认四项计算收敛、能量与力在预定界限内，再运行正式计时：

```bash
sbatch --qos=flood-1o2gpu --ntasks=1 --gpus-per-node=1 campaign.sbatch benchmark-g1.json
sbatch --ntasks=4 --gpus-per-node=4 campaign.sbatch benchmark-g4.json
sbatch --ntasks=16 --gpus-per-node=16 campaign.sbatch benchmark-g16.json
```

每个正式规格已经包含两次独立启动。`benchmark-*-remaining.json` 只用于复核本轮发生过的记录脚本故障及剩余作业调度，不用于全新复现。运行期间不要原地覆盖正在读取的 shell 脚本。

若也要复核前次原模块，在相同节点另行提交：

```bash
sbatch --nodelist=验证所用节点 campaign.sbatch control-module-si64-g4.json
```

执行 `python3 analyze-gpu.py --require-complete` 汇总与检查数值结果。本轮证据包可进一步执行 `python3 verify-evidence.py` 与 `python3 make-report.py`；后两者审计本轮固定二进制与记录格式，不能将新编译产生的不同二进制哈希直接当成本轮原始证据。图表需要 matplotlib。

新程序的环境由 `build-env.sh` 和 `run-case.sh` 加载：

- `SAI_RI_DEVICE=cpu|gpu`：LibRI 张量收缩后端。
- `SAI_LIBXC_DEVICE=cpu|gpu`：LibXC 本地密度网格的计算后端。
- `SAI_GPU_TRACE=1`：打印后端/设备调用，用于验证；正式计时不设置。

实验适配覆盖本文的 HSE/PBE LDA/GGA 势路径，未验证 DFPT 等其他直接调用 LibXC 的工作流。测试范围、近似和比较限制见 `REPORT.md`。
