#!/usr/bin/env python3
"""Run isolated, explicitly selected CPU/GPU library combinations."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
spec = json.loads((root / sys.argv[1]).read_text())
out = root / 'results' / f'{spec["name"]}-{os.environ["SLURM_JOB_ID"]}'
out.mkdir(parents=True, exist_ok=False)
shutil.copy2(root / sys.argv[1], out / 'request.json')
for name, command in [
    ('allocation.txt', ['scontrol', 'show', 'job', '-o', os.environ['SLURM_JOB_ID']]),
    ('lscpu.txt', ['lscpu']),
    ('gpu.txt', ['nvidia-smi', '-q']),
]:
    with (out / name).open('w') as stream:
        subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True)
(out / 'environment.json').write_text(json.dumps(
    {k: v for k, v in os.environ.items() if k.startswith(('SLURM_', 'CUDA_', 'OMP_'))}, indent=2))
results = []
for index, item in enumerate(spec['cases']):
    label = f'{index:02d}-{item["input"]}-ri{item["ri"]}-xc{item["xc"]}'
    dest = out / label
    shutil.copytree(root / 'inputs' / item['input'], dest)
    for path in (root / 'data').iterdir():
        shutil.copy2(path, dest / path.name)
    input_path = dest / 'INPUT'
    content = input_path.read_text()
    for before, after in item.get('replace', {}).items():
        assert before in content, (before, input_path)
        content = content.replace(before, after)
    input_path.write_text(content)
    (dest / 'request.json').write_text(json.dumps(item, indent=2) + '\n')
    start = time.time()
    print('START', label, time.strftime('%FT%T%z'), flush=True)
    with (dest / 'driver.log').open('w') as stream:
        process = subprocess.run([
            'bash', str(root / 'run-case.sh'), str(dest), str(spec['ranks']),
            item['ri'], item['xc'], '1' if item.get('trace') else '0',
            item.get('engine', 'new'),
        ], stdout=stream, stderr=subprocess.STDOUT)
    result = dict(item, index=index, exitcode=process.returncode,
                  driver_wall_s=time.time() - start, path=str(dest), start_unix=start)
    results.append(result)
    (out / 'progress.json').write_text(json.dumps(results, indent=2) + '\n')
    print('END', label, process.returncode, round(result['driver_wall_s'], 2), flush=True)
    if process.returncode:
        sys.exit(process.returncode)
(out / 'complete.txt').write_text(time.strftime('%FT%T%z') + '\n')
