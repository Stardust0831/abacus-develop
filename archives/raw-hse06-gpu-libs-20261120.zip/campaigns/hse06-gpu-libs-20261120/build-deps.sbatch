#!/bin/bash
#SBATCH --job-name=hse-gpu-libs-build
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-gpu
#SBATCH --nodes=1
#SBATCH --ntasks=8
#SBATCH --gpus-per-node=8
#SBATCH --time=02:00:00
#SBATCH --output=build-deps-%j.log
#SBATCH --export=ALL
set -euo pipefail
root=$SLURM_SUBMIT_DIR
cd "$root"
source "$root/build-env.sh"
mkdir -p logs build install imported-deps
(set +u; module -t list) > logs/build-modules.txt 2>&1
lscpu > logs/build-lscpu.txt
nvidia-smi -q > logs/build-gpu.txt
gcc --version > logs/compiler.txt
image=/home/stardust/sai-hpc-software/sif-beta/runtimes/daily-20261116-43934692710-1-abacus/images/abacus/16V100.sif
prefix=/opt/apps/abacus/abacus-development-develop-2026-11-16-g4e9f1636b7ca-r4555f0f84db5/16V100
apptainer exec --no-home --bind /usr:/usr:ro,/lib:/lib:ro,/lib64:/lib64:ro --bind "$root:$root" --env PATH=/usr/bin:/bin "$image" bash -c \
 'set -e; for item in cereal json LibComm-master libnpy-1.0.1; do cp -a "$1/dependencies/$item" "$2/imported-deps/"; done; cp "$1/share/sai/CMakeCache.txt" "$2/logs/original-CMakeCache.txt"' bash "$prefix" "$root"
(
 cmake -S src/LibDDLA -B build/ddla -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="$root/install/ddla" -DCMAKE_INSTALL_LIBDIR=lib \
  -DCMAKE_CXX_COMPILER="$CXX" -DCMAKE_CUDA_HOST_COMPILER="$CXX" \
  -DCMAKE_CUDA_ARCHITECTURES=70 -DDDLA_USE_CUDA=ON -DBUILD_TESTS=OFF \
  -DCUBLAS_LIBRARY=/opt/devtools/nvidia/cuda-12.9.1/lib64/libcublas.so \
  -DCURAND_LIBRARY=/opt/devtools/nvidia/cuda-12.9.1/lib64/libcurand.so \
  -DCUSOLVER_LIBRARY=/opt/devtools/nvidia/cuda-12.9.1/lib64/libcusolver.so \
  -DDDLA_LAPACK_LIBRARY="$OPENBLAS_ROOT/lib/libopenblas.so"
 cmake --build build/ddla --parallel 8
 cmake --install build/ddla
 touch logs/ddla-built
) > logs/ddla-build.log 2>&1 &
ddla_pid=$!
(
 if [ -f logs/libxc-built ]; then exit 0; fi
 cmake -S src/libxc -B build/libxc -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="$root/install/libxc" -DCMAKE_INSTALL_LIBDIR=lib \
  -DCMAKE_C_COMPILER="$CC" -DCMAKE_CUDA_HOST_COMPILER="$CXX" \
  -DCMAKE_CUDA_ARCHITECTURES=70 -DENABLE_CUDA=ON -DENABLE_FORTRAN=OFF \
  -DMAXORDER=2 -DBUILD_SHARED_LIBS=ON -DBUILD_TESTING=OFF \
  -DCMAKE_C_FLAGS='-O3 -march=znver3 -mtune=znver3'
 cmake --build build/libxc --parallel 24
 cmake --install build/libxc
 touch logs/libxc-built
) > logs/libxc-build.log 2>&1 &
libxc_pid=$!
status=0
wait "$ddla_pid" || status=1
wait "$libxc_pid" || status=1
if [ "$status" != 0 ]; then exit "$status"; fi
sha256sum install/ddla/lib/libddla.so* install/libxc/lib/libxc.so* > logs/dependency-library-sha256.txt
touch logs/deps-complete
