#!/bin/bash
#SBATCH --job-name=hse-abacus-gpu-build
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-gpu
#SBATCH --nodes=1
#SBATCH --ntasks=8
#SBATCH --gpus-per-node=8
#SBATCH --time=02:00:00
#SBATCH --output=build-abacus-%j.log
#SBATCH --export=ALL
set -euo pipefail
root=$SLURM_SUBMIT_DIR
cd "$root"
source "$root/build-env.sh"
source /opt/sai/runtime/mps_mapping.d/16V100.bash
export LD_LIBRARY_PATH="$root/install/ddla/lib:$root/install/libxc/lib:${LD_LIBRARY_PATH:-}"
test -f logs/deps-complete
xcsrc="$root/src/abacus/source/source_hamilt/module_xc"
g++ -O2 -std=c++17 "$xcsrc/libxc_gpu.cpp" "$xcsrc/unittests/test_libxc_gpu.cpp" \
 -I"$root/install/libxc/include" -I"$CUDA_HOME/include" \
 -L"$root/install/libxc/lib" -L"$CUDA_HOME/lib64" -lxc -lcudart \
 -o build/test_libxc_gpu > logs/libxc-adapter-build.log 2>&1
./build/test_libxc_gpu > logs/libxc-adapter-test.log 2>&1
cmake -S src/LibRI/unittests/gpu_symmetry -B build/libri-tests \
 -DENABLE_GPU=ON -DCMAKE_BUILD_TYPE=Debug -DDDLA_ROOT="$root/install/ddla" \
 -DLIBCOMM_ROOT="$root/imported-deps/LibComm-master" -DCEREAL_ROOT="$root/imported-deps/cereal" \
 -DBLAS_LIBRARIES="$OPENBLAS_ROOT/lib/libopenblas.so" -DLAPACK_LIBRARIES="$OPENBLAS_ROOT/lib/libopenblas.so" \
 > logs/libri-test-configure.log 2>&1
cmake --build build/libri-tests --parallel 2 > logs/libri-test-build.log 2>&1
for ranks in 1; do
 for threads in 1 4; do
  OMP_NUM_THREADS=$threads mpirun -np "$ranks" --map-by "ppr:$ranks:node:pe=4" --bind-to core \
   build/libri-tests/test_lri_gpu_symmetry > "logs/libri-mpi$ranks-omp$threads.log" 2>&1
 done
done
cmake -S src/abacus -B build/abacus \
 -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$root/install/abacus" \
 -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DBUILD_TESTING=OFF -DGIT_SUBMODULE=OFF \
 -DENABLE_MPI=ON -DENABLE_OPENMP=ON -DENABLE_LCAO=ON -DENABLE_LIBRI=ON \
 -DENABLE_LIBXC=ON -DENABLE_ELPA=ON -DENABLE_JSON=ON -DENABLE_MLALGO=OFF \
 -DUSE_CUDA=ON -DUSE_CUDA_MPI=ON -DENABLE_CUSOLVERMP=ON -DENABLE_CUBLASMP=ON \
 -DENABLE_NCCL_PARALLEL_DEVICE=ON -DCMAKE_CUDA_ARCHITECTURES=70 \
 -DCMAKE_C_COMPILER="$CC" -DCMAKE_CXX_COMPILER="$CXX" -DCMAKE_CUDA_HOST_COMPILER="$CXX" \
 -DCMAKE_CXX_STANDARD=17 -DCMAKE_CXX_FLAGS='-march=znver3 -mtune=znver3' \
 -DCMAKE_C_FLAGS='-march=znver3 -mtune=znver3' \
 -DLIBRI_DIR="$root/src/LibRI" -DLIBCOMM_DIR="$root/imported-deps/LibComm-master" \
 -Dcereal_DIR="$root/imported-deps/cereal/lib/cmake/cereal" \
 -Dnlohmann_json_DIR="$root/imported-deps/json/share/cmake/nlohmann_json" \
 -DLibxc_DIR="$root/install/libxc/lib/cmake/Libxc" \
 -DLibDDLA_DIR="$root/install/ddla/lib/cmake/LibDDLA" -DELPA_DIR="$ELPA_ROOT" \
 -DFETCHCONTENT_FULLY_DISCONNECTED=ON -DFETCHCONTENT_UPDATES_DISCONNECTED=ON \
 > logs/abacus-configure.log 2>&1
cmake --build build/abacus --parallel 28 > logs/abacus-build.log 2>&1
cmake --install build/abacus > logs/abacus-install.log 2>&1
install/abacus/bin/abacus --info > logs/abacus-info.txt 2>&1
ldd install/abacus/bin/abacus > logs/abacus-ldd.txt
sha256sum install/abacus/bin/abacus > logs/abacus-sha256.txt
touch logs/abacus-complete
