#!/bin/bash
set -eo pipefail
set +u
source /etc/profile.d/lmod.sh
module purge
module use /opt/modules/modulefiles/devtools
module load cmake/3.31.6 openmpi/5.0.10-nvhpc26.3-gnu-cuda12-auto
module load fftw/3.3.10 saiblas/2603-gnu-auto elpa/2026.02.001-2603-gnu-auto
module load cuda/12.9.1 nvmplibs/26.7-tmp apptainer/1.4.4
export CC=/usr/bin/gcc CXX=/usr/bin/g++ FC=/usr/bin/gfortran
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=4
export SLURM_EXPORT_ENV=ALL
export OMPI_MCA_plm_slurm_args=--external-launcher PRTE_MCA_plm_slurm_args=--external-launcher
export CMAKE_LIBRARY_PATH=${LIBRARY_PATH:-} CMAKE_INCLUDE_PATH=${CPATH:-}
set -u
