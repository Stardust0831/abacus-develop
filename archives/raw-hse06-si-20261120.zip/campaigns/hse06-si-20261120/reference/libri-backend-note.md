# Installed ABACUS LibRI backend

The measured ABACUS CUDA module pins LibRI 2.1.1-b0eff7a. The frozen build recipe and dependency lock are recorded in `abacus-exchange-build.txt` and `abacus-frozen-dependencies.sh`; `abacus-build.txt` records the installed executable's `--info` output.

The downloaded archive from <https://codeload.github.com/abacusmodeling/LibRI/tar.gz/b0eff7a> has SHA256 `bee9df54e0d827942524640897c3a57c0c738d2db6b2d73a09ab6c054bef94ea`, matching the deployed dependency lock.

At ABACUS source commit `4e9f1636b7ca27d1dc634711915c18087654b911`, `source/source_lcao/module_ri/exx_lri.hpp` calls LibRI `cal_Hs` for exchange matrices and `cal_force` for exchange forces. The exact source is saved in `abacus-ri-source-2.txt` (calls at lines 915 and 1037).

In the matching LibRI archive, `include/RI/physics/Exx.hpp` implements these using `lri.cal_loop3`; `include/RI/ri/LRI-cal_loop3.hpp` uses OpenMP loops. The library BLAS interface calls ordinary Fortran BLAS (for example `dgemm_` in `include/RI/global/Blas_Interface.h`). Relevant files are retained next to this note. The archive's include files contain no CUDA, cuBLAS, HIPBLAS, MAGMA or DDLA backend.

Thus the exchange tensor contractions in this installed dependency use the CPU/OpenMP implementation. ABACUS's CUDA build can accelerate other supported portions of the calculation. GPU allocation counts in the report must be read together with CPU core counts; the measured scaling is not a comparison of pure GPU exchange kernels. No CPU-only baseline or alternative LibRI build was measured.
