#!/usr/bin/env python3
"""Stop only the duplicate work after the first Si216 ABACUS case succeeds."""
from pathlib import Path
import json
import subprocess
import time

root = Path(__file__).resolve().parent
original_job = '2652178'
repeat_job = '2652959'
original = root / 'results' / f'benchmark-g4-{original_job}'
repeat = root / 'results' / f'benchmark-g4-repeat-{repeat_job}'
deadline = time.monotonic() + 3600
last_state = None
while time.monotonic() < deadline:
    state = subprocess.check_output(['squeue','-h','-j',repeat_job,'-o','%T'],text=True).strip()
    if state != last_state:
        print(time.strftime('%FT%T%z'), 'repeat state', state or 'not queued', flush=True)
        last_state = state
    progress = original / 'progress.json'
    completed = json.loads(progress.read_text()) if progress.exists() else []
    first = next((r for r in completed if r['index'] == 5), None)
    if first is not None:
        if first['exitcode'] != 0:
            raise RuntimeError('First ABACUS Si216 case failed; do not cancel anything.')
        if state == 'RUNNING' or (repeat / 'complete.txt').exists():
            cancel = original_job
            reason = 'First Si216 ABACUS repeat complete; second repeat already running/completed in same-node job. Skip original duplicate and obsolete loose-force CP2K repeat.'
        elif state == 'PENDING':
            cancel = repeat_job
            reason = 'Replacement has not started; keep the original sequential second repeat.'
        else:
            cancel = None
            reason = 'Replacement not running; keep original campaign.'
        if cancel:
            subprocess.run(['scancel',cancel],check=True)
        result = {'cancelled_job':cancel,'reason':reason,'time':time.strftime('%FT%T%z'),
                  'successful_original_case':first}
        (root / 'scheduling-decision.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result),flush=True)
        break
    time.sleep(5)
else:
    raise RuntimeError('Monitoring limit reached; no cancellation performed.')
