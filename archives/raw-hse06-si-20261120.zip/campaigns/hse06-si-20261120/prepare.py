#!/usr/bin/env python3
"""Reproducible Si HSE06 inputs; all energies start from atomic densities."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
A = 5.431
MODULES = {
    "cp2k": "cp2k/master-beta-20261117-356586e108ea-rf678a701a42f-b0ffec6895ef1",
    "abacus": "abacus/develop-beta-20261116-4e9f1636b7ca-rf678a701a42f-b5b5f95b9e21c",
}

def positions(n):
    basis = [(0,0,0),(0,.5,.5),(.5,0,.5),(.5,.5,0),(.25,.25,.25),(.25,.75,.75),(.75,.25,.75),(.75,.75,.25)]
    return [tuple((p[d]+(i,j,k)[d])*A for d in range(3))
            for i in range(n) for j in range(n) for k in range(n) for p in basis]

def cp2k(n, radius=None, admm=True, cutoff=400, eps=1e-7, displaced=False):
    coords = positions(n)
    if displaced:
        coords[0] = (.01, .02, -.015)
    xyz = '\n'.join('      Si '+' '.join(f'{x:.12f}' for x in p) for p in coords)
    aux = '''    &AUXILIARY_DENSITY_MATRIX_METHOD
      METHOD BASIS_PROJECTION
      ADMM_PURIFICATION_METHOD MO_DIAG
    &END
''' if admm else ''
    auxkind = '      BASIS_SET AUX_FIT cFIT3\n' if admm else ''
    rad = f'          CUTOFF_RADIUS {radius}\n' if radius is not None else ''
    return f'''&GLOBAL
  PROJECT si{len(coords)}
  RUN_TYPE ENERGY_FORCE
  PRINT_LEVEL MEDIUM
&END
&FORCE_EVAL
  METHOD Quickstep
  &DFT
    BASIS_SET_FILE_NAME BASIS_MOLOPT
    BASIS_SET_FILE_NAME BASIS_ADMM
    POTENTIAL_FILE_NAME GTH_POTENTIALS
    &QS
      EPS_DEFAULT 1.0E-12
    &END
    &MGRID
      CUTOFF {cutoff}
      REL_CUTOFF 60
      NGRIDS 5
    &END
    &SCF
      EPS_SCF {eps}
      MAX_SCF 100
      SCF_GUESS ATOMIC
      &OT
        MINIMIZER DIIS
        PRECONDITIONER FULL_SINGLE_INVERSE
      &END
      &OUTER_SCF
        EPS_SCF {eps}
        MAX_SCF 10
      &END
      &PRINT
        &RESTART OFF
        &END
      &END
    &END
{aux}    &XC
      &XC_FUNCTIONAL
        &PBE
          SCALE_X 0.0
          SCALE_C 1.0
        &END
        &XWPBE
          SCALE_X -0.25
          SCALE_X0 1.0
          OMEGA 0.11
        &END
      &END
      &HF
        FRACTION 0.25
        &INTERACTION_POTENTIAL
          POTENTIAL_TYPE SHORTRANGE
          OMEGA 0.11
{rad}        &END
        &SCREENING
          EPS_SCHWARZ 1.0E-6
          SCREEN_ON_INITIAL_P FALSE
        &END
        &MEMORY
          MAX_MEMORY 8000
          EPS_STORAGE_SCALING 0.1
        &END
      &END
    &END
  &END
  &SUBSYS
    &CELL
      ABC {n*A:.12f} {n*A:.12f} {n*A:.12f}
      PERIODIC XYZ
    &END
    &COORD
{xyz}
    &END
    &KIND Si
      ELEMENT Si
      BASIS_SET DZVP-MOLOPT-SR-GTH
{auxkind}      POTENTIAL GTH-PBE-q4
    &END
  &END
  &PRINT
    &FORCES ON
    &END
  &END
&END
'''

def abacus(n, solver='cusolvermp', separate=False, cutoff=100, thr=1e-8, displaced=False):
    coords=positions(n)
    if displaced:
        coords[0]=(.01,.02,-.015)
    xyz='\n'.join(' '.join(f'{x/(n*A):.12f}' for x in p)+' 0 0 0' for p in coords)
    stru=f'''ATOMIC_SPECIES
Si 28.0855 Si.upf

NUMERICAL_ORBITAL
Si_gga_7au_100Ry_2s2p1d.orb

LATTICE_CONSTANT
1.8897261246257702

LATTICE_VECTORS
{n*A:.12f} 0 0
0 {n*A:.12f} 0
0 0 {n*A:.12f}

ATOMIC_POSITIONS
Direct
Si
0.0
{len(coords)}
{xyz}
'''
    inp=f'''INPUT_PARAMETERS
suffix si
calculation scf
ntype 1
basis_type lcao
device gpu
ks_solver {solver}
precision double
gamma_only 1
symmetry -1
nspin 1
nbands {2*len(coords)}
dft_functional hse
exx_erfc_alpha 0.25
exx_erfc_omega 0.11
exx_separate_loop {int(separate)}
exx_hybrid_step 100
exx_pca_threshold 1e-4
exx_c_threshold 1e-4
exx_v_threshold 1e-4
exx_dm_threshold 1e-4
ecutwfc {cutoff}
scf_thr {thr}
scf_nmax 150
smearing_method fixed
mixing_type broyden
mixing_beta 0.4
mixing_ndim 8
cal_force 1
cal_stress 0
init_chg atomic
out_chg 0
out_wfc_lcao 0
out_mul 0
'''
    return inp,stru

def staged_cp2k(n,radius,cutoff=400,eps=1e-7,displaced=False,screen=True,gap=None):
    hse=cp2k(n,radius,cutoff=cutoff,eps=eps,displaced=displaced)
    hse=hse.replace('PRECONDITIONER FULL_SINGLE_INVERSE','PRECONDITIONER FULL_ALL')
    hse=hse.replace('SCF_GUESS ATOMIC','SCF_GUESS RESTART')
    hse=hse.replace('    POTENTIAL_FILE_NAME GTH_POTENTIALS',f'    POTENTIAL_FILE_NAME GTH_POTENTIALS\n    WFN_RESTART_FILE_NAME si{8*n**3}-RESTART.wfn')
    if screen:
        hse=hse.replace('SCREEN_ON_INITIAL_P FALSE','SCREEN_ON_INITIAL_P TRUE')
    pbe=cp2k(n,radius,admm=False,cutoff=cutoff,eps=1e-6,displaced=displaced)
    pbe=pbe.replace('PRECONDITIONER FULL_SINGLE_INVERSE','PRECONDITIONER FULL_ALL')
    pbe=pbe.replace('RUN_TYPE ENERGY_FORCE','RUN_TYPE ENERGY').replace('&RESTART OFF','&RESTART ON')
    start=pbe.index('    &XC\n');end=pbe.index('  &END\n  &SUBSYS')
    pbe=pbe[:start]+'    &XC\n      &XC_FUNCTIONAL PBE\n      &END\n    &END\n'+pbe[end:]
    if gap is not None:
        hse=hse.replace('PRECONDITIONER FULL_ALL',f'PRECONDITIONER FULL_ALL\n        ENERGY_GAP {gap}')
        pbe=pbe.replace('PRECONDITIONER FULL_ALL',f'PRECONDITIONER FULL_ALL\n        ENERGY_GAP {gap}')
    return hse,pbe

if __name__ == '__main__':
    for n in (2,3,4):
        for tag, radius in [('auto',None),('r8',8.0),('r6',6.0),('r5',5.0),('r4',4.0)]:
            p=ROOT/'inputs'/f'cp2k-si{8*n**3}-{tag}'
            p.mkdir(parents=True,exist_ok=True)
            (p/'input.inp').write_text(cp2k(n,radius))
        for radius in (4,5,6,8):
            for label,gap in [('staged',None),('fast',0.001)]:
                p=ROOT/'inputs'/f'cp2k-si{8*n**3}-r{radius}-{label}'
                p.mkdir(parents=True,exist_ok=True)
                hse,pbe=staged_cp2k(n,radius,gap=gap)
                (p/'input.inp').write_text(hse)
                (p/'pbe.inp').write_text(pbe)
        for solver in ('cusolver','cusolvermp'):
            for separate in (False,True):
                p=ROOT/'inputs'/f'abacus-si{8*n**3}-{solver}-loop{int(separate)}'
                p.mkdir(parents=True,exist_ok=True)
                inp,stru=abacus(n,solver,separate)
                (p/'INPUT').write_text(inp)
                (p/'STRU').write_text(stru)
                (p/'KPT').write_text('K_POINTS\n0\nGamma\n1 1 1 0 0 0\n')
    (ROOT/'modules.json').write_text(json.dumps(MODULES,indent=2)+'\n')
