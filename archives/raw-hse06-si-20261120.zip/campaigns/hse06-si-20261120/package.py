#!/usr/bin/env python3
"""Package the final runnable inputs and retain separate full raw evidence."""
from pathlib import Path
import hashlib
import json
import tarfile
from fnmatch import fnmatch

root = Path(__file__).resolve().parent
requests = [f'{kind}-g{g}.json' for g in [1,4,16] for kind in ['force-benchmark','abacus-final']]
names = sorted({case['input'] for name in requests
                for case in json.loads((root/name).read_text())['cases']})
source_hashes = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
                 for directory in [root/'data']+[root/'inputs'/name for name in names]
                 for p in sorted(directory.rglob('*')) if p.is_file()}
(root/'input-sha256-final.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
files = requests + ['campaign.py','run-case.sh','reproduce.sbatch','analyze.py','report.py',
                    'validate.py','modules.json','manifest.json','input-sha256-final.json',
                    'README-REPRODUCE.md','PLAN.md']
with tarfile.open(root/'reproduce-inputs.tar.gz','w:gz') as tf:
    for name in files: tf.add(root/name,arcname=name)
    tf.add(root/'data',arcname='data')
    for name in names: tf.add(root/'inputs'/name,arcname='inputs/'+name)

evidence = ['results','REPORT.md','PLAN.md','summary.json','summary.csv','aggregate.json',
            'manifest.json','validation.json','executed-input-sha256.json',
            'slurm-accounting.psv','scheduling-decision.json','timing.png','timing.svg']
with tarfile.open(root/'evidence.tar.gz','w:gz') as tf:
    for name in evidence:
        p=root/name
        if p.exists():tf.add(p,arcname=name,filter=lambda info: None if any(fnmatch(Path(info.name).name,pattern) for pattern in ['*.wfn*','*.restart*','*.npy','*.npz','*.cube']) else info)
    for p in sorted((root/'reference').iterdir()):
        if p.is_file() and p.name not in ['APNS-v1.zip','LibRI-GPU-Backend.h']:
            tf.add(p,arcname='reference/'+p.name)

artifacts=['reproduce-inputs.tar.gz','evidence.tar.gz','REPORT.md','summary.csv','summary.json',
           'aggregate.json','validation.json','timing.png','timing.svg']
(root/'SHA256SUMS').write_text(''.join(hashlib.sha256((root/name).read_bytes()).hexdigest()+'  '+name+'\n' for name in artifacts))
with tarfile.open(root/'reproduce-inputs.tar.gz') as tf:
    members=tf.getnames()
    assert all(not Path(p).is_absolute() and '..' not in Path(p).parts for p in members)
    assert all(name in members for name in files)
    assert all('inputs/'+name+'/input.inp' in members or 'inputs/'+name+'/INPUT' in members for name in names)
print('Packaged final inputs and raw evidence; hashes in SHA256SUMS.')
