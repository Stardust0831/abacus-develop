# Reproduce the Si HSE06 benchmark

Extract `reproduce-inputs.tar.gz` into a fresh directory on SAI and submit from that directory:

```bash
sbatch reproduce.sbatch
sbatch --qos=flood-gpu --ntasks=4 --gpus-per-node=4 reproduce.sbatch
sbatch --qos=flood-gpu --ntasks=16 --gpus-per-node=16 reproduce.sbatch
```

All requests use partition `16V100`, account `proj-sai-hpc-software`, one MPI rank and four OpenMP threads per GPU. The script reserves three hours to accommodate sequential repeats. Each job runs both programs on its allocated node: 1 GPU covers Si64; 4 GPUs cover Si64 and Si216; 16 GPUs cover Si216. Every program/size/resource combination is repeated twice from independent input directories.

The fixed CP2K and ABACUS modules and SAI rank-mapping script are required. `run-case.sh` records the loaded modules, per-stage wall times and exit status. CP2K first generates a PBE wavefunction and then performs the HSE energy/force calculation. Both stages are timed. ABACUS includes its internal initial GGA convergence. The APNS pseudopotential and orbital are included in `data/`.

After all three jobs finish, extract and review their evidence:

```bash
python3 analyze.py
python3 validate.py
python3 report.py
```

Analysis requires Python 3; plotting additionally requires Matplotlib. `results/` contains each executed input after solver substitutions, full output, forces, timing and resource allocation. `summary.csv` provides per-case measurements and `aggregate.json` provides medians and ranges.

`manifest.json` and `PLAN.md` record the original experiment and its fixed versions. Each reproduced job records its own job number and allocation under `results/`.

This reproduces the main timing configurations. The original radius, screening and displaced-atom precision probes, together with their raw outputs, remain in the full benchmark directory at `/org/org-open-sai/proj-sai-hpc-software/runtime-tests/hse06-si-20261120`. The original report distinguishes ADMM, finite exchange radii and RI screening from full numerical convergence.
