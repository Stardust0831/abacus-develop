#!/usr/bin/env python3
"""Download small raw evidence; wavefunction/charge restarts stay on SAI."""
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parent
remote='/org/org-open-sai/proj-sai-hpc-software/runtime-tests/hse06-si-20261120'
command=f"cd {remote} && tar --exclude='*.wfn*' --exclude='*.restart*' --exclude='*.npy' --exclude='*.npz' --exclude='*.cube' -cf - results"
source=subprocess.Popen(['tssh','-T','SAI-stardust',command],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
result=subprocess.run(['tar','-C',str(root),'-xf','-'],stdin=source.stdout)
source.stdout.close()
error=source.stderr.read().decode(errors='replace')
status=source.wait()
if status not in (0,1) or result.returncode:
    raise RuntimeError((status,result.returncode,error))
if error:print(error)
subprocess.run(['python3',str(root/'analyze.py')],check=True)
