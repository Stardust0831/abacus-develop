#!/bin/bash
#SBATCH --job-name=hse-si-cp2k-pilot
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-gpu
#SBATCH --nodes=1
#SBATCH --ntasks=4
#SBATCH --gpus-per-node=4
#SBATCH --time=00:45:00
#SBATCH --export=ALL
set -eo pipefail
root=$PWD
source /etc/profile.d/lmod.sh
module purge
module use /home/stardust/sai-hpc-software/modulefiles/apps
module load cp2k/master-beta-20261117-356586e108ea-rf678a701a42f-b0ffec6895ef1
source /opt/sai/runtime/mps_mapping.d/16V100.bash
export OMP_NUM_THREADS=4 OMP_PLACES=cores OMP_PROC_BIND=close OMP_DYNAMIC=FALSE
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_EXPORT_ENV=ALL
export OMPI_MCA_plm_slurm_args=--external-launcher PRTE_MCA_plm_slurm_args=--external-launcher
out=$root/results/pilot-$SLURM_JOB_ID
mkdir -p "$out"
module -t list > "$out/modules.txt" 2>&1
scontrol show job -o "$SLURM_JOB_ID" > "$out/allocation.txt"
lscpu > "$out/lscpu.txt"
nvidia-smi -q > "$out/nvidia-smi.txt"
mpirun -np 1 --map-by ppr:1:node:pe=4 cp2k.psmp --version > "$out/cp2k-version.txt" 2>&1
for case in cp2k-si64-r4 cp2k-si64-r5 cp2k-si216-r6 cp2k-si216-r8; do
  mkdir -p "$out/$case"
  cp "$root/inputs/$case/input.inp" "$out/$case/"
  cd "$out/$case"
  date -Is > started.txt
  /usr/bin/time -v -o time.txt timeout 900 mpirun -np 4 --map-by "$MAP_OPT" --bind-to core cp2k.psmp -i input.inp -o output.log > launcher.log 2>&1
  date -Is > finished.txt
done
