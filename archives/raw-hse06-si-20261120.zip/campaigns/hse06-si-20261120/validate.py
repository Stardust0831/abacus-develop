#!/usr/bin/env python3
"""Validate completed benchmark evidence, not the accuracy of either method."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import math
import re

root = Path(__file__).resolve().parent
rows = json.loads((root / 'summary.json').read_text())
selected = [r for r in rows if r['complete'] and
            ((r['case'].startswith('benchmark-g') and r['program'] == 'abacus')
             or r['case'].startswith('force-benchmark-g'))]
groups = defaultdict(list)
hashes = {}
for r in selected:
    key = (r['atoms'], r['ranks'], r['program'])
    groups[key].append(r)
    d = root / 'results' / r['case']
    assert r['complete'] and r['exitcode'] == 0, r['case']
    assert r['force_count'] == r['atoms'], r['case']
    assert all(math.isfinite(x) for f in r['forces_ev_A'] for x in f)
    assert r['workflow_wall_s'] > 0 and r['workflow_scf_s'] > 0
    allocation = (d.parent / 'allocation.txt').read_text()
    assert 'Partition=16V100 ' in allocation
    assert f'NumCPUs={8*r["ranks"]} ' in allocation
    assert f'gres/gpu={r["ranks"]}' in allocation
    env = json.loads((d.parent / 'environment.json').read_text())
    assert env['SLURM_JOB_PARTITION'] == '16V100'
    if r['program'] == 'cp2k':
        assert r['eps_schwarz_forces'] == 1e-6
        assert r['max_memory_MiB_per_rank'] == 8000
        assert r['eri_on_the_fly'] == 0
        assert not r['cell_radius_warning']
        assert r['pbe_iterations'] == 8 and r['hse_iterations'] > 0
        assert json.loads((d / 'time-pbe.json').read_text())['exitcode'] == 0
        assert '356586e108' in (d / 'output.log').read_text()
        names = ['input.inp', 'pbe.inp']
    else:
        assert r['solver'] == ('cusolver' if r['ranks'] == 1 else 'elpa')
        assert r['separate_loop'] == 0
        assert r['pbe_iterations'] == 12 and r['hse_iterations'] > 0
        assert '4e9f1636b7ca' in (d / 'modules.txt').read_text()
        names = ['INPUT', 'STRU', 'KPT', 'Si.upf', 'Si_gga_7au_100Ry_2s2p1d.orb']
    for name in names:
        p = d / name
        hashes[str(p.relative_to(root))] = hashlib.sha256(p.read_bytes()).hexdigest()

expected = {(n,g,p) for n,g in [(64,1),(64,4),(216,4),(216,16)] for p in ['cp2k','abacus']}
assert set(groups) == expected, sorted(groups)
for key, rr in groups.items():
    assert len(rr) == 2, (key, len(rr))
    assert abs(rr[0]['energy_ev'] - rr[1]['energy_ev']) / key[0] < 1e-7
    assert rr[0]['node'] == rr[1]['node']
structure_deltas = {}
for n,g in [(64,1),(64,4),(216,4),(216,16)]:
    c = groups[(n,g,'cp2k')][0]
    a = groups[(n,g,'abacus')][0]
    assert c['node'] == a['node']
    cp = (root / 'results' / c['case'] / 'input.inp').read_text()
    ab = (root / 'results' / a['case'] / 'STRU').read_text()
    cell = float(re.search(r'ABC\s+([\d.]+)', cp)[1])
    cc = [list(map(float, line.split()[1:])) for line in cp.split('&COORD')[1].split('&END')[0].splitlines() if line.strip().startswith('Si ')]
    ac = [list(map(float, line.split()[:3])) for line in ab.split('ATOMIC_POSITIONS')[1].splitlines()[5:] if line.strip()]
    assert len(cc) == len(ac) == n
    max_delta = max(abs(x - cell*y) for f,h in zip(cc,ac) for x,y in zip(f,h))
    assert max_delta < 1e-9, max_delta
    structure_deltas[f'Si{n}-g{g}'] = max_delta

parallel_consistency = {}
for n in [64,216]:
    for program in ['cp2k','abacus']:
        rr = [r for r in selected if r['atoms']==n and r['program']==program]
        energy_delta = (max(r['energy_ev'] for r in rr)-min(r['energy_ev'] for r in rr))/n
        force_delta = max(math.sqrt(sum((x-y)**2 for x,y in zip(f,h)))
                          for r in rr for f,h in zip(rr[0]['forces_ev_A'],r['forces_ev_A']))
        assert energy_delta < 1e-7, (n,program,energy_delta)
        assert force_delta < 1e-5, (n,program,force_delta)
        parallel_consistency[f'{program}-Si{n}'] = {'energy_spread_eV_atom':energy_delta,
                                                  'max_force_delta_eV_A':force_delta}

result = {'passed': True, 'cases': len(selected), 'groups': len(groups),
          'repeats_per_group': 2, 'partition': '16V100',
          'max_coordinate_difference_A': structure_deltas,
          'parallel_consistency': parallel_consistency,
          'checks': ['SCF convergence and exit status', 'force count and finite values',
                     'matched partition, node and resource allocation',
                     'final force threshold and no repeated ERI calculation',
                     'repeat energy agreement', 'matching Si positions',
                     'energy and force consistency across MPI counts'],
          'scope': 'Evidence consistency; does not establish equal numerical accuracy.'}
(root / 'validation.json').write_text(json.dumps(result, indent=2)+'\n')
(root / 'executed-input-sha256.json').write_text(json.dumps(hashes, indent=2)+'\n')
print(json.dumps(result, indent=2))
