#!/bin/bash
#SBATCH --job-name=si-hse06-final
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-1o2gpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gpus-per-node=1
#SBATCH --time=03:00:00
#SBATCH --export=ALL
set -eo pipefail
ranks=${SLURM_NTASKS:?}
case "$ranks" in 1|4|16) ;; *) echo 'Use 1, 4, or 16 MPI ranks, one per GPU.' >&2; exit 2 ;; esac
source /opt/sai/runtime/mps_mapping.d/16V100.bash
python3 -u campaign.py "force-benchmark-g${ranks}.json"
python3 -u campaign.py "abacus-final-g${ranks}.json"
