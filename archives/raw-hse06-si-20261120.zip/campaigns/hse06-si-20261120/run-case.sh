#!/bin/bash
set -eo pipefail
program=$1
case_dir=$2
ranks=$3
source /etc/profile.d/lmod.sh
module purge
module use /home/stardust/sai-hpc-software/modulefiles/apps
case "$program" in
  cp2k) module load cp2k/master-beta-20261117-356586e108ea-rf678a701a42f-b0ffec6895ef1 ;;
  abacus) module load abacus/develop-beta-20261116-4e9f1636b7ca-rf678a701a42f-b5b5f95b9e21c ;;
  *) exit 2 ;;
esac
export OMP_NUM_THREADS=4 OMP_PLACES=cores OMP_PROC_BIND=close OMP_DYNAMIC=FALSE
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_EXPORT_ENV=ALL
export OMPI_MCA_plm_slurm_args=--external-launcher PRTE_MCA_plm_slurm_args=--external-launcher
cd "$case_dir"
module -t list > modules.txt 2>&1
if [[ "$program" == cp2k ]]; then
  if [[ -f pbe.inp ]]; then
    /usr/bin/time -f '{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kb":%M,"exitcode":%x}' -o time-pbe.json timeout 3600 mpirun -np "$ranks" --map-by "ppr:$ranks:node:pe=4" --bind-to core cp2k.psmp -i pbe.inp -o pbe.log > pbe-launcher.log 2>&1
  fi
  command=(cp2k.psmp -i input.inp -o output.log)
else
  command=(abacus)
fi
set +e
/usr/bin/time -f '{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kb":%M,"exitcode":%x}' -o time.json timeout 3600 mpirun -np "$ranks" --map-by "ppr:$ranks:node:pe=4" --bind-to core "${command[@]}" > launcher.log 2>&1
status=$?
echo "$status" > exitcode.txt
exit "$status"
