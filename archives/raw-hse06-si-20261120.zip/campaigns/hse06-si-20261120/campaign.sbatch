#!/bin/bash
#SBATCH --job-name=hse-si-campaign
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-1o2gpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gpus-per-node=1
#SBATCH --time=01:30:00
#SBATCH --export=ALL
set -eo pipefail
source /opt/sai/runtime/mps_mapping.d/16V100.bash
python3 -u campaign.py "$1"
