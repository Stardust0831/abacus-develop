# Si HSE06 on SAI 16V100 — 2026-11-20

User requested the latest accepted CP2K/ABACUS branch modules, CP2K DZVP-MOLOPT-SR-GTH with ADMM allowed, and ABACUS APNS efficiency LCAO. Only 16V100 is used.

Both programs use identical diamond Si structures (a = 5.431 Å), Gamma-only sampling, four valence electrons per atom, zero spin, fixed occupations, HSE06 (25% erfc screened exchange, omega = 0.11 bohr^-1), and single-point energy plus forces starting from atomic density. This is a finite-supercell efficiency test, not a converged primitive-cell k-mesh material-property benchmark. Absolute total energies across different pseudopotentials are not comparable.

Pilot: 64 and 216 atoms. Use CP2K radii 4/5 Å for Si64 and 6/8 Å for Si216; these satisfy the half-cell constraint. The initial default-radius run was cancelled, as the automatic radius was 14.279 Å. ABACUS uses the APNS recommended 100 Ry, 7-bohr 2s2p1d orbitals and its paired Si pseudopotential. Compare simultaneous and separate EXX loops before choosing the benchmark configuration.

Resource allocation: one MPI process per V100, four OpenMP threads per process, system rank mapping. Compare 1 and 4 GPUs where runtime permits. Reserve and report 4 physical CPU cores per GPU. Each program may select its suitable eigensolver. Repeat from fresh inputs; record process wall time, program total time, iterations, SCF time, energy, and force checks. Container version startup and the first scientific run will be identified separately from warmed startup repeats.

Precision checks are within each method. Convergence metrics differ between codes; the same numeric SCF threshold does not imply equal accuracy. Do not describe results as equal-basis or equal-accuracy performance without independent evidence.


## Adjustments justified by pilot evidence

- ABACUS separate EXX loop was slower on Si64 (366.82 s program time vs 278.66 s), with energy agreeing to 1.5e-11 eV. Select `exx_separate_loop 0`.
- ABACUS ELPA GPU solver reduced Si64 program time to 234.44 s from cuSOLVERMp 278.66 s; same final energy. Select ELPA for multi-GPU; cuSOLVER for 1 GPU.
- CP2K PBE initial guess uses diagonalization + Broyden mixing. It converged in 8 steps vs over 100 with atomic-guess OT. HSE uses FULL_ALL OT DIIS with ENERGY_GAP 0.001.
- CP2K SCREEN_ON_INITIAL_P uses the PBE restart density. On/off check at r5 changed total Si64 energy by 0.000994 eV (0.0155 meV/atom), and reduces HSE initialization cost. It remains an explicit screening approximation.
- CP2K 4/5 Å Si64 comparison differs by 1.746 meV/atom. Select 5 Å on Si64 and assess 6/8 Å on Si216. Both selected radii fit inside half the respective supercell length. CP2K warns these are shorter than its kernel-tail screening radius (14.279 Å), so these remain truncated HSE approximations.
- CP2K MAX_MEMORY initially 2000 MiB/rank caused on-the-fly ERI recomputation on Si216/4 GPUs. Increase future inputs to 8000 MiB/rank within 15 GiB/GPU host memory allocation; preserve every executed input under its result directory. Templates changed on 2026-11-20 around 20:57 Asia/Shanghai. Si64/4 and Si216/16 already stored all ERIs under the old cap; repeat behavior must be checked before pooling.
- Formal benchmarks use two repeats with reversed program order. The 1-GPU memory check repeats CP2K on the same node (`16v100n10`). Do not use cancelled or incomplete pilots in timing medians.


## Force accuracy correction

The displaced Si64 probe found a 0.025938 eV/Å maximum force-vector difference between the original CP2K settings and the tighter reference. Tightening only EPS_SCHWARZ_FORCES from its default 1e-4 to 1e-6 reduces the difference against the tight reference to 0.0009863 eV/Å; the total energy changes by only 2.2e-7 eV. Final CP2K timing must therefore use the explicit 1e-6 force threshold. These new `force-benchmark-g*` jobs each run twice on the same node as the corresponding ABACUS benchmark. Earlier default-force timings are exploratory and excluded from the final table.


## Completed numerical probes

- Si216 CP2K radius 6 to 8 A changed the energy by 0.00482493 meV/atom; both use the same staged PBE seed. This is a finite-radius sensitivity check at the tested thresholds, not proof of convergence to the untruncated kernel.
- Displaced ABACUS 100/150 Ry plus SCF/RI-threshold tightening changed energy by 1.043275 meV/atom and the maximum force vector by about 0.000013 eV/A. Retain the APNS-recommended 100 Ry baseline.
- The final CP2K force-threshold repeats run separately from the earlier interleaved campaign. Same-node pairing is retained; 1/4-GPU allocations share the node with other jobs.


## Same-node scheduling overlap

- Job 2652959 runs only the second Si216/4-GPU ABACUS repeat on 16v100n14, starting at about 21:32. It overlaps the first repeat in 2652178 after CP2K releases its four GPUs.
- `finish-overlap.py` waits for the original Si216 ABACUS case (index 5) to finish successfully. If the replacement is running/completed, it cancels only 2652178 to skip its duplicate ABACUS case and obsolete loose-force CP2K case. It writes `scheduling-decision.json`. Successful per-case outputs remain valid even when the enclosing campaign is subsequently cancelled.
- If the replacement were still pending, the watcher would instead cancel only the pending replacement and leave the original sequential repeats running.


## Final workflow accuracy confirmation

Job 2653188 repeats the displaced Si64 probe using the exact final timing workflow (diagonalization/Broyden PBE seed, 8000 MiB/rank, force Schwarz 1e-6). It completed in 148.86 s including initialization, with 10 PBE and 9 HSE iterations. Relative to the existing tight reference, the energy difference is 0.3813376 meV/atom and maximum force-vector difference is 0.001000287 eV/A. This confirms the earlier force-threshold finding for the actual timed workflow; it does not establish ADMM/basis/pseudopotential convergence.
