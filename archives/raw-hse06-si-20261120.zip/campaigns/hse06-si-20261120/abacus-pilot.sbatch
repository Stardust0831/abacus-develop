#!/bin/bash
#SBATCH --job-name=hse-si-abacus-pilot
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-gpu
#SBATCH --nodes=1
#SBATCH --ntasks=4
#SBATCH --gpus-per-node=4
#SBATCH --time=00:45:00
#SBATCH --export=ALL
set -eo pipefail
root=$PWD
source /etc/profile.d/lmod.sh
module purge
module use /home/stardust/sai-hpc-software/modulefiles/apps
module load abacus/develop-beta-20261116-4e9f1636b7ca-rf678a701a42f-b5b5f95b9e21c
source /opt/sai/runtime/mps_mapping.d/16V100.bash
export OMP_NUM_THREADS=4 OMP_PLACES=cores OMP_PROC_BIND=close OMP_DYNAMIC=FALSE
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_EXPORT_ENV=ALL
export OMPI_MCA_plm_slurm_args=--external-launcher PRTE_MCA_plm_slurm_args=--external-launcher
out=$root/results/abacus-pilot-$SLURM_JOB_ID
mkdir -p "$out"
module -t list > "$out/modules.txt" 2>&1
scontrol show job -o "$SLURM_JOB_ID" > "$out/allocation.txt"
lscpu > "$out/lscpu.txt"
nvidia-smi -q > "$out/nvidia-smi.txt"
for case in abacus-si64-cusolvermp-loop0 abacus-si64-cusolvermp-loop1 abacus-si216-cusolvermp-loop0; do
  mkdir -p "$out/$case"
  cp "$root/inputs/$case/"* "$out/$case/"
  cp "$root/data/"* "$out/$case/"
  cd "$out/$case"
  date -Is > started.txt
  set +e
  /usr/bin/time -v -o time.txt timeout 900 mpirun -np 4 --map-by "$MAP_OPT" --bind-to core abacus > output.log 2>&1
  rc=$?
  set -e
  echo "$rc" > exitcode.txt
  date -Is > finished.txt
  if [ "$rc" != 0 ]; then exit "$rc"; fi
done
