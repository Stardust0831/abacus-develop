#!/usr/bin/env python3
"""Run declared cases sequentially inside a single allocation, preserving failures."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
spec=json.loads((root/sys.argv[1]).read_text())
out=root/'results'/f'{spec["name"]}-{os.environ["SLURM_JOB_ID"]}'
out.mkdir(parents=True,exist_ok=False)
shutil.copy2(root/sys.argv[1],out/'request.json')
for name,cmd in [('allocation.txt',['scontrol','show','job','-o',os.environ['SLURM_JOB_ID']]),
                 ('lscpu.txt',['lscpu']),('gpu.txt',['nvidia-smi','-q'])]:
    with (out/name).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
(out/'environment.json').write_text(json.dumps({k:v for k,v in os.environ.items() if k.startswith(('SLURM_','CUDA_','OMP_'))},indent=2))
results=[]
for index,item in enumerate(spec['cases']):
    source=root/'inputs'/item['input']
    dest=out/f'{index:02d}-{item["input"]}'
    shutil.copytree(source,dest)
    if item['program']=='abacus':
        for p in (root/'data').iterdir():shutil.copy2(p,dest/p.name)
    if 'replace' in item:
        p=dest/('INPUT' if item['program']=='abacus' else 'input.inp')
        s=p.read_text()
        for a,b in item['replace'].items():
            assert a in s,(a,p)
            s=s.replace(a,b)
        p.write_text(s)
    start=time.time()
    print('START',dest.name,time.strftime('%FT%T%z'),flush=True)
    with (dest/'driver.log').open('w') as f:
        proc=subprocess.run(['bash',str(root/'run-case.sh'),item['program'],str(dest),str(spec['ranks'])],stdout=f,stderr=subprocess.STDOUT)
    result=dict(item,index=index,exitcode=proc.returncode,driver_wall_s=time.time()-start,path=str(dest),start_unix=start)
    results.append(result)
    (out/'progress.json').write_text(json.dumps(results,indent=2)+'\n')
    print('END',dest.name,proc.returncode,round(result['driver_wall_s'],2),flush=True)
    if proc.returncode and not spec.get('continue_on_failure',False):sys.exit(proc.returncode)
(out/'complete.txt').write_text(time.strftime('%FT%T%z')+'\n')
