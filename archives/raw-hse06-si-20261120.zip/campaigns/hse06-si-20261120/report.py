#!/usr/bin/env python3
"""Build a report and standalone plot from completed scientific calculations."""
from collections import defaultdict
from pathlib import Path
import json
import math
import statistics

ROOT=Path(__file__).resolve().parent
rows=json.loads((ROOT/'summary.json').read_text())
groups=defaultdict(list)
for r in rows:
    if not r['complete']:continue
    name=r['case']
    if name.startswith('benchmark-g') and r['program']=='abacus':
        groups[(r['atoms'],r['ranks'],r['program'])].append(r)
    elif name.startswith('force-benchmark-g'):
        groups[(r['atoms'],r['ranks'],'cp2k')].append(r)

aggregate={}
for k,rr in groups.items():
    fields=['workflow_wall_s','workflow_program_s','workflow_scf_s','exx_force_s','energy_ev']
    aggregate[k]={f:statistics.median(x[f] for x in rr) for f in fields if all(x.get(f) is not None for x in rr)}
    aggregate[k]['repeats']=len(rr)
    aggregate[k]['wall_min_s']=min(x['workflow_wall_s'] for x in rr)
    aggregate[k]['wall_max_s']=max(x['workflow_wall_s'] for x in rr)
    aggregate[k]['energy_spread_meV_atom']=1000*(max(x['energy_ev'] for x in rr)-min(x['energy_ev'] for x in rr))/k[0]
    aggregate[k]['cases']=[x['case'] for x in rr]
    aggregate[k]['nodes']=sorted({x['node'] for x in rr})
    aggregate[k]['allocated_gpu_hours']=k[1]*aggregate[k]['workflow_wall_s']/3600
    aggregate[k]['pbe_iterations']=sorted({x['pbe_iterations'] for x in rr})
    aggregate[k]['hse_iterations']=sorted({x['hse_iterations'] for x in rr})

expected={(n,g,p) for n,g in [(64,1),(64,4),(216,4),(216,16)] for p in ['cp2k','abacus']}
finished=set(groups)==expected and all(a['repeats']==2 for a in aggregate.values())
ratios=[aggregate[(n,g,'abacus')]['workflow_wall_s']/aggregate[(n,g,'cp2k')]['workflow_wall_s']
        for n,g in [(64,1),(64,4),(216,4),(216,16)]
        if (n,g,'abacus') in aggregate and (n,g,'cp2k') in aggregate]
decision_path=ROOT/'scheduling-decision.json'
decision=json.loads(decision_path.read_text()) if decision_path.exists() else {}
overlap_note=('Si216四卡ABACUS的第二次重复独立调度在同一节点，以缩短等待。原批处理在第一轮成功退出后取消冗余后续计算；因此批处理整体的CANCELLED状态不表示其中已完成的第一轮算例失败，逐例退出码和完整输出是判断依据。调度决定保存在 `scheduling-decision.json`。'
              if decision.get('cancelled_job')=='2652178' else
              'Si216四卡ABACUS的独立第二轮重复调度过程记录在 `PLAN.md`；最终作业状态以 `manifest.json` 和Slurm记录为准。')

audit=[]
by_case={r['case']:r for r in rows}
def compare(title,aname,bname):
    a=by_case.get(aname);b=by_case.get(bname)
    if not a or not b or not a['complete'] or not b['complete']:return
    assert a['atoms']==b['atoms']
    fd=[math.sqrt(sum((u-v)**2 for u,v in zip(f,g))) for f,g in zip(a['forces_ev_A'],b['forces_ev_A'])]
    audit.append({'comparison':title,'energy_meV_atom':1000*abs(a['energy_ev']-b['energy_ev'])/a['atoms'],
                  'max_force_delta_ev_A':max(fd),'rms_force_delta_ev_A':math.sqrt(sum(x*x for x in fd)/len(fd)),
                  'a':aname,'b':bname})

compare('CP2K Si64：4 Å → 5 Å','four-staged-2651966/00-cp2k-si64-r4-staged','four-staged-2651966/01-cp2k-si64-r5-staged')
compare('CP2K Si216：6 Å → 8 Å','four-staged-2651966/03-cp2k-si216-r6-staged','four-staged-2651966/04-cp2k-si216-r8-staged')
compare('CP2K：初猜密度筛选开 → 关','fast-check-2652004/00-cp2k-si64-r5-fast','fast-check-2652004/01-cp2k-si64-r5-fast')
compare('CP2K 扰动 Si64：常规 → 严格参数','precision-check-2652081/00-cp2k-si64-displaced-normal','precision-check-2652081/01-cp2k-si64-displaced-tight')
compare('ABACUS 扰动 Si64：常规 → 严格参数','precision-check-2652081/02-abacus-si64-displaced-normal','precision-check-2652081/03-abacus-si64-displaced-tight')
compare('CP2K 扰动 Si64：仅收紧力积分筛选','precision-check-2652081/00-cp2k-si64-displaced-normal','force-grid-check-2652301/00-cp2k-si64-displaced-force')
compare('CP2K 扰动 Si64：仅提高网格截断','precision-check-2652081/00-cp2k-si64-displaced-normal','force-grid-check-2652301/01-cp2k-si64-displaced-grid')
compare('CP2K 最终力筛选 → 严格参数','force-grid-check-2652301/00-cp2k-si64-displaced-force','precision-check-2652081/01-cp2k-si64-displaced-tight')
compare('CP2K 最终完整流程 → 严格参数','precision-final-2653188/00-cp2k-si64-displaced-final','precision-check-2652081/01-cp2k-si64-displaced-tight')

lines=['# SAI 16V100：Si 晶体 HSE06 实测','',
       '状态：'+('主表全部完成，每组两次独立启动。' if finished else '计算仍在进行；以下仅列已完成结果。'),
       '',
       '测试日期：2026-11-20。只使用 16V100 分区，AMD Ryzen Threadripper PRO 5995WX + V100-SXM2 16 GB；每卡 1 个 MPI rank、4 个 OpenMP 线程。',
       'Slurm每卡分配8个硬件线程（4个物理核）和15 GiB主机内存；本测试关闭BLAS库的额外线程，并将每个rank绑定到4个物理核。',
       '',
       (f'在这套输入和已部署模块下，CP2K的能量加力计算总耗时更短，ABACUS/CP2K耗时比为{min(ratios):.2f}–{max(ratios):.2f}。所有主表计算均正常退出并达到各自SCF收敛标准。' if finished else '最终结论等待所有主表重复计算结束。'),
       '',
       'CP2K 使用 `DZVP-MOLOPT-SR-GTH`、`GTH-PBE-q4`、`cFIT3` ADMM；ABACUS 使用 APNS v1 efficiency 的配套 Si 赝势和 7 bohr `2s2p1d` 轨道。两边都是每原子 13 个主基函数。结构为 a=5.431 Å 的理想金刚石 Si，64/216 原子，Γ 点，无自旋极化、固定占据。HSE 参数均为 25% 短程交换和 ω=0.11 bohr⁻¹。',
       '',
       '**这是上述实用近似设置的效率比较，不是等基组、等赝势或已证明等力精度的比较。** CP2K 的 ADMM、有限交换半径、积分筛选与 ABACUS 的 RI 筛选各有误差。不同赝势的绝对总能量不作跨程序比较。Γ 点超胞不代表 Si 材料性质已经完成 k 点收敛。',
       '',
       '## 重复计时',
       '',
       '总耗时为 `/usr/bin/time` 测得的程序启动到退出时间，CP2K 包含 PBE 初猜和 HSE 两次启动；ABACUS 包含其内部 GGA 初始自洽。均包括最后的力计算；不含排队和 module 加载。每程序每组两次，以中位数汇总并列出范围。每次从独立输入目录开始；不复用前一次 HSE 的波函数。CP2K 经力误差检查后单独重跑，主表只使用 EPS_SCHWARZ_FORCES=1e-6 的最终结果；同一资源档的两套程序使用同一节点。1/4卡作业使用共享节点，16卡作业占满单个节点。',
       '',
       'SCF 时间取程序计时器，CP2K 包含 PBE 和 HSE 两阶段；ABACUS 包含 GGA 和 HSE 迭代。交换力列分别来自 CP2K 的 derivatives_four_center 和 ABACUS 的 Exx_LRI::cal_exx_force，计时范围不保证逐项相同；总耗时是主要比较指标。多卡测试同时增加 CPU 核数，扩展比反映整份资源配额，不能单独解释为 GPU 加速比。',
       '',
       '| 原子数 | GPU / CPU物理核 | 程序 | 完成重复数 | 总耗时中位数 [范围] / s | SCF / s | 交换力积分 / s |',
       '|---:|---:|---|---:|---:|---:|---:|']
for (n,g,program),a in sorted(aggregate.items()):
    lines.append(f'| {n} | {g} / {4*g} | {program.upper()} | {a["repeats"]} | {a["workflow_wall_s"]:.2f} [{a["wall_min_s"]:.2f}, {a["wall_max_s"]:.2f}] | {a.get("workflow_scf_s",float("nan")):.2f} | {a.get("exx_force_s",float("nan")):.2f} |')
lines+=['','| 原子数 | GPU | ABACUS总耗时 / CP2K总耗时 | ABACUS SCF / CP2K SCF |','|---:|---:|---:|---:|']
for n,g in [(64,1),(64,4),(216,4),(216,16)]:
    a=aggregate.get((n,g,'abacus'));c=aggregate.get((n,g,'cp2k'))
    if a and c:
        lines.append(f'| {n} | {g} | {a["workflow_wall_s"]/c["workflow_wall_s"]:.2f}× | {a["workflow_scf_s"]/c["workflow_scf_s"]:.2f}× |')
lines+=['','![HSE06 wall-time comparison](timing.png)']
lines+=['','## 资源扩展与迭代数','','| 原子数 | 程序 | GPU变化（CPU核数同步增4倍） | 总耗时加速比 | 并行效率 | GPU小时：少卡 → 多卡 |','|---:|---|---:|---:|---:|---:|']
for n,g0,g1 in [(64,1,4),(216,4,16)]:
    for program in ['cp2k','abacus']:
        a=aggregate.get((n,g0,program));b=aggregate.get((n,g1,program))
        if a and b:
            speedup=a['workflow_wall_s']/b['workflow_wall_s']
            lines.append(f'| {n} | {program.upper()} | {g0} → {g1} | {speedup:.2f}× | {100*speedup/(g1/g0):.1f}% | {a["allocated_gpu_hours"]:.3f} → {b["allocated_gpu_hours"]:.3f} |')
lines+=['','| 原子数 | GPU | 程序 | 初始GGA迭代数 | HSE迭代数 | 重复能量极差 / meV·atom⁻¹ | 节点 |','|---:|---:|---|---:|---:|---:|---|']
for (n,g,program),a in sorted(aggregate.items()):
    lines.append(f'| {n} | {g} | {program.upper()} | {",".join(map(str,a["pbe_iterations"]))} | {",".join(map(str,a["hse_iterations"]))} | {a["energy_spread_meV_atom"]:.3g} | {", ".join(a["nodes"])} |')
lines+=['','## 数值检查','','扰动算例将第一个 Si 原子移动 `(0.01, 0.02, -0.015)` Å，避免理想晶体的零力掩盖误差。严格 CP2K 使用 600 Ry、EPS_SCF=1e-8、EPS_SCHWARZ=1e-7、EPS_SCHWARZ_FORCES=1e-6；严格 ABACUS 使用 150 Ry、SCF=1e-10、RI PCA/C/V/DM=1e-5。此处只检查参数收紧的变化，没有将严格参数当作精确解。','','| 检查 | 能量差 / meV·atom⁻¹ | 最大原子力向量差 / eV·Å⁻¹ | RMS力向量差 / eV·Å⁻¹ |','|---|---:|---:|---:|']
for a in audit:lines.append(f'| {a["comparison"]} | {a["energy_meV_atom"]:.6f} | {a["max_force_delta_ev_A"]:.6f} | {a["rms_force_delta_ev_A"]:.6f} |')
lines+=['','默认 CP2K 力筛选1e-4在扰动结构上产生约0.026 eV/Å差异，因此其最快结果没有进入主表。最终1e-6设置相对严格参数约0.001 eV/Å；ABACUS参数收紧后的力变化约0.000013 eV/Å。后者的能量整体平移约1.04 meV/atom，不代表力也发生同量级变化。这些检查没有验证ADMM、主基组、赝势或完整k点收敛，也没有证明两程序精度相同。']
validation_path=ROOT/'validation.json'
if validation_path.exists():
    validation=json.loads(validation_path.read_text())
    if validation.get('passed'):
        consistency=validation['parallel_consistency'].values()
        de=max(x['energy_spread_eV_atom'] for x in consistency)
        df=max(x['max_force_delta_eV_A'] for x in consistency)
        lines+=['',f'主表16次计算全部通过记录核验。各程序在不同MPI进程数及重复启动之间，能量极差最多{de:.3g} eV/atom，原子力向量差最多{df:.3g} eV/Å；同一资源档使用同一节点，CP2K最终算例的电子交换积分全部可缓存，没有因缓存不足发生重复计算。']
lines+=['','## 输入与版本','',
       '- CP2K `356586e108ea6f7afb60a0a1ac3c2ad98805eeb6`，固定 module `cp2k/master-beta-20261117-356586e108ea-rf678a701a42f-b0ffec6895ef1`。',
       '- ABACUS `4e9f1636b7ca27d1dc634711915c18087654b911`，固定 module `abacus/develop-beta-20261116-4e9f1636b7ca-rf678a701a42f-b5b5f95b9e21c`。',
       '- CP2K 主配置：400/60 Ry，EPS_SCF=1e-7，EPS_SCHWARZ=1e-6，EPS_SCHWARZ_FORCES=1e-6；Si64 交换半径5 Å，Si216 6 Å；PBE 对角化+Broyden 初猜后用 OT DIIS/FULL_ALL、ENERGY_GAP=0.001。初猜密度筛选开启。',
       '- CP2K 主表积分缓存上限8000 MiB/rank。早期2000 MiB/rank或默认力筛选1e-4的探索数据保留在逐例CSV中，不进入主表。',
       '- ABACUS 主配置：100 Ry，SCF=1e-8，RI PCA/C/V/DM=1e-4，`exx_separate_loop 0`；1卡 cuSOLVER，多卡 ELPA。',
       '- ABACUS 模块配套 LibRI `2.1.1-b0eff7a`；该库的交换矩阵/交换力张量收缩为CPU/OpenMP路径，CUDA模式不意味着全部EXX计算都在GPU上。本次比较的是现有模块整体效率。构建及源码依据见 `reference/libri-backend-note.md`。',
       '- APNS archive: https://store.aissquare.com/datasets/dc875646-a526-41f1-a180-d54b218fc80a/ABACUS-APNS-PPORBs-v1.zip ，MD5 `96cc456911712a81c1db85ba6e8239ce`。',
       '',
       '短半径会触发 CP2K 提示：erfc 核尾达到1e-6约需14.279 Å。本次5/6 Å都满足半胞长限制，但仍是数值截断近似，6/8 Å对照也不能代替对无限半径的严格证明。',
       '',
       '## 复现与原始记录','',
       'SAI目录：`/org/org-open-sai/proj-sai-hpc-software/runtime-tests/hse06-si-20261120`。',
       '',
       '本地 `results/` 保存输入、完整输出、force、计时和 allocation；大体积波函数/电荷重启保留在集群。`summary.json`/`summary.csv` 是逐例解析值，`aggregate.json` 给出主表分组及每个原始算例，`manifest.json` 记录所有尝试和作业号。计算本身取消、超时、未收敛的结果不计入主表。`PLAN.md` 记录参数选择依据。主表逐例退出状态、收敛、输入匹配、资源分配及重复能量一致性由 `validation.json` 记录。',
       '',
       '[最终输入包](reproduce-inputs.tar.gz) · [原始证据包](evidence.tar.gz) · [逐例CSV](summary.csv) · [文件校验值](SHA256SUMS)',
       '',
       overlap_note,
       '',
       '`reproduce-inputs.tar.gz` 保存最终输入、APNS配对文件、固定模块名和运行/分析脚本。解压到新的测试目录后，用 `reproduce.sbatch` 可在同一分配中依次运行两程序的最终参数，每组两次；1卡测Si64，4卡测Si64/Si216，16卡测Si216。例如：',
       '',
       '```bash',
       '# 在解压后的目录中提交；所有命令都固定16V100分区',
       'sbatch reproduce.sbatch',
       'sbatch --qos=flood-gpu --ntasks=4 --gpus-per-node=4 reproduce.sbatch',
       'sbatch --qos=flood-gpu --ntasks=16 --gpus-per-node=16 reproduce.sbatch',
       '```','']
(ROOT/'REPORT.md').write_text('\n'.join(lines))
(ROOT/'aggregate.json').write_text(json.dumps({'groups':[dict(atoms=k[0],gpus=k[1],program=k[2],**v) for k,v in sorted(aggregate.items())],'accuracy':audit},indent=2)+'\n')

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,2,figsize=(10,4.5),layout='constrained')
for ax,n in zip(axes,[64,216]):
    for program,color in [('cp2k','#2166ac'),('abacus','#b35806')]:
        vals=sorted((g,a) for (atoms,g,pr),a in aggregate.items() if atoms==n and pr==program)
        if not vals:continue
        x=[g for g,a in vals];y=[a['workflow_wall_s'] for g,a in vals]
        err=[[a['workflow_wall_s']-a['wall_min_s'] for g,a in vals],[a['wall_max_s']-a['workflow_wall_s'] for g,a in vals]]
        ax.errorbar(x,y,yerr=err,color=color,marker='o',capsize=4,label=program.upper())
        for g,a in vals:
            at_right=g==x[-1]
            ax.annotate(f'{a["workflow_wall_s"]:.0f}s',(g,a['workflow_wall_s']),xytext=(-6,-8) if at_right else (6,7),ha='right' if at_right else 'left',va='top' if at_right else 'bottom',textcoords='offset points',fontsize=9,color=color)
    ax.set_xscale('log',base=4);ax.set_xticks([1,4] if n==64 else [4,16],labels=['1','4'] if n==64 else ['4','16'])
    ax.set_title(f'Si {n} atoms, Gamma point');ax.set_xlabel('V100 GPUs (4 CPU cores per GPU)');ax.set_ylabel('Wall time incl. initialization and forces (s)');ax.margins(y=.12);ax.grid(alpha=.2);ax.legend()
fig.suptitle('HSE06 with CP2K ADMM / APNS efficiency LCAO\nDifferent numerical approximations; see force-accuracy checks',fontsize=11)
fig.supxlabel(('Two fresh runs per point; error bars span min–max.' if finished else 'Partial results; calculations still running.')+' GPU counts include the associated CPU allocation.',fontsize=8)
fig.savefig(ROOT/'timing.png',dpi=180);fig.savefig(ROOT/'timing.svg')
print('Report:',ROOT/'REPORT.md','completed groups:',len(groups))
