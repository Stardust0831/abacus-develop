#!/bin/bash
set -euo pipefail
root=$1
case_dir=$2
ranks=$3
configuration=$4
trace=$5
base=/org/org-open-sai/proj-sai-hpc-software/runtime-tests/hse06-gpu-libs-20261120
script_dir=$(cd "$(dirname "$0")" && pwd)
source "$script_dir/build-env.sh"
export LD_LIBRARY_PATH="$base/install/ddla/lib:$base/install/libxc/lib:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=4 OMP_PLACES=cores OMP_PROC_BIND=close OMP_DYNAMIC=FALSE
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export SAI_RI_DEVICE=gpu SAI_LIBXC_DEVICE=gpu SAI_RI_RESIDENT=0
unset SAI_GPU_TRACE
if [[ "$trace" == 1 ]]; then export SAI_GPU_TRACE=1; fi
case "$configuration" in
 baseline) binary="$base/install/abacus/bin/abacus" ;;
 pr-default) binary="$root/install/abacus/bin/abacus" ;;
 pr-resident) binary="$root/install/abacus/bin/abacus"; export SAI_RI_RESIDENT=1 ;;
 *) exit 2 ;;
esac
test -f "$root/logs/build-complete"
cd "$case_dir"
(set +u; module -t list) > modules.txt 2>&1
ldd "$binary" > linked-libraries.txt
sha256sum "$binary" > executable-sha256.txt
printf 'configuration=%s\nSAI_RI_DEVICE=%s\nSAI_LIBXC_DEVICE=%s\nSAI_RI_RESIDENT=%s\nOMP_NUM_THREADS=%s\nOPENBLAS_NUM_THREADS=%s\n' \
 "$configuration" "$SAI_RI_DEVICE" "$SAI_LIBXC_DEVICE" "$SAI_RI_RESIDENT" "$OMP_NUM_THREADS" "$OPENBLAS_NUM_THREADS" > run-settings.txt
set +e
/usr/bin/time -f '{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kb":%M,"exitcode":%x}' \
 -o time.json timeout 3600 mpirun -np "$ranks" --map-by "ppr:$ranks:node:pe=4" \
 --bind-to core bash ../scripts/rank.sh "$binary" > launcher.log 2>&1
status=$?
echo "$status" > exitcode.txt
exit "$status"
