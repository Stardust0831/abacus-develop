# 复现 LibRI PR #17 的 HSE 端到端对照

测试对象是 https://github.com/abacusmodeling/LibRI/pull/17 的固定提交 `5025261859f0c8b53d84eb1e2476aaec3f7bf202`，基线为前次 GPU 实验中的 LibRI `0e8afc3931ee4cdf564699811ca220215570dd6b`。新 PR 分支从该基线直接增加16个提交。

本目录的 `src/abacus` 沿用前次 ABACUS `4e9f1636b7ca` 及 GPU LibXC 接入，仅增加 `abacus-residency.patch` 中的驻留开关：

- `SAI_RI_RESIDENT=0`：PR 默认模式，保持 C/V 驻留关闭。
- `SAI_RI_RESIDENT=1`：调用 `set_gpu_resident_options()`，名称为 `Cs_`、`Vs_`，使用上游自动显存预算 `min(空闲显存/3, 4 GiB)`。

两种 PR 模式使用同一个可执行文件。LibRI 源码本身保持该提交原样。`source-sha256.json`、`source-scope-check.json` 记录源文件校验和及相对上次的 ABACUS 改动范围。

`build.sbatch` 复用 SAI 上前次实验目录中的 DDLA、LibXC 和基础依赖，并先运行 PR 自带的13项 CTest，再编译新 ABACUS。前次基线可执行文件及共享库也会核对 SHA256。完整旧构建复现步骤见前次目录 `hse06-gpu-libs-20261120/REPRODUCE.md`。

在 SAI 上新的测试目录解压 `reproduce-pr17.tar.gz`，其中包含本轮源文件、输入、脚本和冻结的 GitHub PR/review 信息。检查 `manifest.json` 中前次实验路径仍可用，全部构建与计算使用 `16V100` 分区：

```bash
sbatch build.sbatch
# 等构建成功后，先验证扰动结构的能量与非零原子力：
sbatch campaign.sbatch validate-si64-g4.json
```

验证合格后运行四份规格。每份分配内的顺序为基线、PR默认、PR驻留、PR驻留、PR默认、基线，各两次独立启动：

```bash
sbatch --qos=flood-1o2gpu --ntasks=1 --gpus-per-node=1 campaign.sbatch bench-si64-g1.json
sbatch --ntasks=4 --gpus-per-node=4 campaign.sbatch bench-si64-g4.json
sbatch --ntasks=4 --gpus-per-node=4 campaign.sbatch bench-si216-g4.json
sbatch --ntasks=16 --gpus-per-node=16 campaign.sbatch bench-si216-g16.json
```

CPU 绑定、OMP4、BLAS1、APNS efficiency、SCF/RI 阈值、Γ点、固定占据、GGA初猜和完整力计算均沿用前次输入。无重启文件复用。脚本在每个作业的输出目录中保存一份快照；运行时不原地更新脚本。

`/usr/bin/time` 的总墙钟时间包含 MPI 程序启动、自洽和最终力，不含 module 加载和排队。`rank-*-time.json` 的 RSS 是每个 rank 的峰值；其求和是各进程峰值之和，不是严格同时发生的整作业峰值。

`python3 analyze.py --require-validation` 检查三组扰动结构；全部规格完成后用 `python3 analyze.py --require-complete` 复核退出、HSE06标识、非零精确交换能、力、收敛、输入字节一致性、迭代数、节点与资源、动态库路径和二进制身份。能量与力差限值预先固定为 `1e-6 eV/atom` 与 `1e-5 eV/Å`。`make-report.py` 生成报告和独立 PNG/SVG 图表，需要 matplotlib。

固定算例并不能证明所有材料、k点、自旋和响应计算均正确。性能结论限于本轮条件；PR 作者的张量收缩回放结果不作为本轮端到端加速比。
