#!/bin/bash
#SBATCH --job-name=libri17-hse-build
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-gpu
#SBATCH --nodes=1
#SBATCH --ntasks=8
#SBATCH --gpus-per-node=8
#SBATCH --time=02:00:00
#SBATCH --output=build-%j.log
#SBATCH --export=ALL
set -euo pipefail
root=$SLURM_SUBMIT_DIR
base=/org/org-open-sai/proj-sai-hpc-software/runtime-tests/hse06-gpu-libs-20261120
cd "$root"
source "$root/build-env.sh"
source /opt/sai/runtime/mps_mapping.d/16V100.bash
export LD_LIBRARY_PATH="$base/install/ddla/lib:$base/install/libxc/lib:${LD_LIBRARY_PATH:-}"
mkdir -p logs build install
(set +u; module -t list) > logs/build-modules.txt 2>&1
lscpu > logs/build-lscpu.txt
nvidia-smi -q > logs/build-gpu.txt
sha256sum "$base/install/abacus/bin/abacus" "$base/install/ddla/lib/libddla.so.0" \
 "$base/install/libxc/lib/libxc.so.15" > logs/baseline-binaries-sha256.txt
cmake -S src/LibRI/unittests/gpu_symmetry -B build/libri-tests \
 -DENABLE_GPU=ON -DCMAKE_BUILD_TYPE=Debug -DDDLA_ROOT="$base/install/ddla" \
 -DLIBCOMM_ROOT="$base/imported-deps/LibComm-master" -DCEREAL_ROOT="$base/imported-deps/cereal" \
 -DBLAS_LIBRARIES="$OPENBLAS_ROOT/lib/libopenblas.so" -DLAPACK_LIBRARIES="$OPENBLAS_ROOT/lib/libopenblas.so" \
 '-DMPIEXEC_PREFLAGS=--map-by;slot:pe=8;--bind-to;core' \
 > logs/libri-test-configure.log 2>&1
cmake --build build/libri-tests --parallel 4 > logs/libri-test-build.log 2>&1
ctest --test-dir build/libri-tests -V --timeout 180 > logs/libri-ctest.log 2>&1
cmake -S src/abacus -B build/abacus \
 -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$root/install/abacus" \
 -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DBUILD_TESTING=OFF -DGIT_SUBMODULE=OFF \
 -DENABLE_MPI=ON -DENABLE_OPENMP=ON -DENABLE_LCAO=ON -DENABLE_LIBRI=ON \
 -DENABLE_LIBXC=ON -DENABLE_ELPA=ON -DENABLE_JSON=ON -DENABLE_MLALGO=OFF \
 -DUSE_CUDA=ON -DUSE_CUDA_MPI=ON -DENABLE_CUSOLVERMP=ON -DENABLE_CUBLASMP=ON \
 -DENABLE_NCCL_PARALLEL_DEVICE=ON -DCMAKE_CUDA_ARCHITECTURES=70 \
 -DCMAKE_C_COMPILER="$CC" -DCMAKE_CXX_COMPILER="$CXX" -DCMAKE_CUDA_HOST_COMPILER="$CXX" \
 -DCMAKE_CXX_STANDARD=17 -DCMAKE_CXX_FLAGS='-march=znver3 -mtune=znver3' \
 -DCMAKE_C_FLAGS='-march=znver3 -mtune=znver3' \
 -DLIBRI_DIR="$root/src/LibRI" -DLIBCOMM_DIR="$base/imported-deps/LibComm-master" \
 -Dcereal_DIR="$base/imported-deps/cereal/lib/cmake/cereal" \
 -Dnlohmann_json_DIR="$base/imported-deps/json/share/cmake/nlohmann_json" \
 -DLibxc_DIR="$base/install/libxc/lib/cmake/Libxc" \
 -DLibDDLA_DIR="$base/install/ddla/lib/cmake/LibDDLA" -DELPA_DIR="$ELPA_ROOT" \
 -DFETCHCONTENT_FULLY_DISCONNECTED=ON -DFETCHCONTENT_UPDATES_DISCONNECTED=ON \
 > logs/abacus-configure.log 2>&1
cmake --build build/abacus --parallel 28 > logs/abacus-build.log 2>&1
cmake --install build/abacus > logs/abacus-install.log 2>&1
install/abacus/bin/abacus --info > logs/abacus-info.txt 2>&1
ldd install/abacus/bin/abacus > logs/abacus-ldd.txt
sha256sum install/abacus/bin/abacus > logs/abacus-sha256.txt
cp build/abacus/CMakeCache.txt logs/abacus-CMakeCache.txt
cp build/abacus/compile_commands.json logs/abacus-compile_commands.json
cp build/libri-tests/Testing/Temporary/LastTest.log logs/libri-last-test.log
touch logs/build-complete
