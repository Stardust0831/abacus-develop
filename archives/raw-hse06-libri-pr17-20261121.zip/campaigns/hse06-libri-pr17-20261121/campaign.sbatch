#!/bin/bash
#SBATCH --job-name=libri17-hse
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-gpu
#SBATCH --nodes=1
#SBATCH --ntasks=4
#SBATCH --gpus-per-node=4
#SBATCH --time=01:30:00
#SBATCH --output=campaign-%j.log
#SBATCH --export=ALL
set -eo pipefail
source /opt/sai/runtime/mps_mapping.d/16V100.bash
python3 -u campaign.py "$1"
