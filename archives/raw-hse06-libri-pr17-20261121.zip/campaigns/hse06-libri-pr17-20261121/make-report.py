#!/usr/bin/env python3
"""Render a reproducible report from completed paired end-to-end measurements."""
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.mpl-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

data = json.loads((ROOT / 'aggregate.json').read_text())
validation = json.loads((ROOT / 'validation.json').read_text())
manifest = json.loads((ROOT / 'manifest.json').read_text())
compiler = json.loads((ROOT / 'compiler-comparison.json').read_text())
previous = json.loads((ROOT / 'baseline/aggregate.json').read_text())['groups']
assert validation['passed'] and compiler['same_compilation_flags']
groups = data['groups']
names = ['baseline', 'pr-default', 'pr-resident']
labels = {'baseline': '上次GPU版（本轮重跑）', 'pr-default': 'PR默认', 'pr-resident': 'PR＋C/V驻留'}


def table(headers, entries):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |',
                      '| ' + ' | '.join(['---'] * len(headers)) + ' |']
                     + ['| ' + ' | '.join(map(str, row)) + ' |' for row in entries])


def format_time(record):
    return f'{record["workflow_wall_s"]:.2f} [{record["wall_min_s"]:.2f}, {record["wall_max_s"]:.2f}]'


plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False,
                     'svg.fonttype': 'none'})
fig, axes = plt.subplots(2, 2, figsize=(11, 7.7))
for ax, group in zip(axes.flat, groups):
    records = [group['configurations'][name] for name in names]
    values = [r['workflow_wall_s'] for r in records]
    errors = [[value - r['wall_min_s'] for value, r in zip(values, records)],
              [r['wall_max_s'] - value for value, r in zip(values, records)]]
    ax.bar(range(3), values, yerr=errors, capsize=4, width=0.65,
           color=['#8e949c', '#386cb0', '#168c68'])
    ax.set_xticks(range(3), ['Baseline\n0e8afc3', 'PR #17\ndefault', 'PR #17\nC/V residency'])
    ax.set_title(f'Si{group["atoms"]} · {group["gpus"]} V100 + {group["gpus"] * 4} CPU cores')
    ax.set_ylabel('Wall time (s)')
    ax.set_ylim(0, max(r['wall_max_s'] for r in records) * 1.23)
    ax.grid(axis='y', alpha=0.18)
    ax.set_axisbelow(True)
    for index, value in enumerate(values):
        ax.text(index, records[index]['wall_max_s'] + max(values) * 0.04,
                f'{value:.2f}', ha='center', fontsize=10)
fig.suptitle('LibRI PR #17 · HSE06 Si energy + forces · SAI 16V100', fontsize=15)
fig.text(0.5, 0.018, 'Median and range of 2 independent starts per configuration.\n'
         'Same allocation per panel; forward/reverse order. Initial GGA SCF and complete forces included.',
         ha='center', fontsize=9)
fig.tight_layout(rect=(0, 0.075, 1, 0.955))
fig.savefig(ROOT / 'timing.png', dpi=180)
fig.savefig(ROOT / 'timing.svg')
plt.close(fig)

entries = []
for group in groups:
    configs = group['configurations']
    entries.append([group['atoms'], group['gpus'], format_time(configs['baseline']),
                    format_time(configs['pr-default']), format_time(configs['pr-resident']),
                    f'{configs["pr-default"]["baseline_over_this"]:.2f}×',
                    f'{configs["pr-resident"]["baseline_over_this"]:.2f}×'])
comparisons = validation['validation_comparisons'] + validation['benchmark_comparisons']
max_energy = max(c['energy_ev_atom'] for c in comparisons)
max_force = max(c['max_force_delta_ev_A'] for c in comparisons)
default_gains = [g['configurations']['pr-default']['time_reduction_percent'] for g in groups]
resident_gains = [g['configurations']['pr-resident']['time_reduction_percent'] for g in groups]
lines = [
    '# LibRI PR #17：相同 Si HSE06 条件的端到端实测',
    '',
    '状态：完成。测试日期 2026-11-21，全部构建和计算使用 SAI `16V100` 分区。4种体系/资源规格 × 3种配置 × 2次独立启动，共24次正式计时；另有3次扰动 Si64 正确性验证。计时均包含初始 GGA 自洽、HSE 自洽及最终完整原子力，不计算应力。',
    '',
    f'相对于本轮重新测量的旧GPU版基线，PR默认模式的总耗时减少 {min(default_gains):.1f}%–{max(default_gains):.1f}%；显式开启C/V驻留后，减少 {min(resident_gains):.1f}%–{max(resident_gains):.1f}%。Si216/4卡收益最大，Si216/16卡的默认模式收益较小。所有27次能量/力检查均通过，收敛迭代数保持一致。',
    '',
    f'测试的是用户 review 过的 [LibRI PR #17]({manifest["pr_url"]})，当前固定 head `{manifest["pr_head"]}`。基线 `{manifest["libri_baseline"]}` 正是上次 GPU 接入实验的 LibRI 版本，PR 在其上增加16个提交。GitHub 上用户的 review 对应更早的 head；本轮测量包含后续更新。PR 作者的张量回放计时未用于以下端到端加速比。',
    '',
    table(['Si原子数', 'GPU', '基线 / s [范围]', 'PR默认 / s [范围]', 'PR＋驻留 / s [范围]', 'PR默认加速比', 'PR＋驻留加速比'], entries),
    '',
    '数值为两次计时的中位数，括号列出最小/最大值；加速比为本轮基线耗时除以相应 PR 配置耗时。每组都在同一份 Slurm 分配内运行，顺序为基线、PR默认、PR驻留、PR驻留、PR默认、基线。所有初猜从原子电荷开始，不复用上一个算例的波函数；缓存只在单次进程内部生效。',
    '',
    '![端到端计时](timing.png)',
    '',
    '三种配置都已经启用 LibRI GPU 和 LibXC GPU。基线复用前次校验过的可执行文件；PR默认包含新的打包和布局缓存，但不启用 C/V 驻留；PR＋驻留通过新增的 ABACUS 实验开关调用 `set_gpu_resident_options()`，注册 `Cs_`、`Vs_`，使用上游自动预算 `min(空闲显存/3, 4 GiB)`。两种 PR 配置使用同一可执行文件。驻留列表示显式启用该 API；本次未对命中次数、驻留字节或回退上传比例进行插桩，不能从开关本身推断所有 C/V 变体都驻留成功。',
    '',
    '**参数与资源。** 与前次相同的 Si64/Si216 晶体、Γ点、非自旋极化、固定占据、APNS v1 efficiency Si赝势和7 bohr 2s2p1d LCAO。HSE06为25%短程交换、ω=0.11 bohr⁻¹，100 Ry，SCF=1e-8，RI PCA/C/V/DM=1e-4，`exx_separate_loop=0`，`cal_force=1`，`cal_stress=0`。27份程序输出的 `INPUT.info` 均确认 `symmetry=-1`、`exx_symmetry_realspace=0`、`gamma_only=1`。单卡 cuSOLVER，多卡 ELPA。全部 INPUT/STRU/KPT/赝势/轨道文件与前次对应算例逐字节核验一致。',
    '',
    '**对称性适用范围。** 本轮结果属于关闭空间群和EXX实空间对称性约化、保留Γ点专用算法的情况。固定PR源码 `src/LibRI/include/RI/ri/LRI-cal_loop3_GPU.hpp` 中，批处理计划的 `cacheable` 条件要求原子筛选器恰为基础 `Filter_Atom`；启用EXX实空间对称性时，`Exx::set_symmetry()` 使用派生的 `Filter_Atom_Symmetry`，此项计划缓存会绕过。C/V驻留没有同样的筛选器条件，但实际收益仍会受到工作量与数据布局影响。已完成的对称性CTest只验证正确性，不能代替开启对称性后的应用性能测量；本轮加速比不能直接外推到该条件。扰动Si64的默认/驻留版也分别比其基线减少约10.1%/22.2%耗时，但每种配置仅一次，且不是完整的对称性开关对照。',
    '',
    '每卡1个MPI进程、4个OpenMP线程及4个绑定物理核，BLAS线程数1；Slurm每卡配8个硬件线程和15 GiB主机内存。V100-SXM2 16 GB、AMD 5995WX。1/4卡作业可与其他作业共享节点，16卡占用整节点；两次样本不足以给出稳定的统计置信区间。比较小于重复波动的变化时应保留不确定性。',
    '',
    '本轮 Si64/4卡与 Si216/4卡确实曾同时运行在 `16v100n47`，使用各自分配的GPU和CPU；Si216的首轮基线及部分首轮PR默认计算与Si64作业重叠。后续的反向复跑覆盖了Si64作业结束后的条件，但不能完全消除节点共享带来的波动。因此表中保留全部重复范围，四卡收益的具体百分比应结合范围理解。各rank的CPU绑定不重叠，线程数与驻留开关也已逐例核验。',
    '',
    table(['体系', 'GPU', '节点', '配置', '总耗时减少', 'SCF / s', '电子交换 / s', '交换力 / s'], [
        [group['atoms'], group['gpus'], ','.join(group['configurations'][name]['nodes']), labels[name],
         f'{group["configurations"][name]["time_reduction_percent"]:.1f}%',
         f'{group["configurations"][name]["scf_s"]:.2f}',
         f'{group["configurations"][name]["exx_s"]:.2f}',
         f'{group["configurations"][name]["exx_force_s"]:.2f}'] for group in groups for name in names]),
    '',
    '上表内部分项取程序计时器，存在包含关系，不能相加当作总时间；主要比较依据为 `/usr/bin/time` 总墙钟。排队、module加载及证据记录在计时区间之外。每个rank外层另有相同的轻量计时器，用于采集进程RSS。',
    '',
    '**数值验证。** 三组验证结构将第一个 Si 原子移动 (0.01,0.02,-0.015) Å，确保非零力。包括正式计时在内，所有计算均成功退出，明确输出 `XC: HSE06`、非零精确交换能和完整原子力，最终残差≤1e-8。各体系的初始GGA及HSE迭代数与前次一致。',
    '',
    table(['扰动Si64/4卡配置', '总耗时 / s', '能量差 / eV·atom⁻¹', '最大力向量差 / eV·Å⁻¹'], [
        [labels[row['configuration']], f'{row["workflow_wall_s"]:.2f}',
         f'{next(c["energy_ev_atom"] for c in validation["validation_comparisons"] if c["case"] == row["case"]):.3e}',
         f'{next(c["max_force_delta_ev_A"] for c in validation["validation_comparisons"] if c["case"] == row["case"]):.3e}']
        for row in data['validation_runs']]),
    '',
    f'所有本轮相对基线的检查中，最大能量差 {max_energy:.3e} eV/atom、最大力向量差 {max_force:.3e} eV/Å；均通过预先固定的 1e-6 eV/atom 与 1e-5 eV/Å 界限。详见 `validation.json`。本次仍仅验证这些 Si HSE 算例，未扩展到其他材料、自旋、k点或响应计算。',
    '',
    'PR自带13项CTest全部通过：参数/显存预算、单rank实数/复数对称性、CPU/GPU缓存复制隔离与张量替换、1/2 MPI进程×1/4 OpenMP线程，以及1/4/6线程打包测试。未放松测试断言或数值阈值。完整输出保存在 `logs/libri-ctest.log`。',
    '',
    '**内存。** 以下为两次运行中“最大单rank RSS峰值”的中位数，单位 GiB。驻留与布局缓存可改变主机/GPU内存使用；本次没有采样GPU显存峰值。逐rank数据及各rank峰值之和保存在逐例CSV和原始JSON，后者不能当作同步整作业内存峰值。',
    '',
    table(['体系', 'GPU', '基线最大rank RSS', 'PR默认最大rank RSS', 'PR驻留最大rank RSS'], [
        [group['atoms'], group['gpus']] + [f'{group["configurations"][name]["max_rank_rss_gib"]:.3f}' for name in names]
        for group in groups]),
    '',
    '**构建控制。** ABACUS主程序仍为 `4e9f1636b7ca` 加前次LibXC GPU适配；新增源码仅为 `abacus-residency.patch` 的初始化开关。LibRI PR源码没有改动。DDLA、LibXC和其他依赖复用前次安装，动态库路径与SHA256已核验。GCC13.3、CUDA12.9/SM70、C++17、相同Release/CPU优化选项；独立新构建重编译所有翻译单元。',
    '',
    table(['公共依赖', '分支', '固定提交'], [
        [name, dependency['branch'], '`' + dependency['sha'] + '`']
        for name, dependency in manifest['dependencies'].items()]),
    '',
    f'逐项核对 {compiler["translation_units"]} 个编译单元的宏、优化及语言标准选项，与前次一致（`compiler-comparison.json`）。基线二进制SHA256：`{manifest["baseline_binary_sha256"]}`；PR二进制：`{manifest["pr_binary_sha256"]}`。公共module未替换，未向PR发送消息。',
    '',
    '与前次结果的时间漂移如下；主表始终使用同节点新跑的基线，避免把日期和节点差异计入PR收益：',
    '',
    table(['体系', 'GPU', '前次GPU基线 / s', '本轮GPU基线 / s'], [
        [group['atoms'], group['gpus'],
         f'{next(r["workflow_wall_s"] for r in previous if r["atoms"] == group["atoms"] and r["gpus"] == group["gpus"]):.2f}',
         f'{group["configurations"]["baseline"]["workflow_wall_s"]:.2f}'] for group in groups]),
    '',
    f'SAI目录：`{manifest["remote"]}`。',
    '',
    '[逐例CSV](summary.csv) · [数值/资源核验](validation.json) · [运行与源码版本](manifest.json) · [复现说明](REPRODUCE.md) · [复现包](reproduce-pr17.tar.gz) · [原始证据包](evidence.tar.gz) · [SHA256](SHA256SUMS)',
]
(ROOT / 'REPORT.md').write_text('\n'.join(lines) + '\n')
