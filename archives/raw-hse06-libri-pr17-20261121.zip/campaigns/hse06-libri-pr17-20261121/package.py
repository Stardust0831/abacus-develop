#!/usr/bin/env python3
"""Package completed source, inputs, scripts and numerical evidence."""
import hashlib
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
assert json.loads((root / 'validation.json').read_text())['passed']
metadata = ['REPORT.md', 'REPRODUCE.md', 'PLAN.md', 'manifest.json', 'summary.json', 'summary.csv',
            'aggregate.json', 'validation.json', 'compiler-comparison.json', 'source-sha256.json',
            'source-scope-check.json', 'patch-verification.json', 'abacus-residency.patch',
            'timing.png', 'timing.svg']
scripts = ['build.sbatch', 'build-env.sh', 'campaign.sbatch', 'campaign.py', 'run-case.sh',
           'rank.sh', 'parse_base.py', 'analyze.py', 'collect.py', 'make-report.py', 'package.py']
specs = [f.name for f in root.glob('bench-*.json')] + ['validate-si64-g4.json']


def clean_filter(info):
    if '/__pycache__/' in info.name or '/.git/' in info.name:
        return None
    return info


with tarfile.open(root / 'reproduce-pr17.tar.gz', 'w:gz', compresslevel=3) as archive:
    for name in ['src', 'reference', 'inputs', 'data', 'baseline'] + metadata + scripts + specs:
        archive.add(root / name, arcname=name, filter=clean_filter)
with tarfile.open(root / 'evidence.tar.gz', 'w:gz', compresslevel=3) as archive:
    for name in ['results', 'logs'] + metadata:
        archive.add(root / name, arcname=name, filter=clean_filter)
    for pattern in ['build-*.log', 'campaign-*.log']:
        for path in sorted(root.glob(pattern)):
            archive.add(path, arcname=path.name)
files = sorted(set(metadata + scripts + specs + ['reproduce-pr17.tar.gz', 'evidence.tar.gz']))
(root / 'SHA256SUMS').write_text(''.join(
    hashlib.sha256((root / name).read_bytes()).hexdigest() + '  ' + name + '\n' for name in files))
with tarfile.open(root / 'deliverables.tar', 'w') as archive:
    for name in files + ['SHA256SUMS']:
        archive.add(root / name, arcname=name)
for name in ['reproduce-pr17.tar.gz', 'evidence.tar.gz', 'deliverables.tar']:
    print(name, round((root / name).stat().st_size / 1024 ** 2, 2), 'MiB')
