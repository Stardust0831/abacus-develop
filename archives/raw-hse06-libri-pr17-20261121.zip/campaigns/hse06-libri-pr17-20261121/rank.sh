#!/bin/bash
set -euo pipefail
rank=${OMPI_COMM_WORLD_RANK:?}
{
 printf 'rank=%s\npid=%s\n' "$rank" "$$"
 awk '/Cpus_allowed_list/ {print}' /proc/self/status
 printf 'OMP_NUM_THREADS=%s\nOPENBLAS_NUM_THREADS=%s\nCUDA_VISIBLE_DEVICES=%s\n' \
  "$OMP_NUM_THREADS" "$OPENBLAS_NUM_THREADS" "${CUDA_VISIBLE_DEVICES:-}"
} > "rank-$rank-settings.txt"
exec /usr/bin/time -f '{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kb":%M,"exitcode":%x}' \
 -o "rank-$rank-time.json" "$1"
