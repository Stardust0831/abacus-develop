# LibRI PR #17 HSE06 end-to-end comparison

The user requested the reviewed performance PR under the previous Si64/Si216 conditions, including forces. GitHub confirms Stardust0831 reviewed PR #17. Freeze its head at 5025261859f0c8b53d84eb1e2476aaec3f7bf202; its ancestor 0e8afc3931ee4cdf564699811ca220215570dd6b is exactly the previous GPU benchmark's LibRI version.

Use the previous ABACUS 4e9f1636b7ca source and GPU LibXC integration, the identical installed DDLA and LibXC shared libraries, compiler flags, APNS inputs, solver, numerical thresholds, CPU/GPU resources, and 16V100 partition. Keep the existing baseline executable, verified by SHA256. Build PR17 independently; the only additional ABACUS change exposes the PR's opt-in resident API through SAI_RI_RESIDENT=0|1 at initialization. No public module or upstream PR is modified.

Three configurations: baseline GPU libraries; PR default (layout/packing optimizations with residency disabled); PR with Cs_/Vs_ residency enabled and the upstream automatic budget min(free GPU memory / 3, 4 GiB). All use GPU RI and GPU LibXC. No geometry, threshold or force setting changes.

First run the PR's upstream CTest suite including resident-cache copy isolation, minimal tensors, CPU/GPU, 1/2 ranks and OpenMP 1/4, plus packing tests. Then validate all three configurations on displaced Si64, 4 GPUs, under the prior limits: 1e-6 eV/atom and 1e-5 eV/angstrom maximum atomic force-vector difference. Require full forces, SCF residual <=1e-8, exit 0 and unchanged iteration count. The prescribed benchmark explicitly uses OMP4, overriding the generic ABACUS test default OMP1.

After validation, four independent resource groups: Si64/1 GPU, Si64/4 GPU, Si216/4 GPU, Si216/16 GPU. Each group runs all configurations in the same allocation, forward then reverse order: baseline, PR default, PR resident, PR resident, PR default, baseline. This gives two independent starts per configuration and limits order/node drift. All timings include GGA warm start, HSE convergence and full forces. No wavefunction reuse. Queue/module setup excluded. Record per-rank RSS, library paths, executable hashes and Slurm allocations. Do not generalize contraction-only PR claims into whole-application speedups.

Runtime scripts are snapshotted into each allocation's evidence directory before execution. Do not overwrite scripts currently being interpreted. Keep failed attempts and diagnose before admitting any timing to the summary.
