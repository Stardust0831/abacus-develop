#!/usr/bin/env python3
"""Parse HSE end-to-end results and audit the fresh baseline comparisons."""
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import statistics
import sys

from parse_base import ab_timing, parse, text

ROOT = Path(__file__).resolve().parent
CONFIGS = ['baseline', 'pr-default', 'pr-resident']
manifest = json.loads((ROOT / 'manifest.json').read_text())
limits = manifest['numerical_limits']
prior_rows = json.loads((ROOT / 'baseline/summary.json').read_text())


def save(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')


def delta(a, b):
    assert a['atoms'] == b['atoms'] == len(a['forces_ev_A']) == len(b['forces_ev_A'])
    norms = [sum((x - y) ** 2 for x, y in zip(fa, fb))
             for fa, fb in zip(a['forces_ev_A'], b['forces_ev_A'])]
    result = dict(energy_ev_atom=abs(a['energy_ev'] - b['energy_ev']) / a['atoms'],
                  max_force_delta_ev_A=math.sqrt(max(norms)),
                  rms_force_delta_ev_A=math.sqrt(statistics.mean(norms)))
    result['passed'] = all(result[key] <= value for key, value in limits.items())
    return result


rows = []
for path in sorted((ROOT / 'results').rglob('INPUT')):
    if 'OUT.' in str(path.parent):
        continue
    directory = path.parent
    row = parse(directory)
    request = json.loads((directory / 'request.json').read_text())
    row.update({key: request.get(key) for key in ['configuration', 'repeat', 'trace']})
    timing = text(directory / 'time.json')
    row['complete'] = row['complete'] and bool(timing)
    if '{' in timing:
        record = json.loads(timing[timing.index('{'):])
        row['complete'] = row['complete'] and record['exitcode'] == 0
    rank_times = []
    for f in directory.glob('rank-*-time.json'):
        raw = f.read_text()
        if '{' in raw:
            rank_times.append(json.loads(raw[raw.index('{'):]))
    row['rank_time_count'] = len(rank_times)
    row['max_rank_rss_gib'] = max((r['max_rss_kb'] for r in rank_times), default=0) / 1024 ** 2
    row['sum_rank_peak_rss_gib'] = sum(r['max_rss_kb'] for r in rank_times) / 1024 ** 2
    row['complete'] = row['complete'] and len(rank_times) == row['ranks'] and all(r['exitcode'] == 0 for r in rank_times)
    out = text(directory / 'OUT.si/running_scf.log')
    row['hse06_identified'] = 'XC: HSE06' in out
    row['exx_energy_ev'] = float(re.findall(r'^\s*E_exx\s+\S+\s+(\S+)', out, re.M)[-1]) if re.search(r'^\s*E_exx\s+', out, re.M) else None
    row['complete'] = row['complete'] and row['hse06_identified'] and row['exx_energy_ev'] not in (None, 0)
    row['xc_s'] = ab_timing(out, 'XC_Functional_Libxc', 'v_xc_libxc')
    row['input_sha256'] = {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                           for name in ['INPUT', 'STRU', 'KPT', 'Si.upf', 'Si_gga_7au_100Ry_2s2p1d.orb']}
    launcher = text(directory / 'launcher.log')
    row['residency_trace'] = sorted(set(re.findall(r'LIBRI_CV_RESIDENCY enabled=(\d)', launcher)))
    row['ri_trace'] = sorted(set(re.findall(r'LIBRI_CONTRACTION_BACKEND (\w+)', launcher)))
    row['xc_gpu_devices'] = sorted(set(re.findall(r'LIBXC_GPU_EVAL device=(\d+)', launcher)))
    row['binary_sha256'] = text(directory / 'executable-sha256.txt').split()[0] if text(directory / 'executable-sha256.txt') else None
    rows.append(row)
save('summary.json', rows)
keys = ['case', 'configuration', 'atoms', 'ranks', 'node', 'repeat', 'complete', 'exitcode',
        'workflow_wall_s', 'program_s', 'scf_s', 'exx_s', 'exx_force_s', 'force_s', 'xc_s',
        'pbe_iterations', 'hse_iterations', 'energy_ev', 'exx_energy_ev', 'max_force_ev_A',
        'final_scf_residual', 'max_rank_rss_gib', 'sum_rank_peak_rss_gib']
with (ROOT / 'summary.csv').open('w') as stream:
    writer = csv.DictWriter(stream, fieldnames=keys, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)

validation_rows = [r for r in rows if r['case'].startswith('validate-')]
reference = next((r for r in validation_rows if r['configuration'] == 'baseline' and r['complete']), None)
checks = {'limits': limits, 'validation_complete': False, 'validation_comparisons': [],
          'benchmark_complete': False, 'benchmark_comparisons': [], 'runtime_audits': []}
if reference:
    for row in validation_rows:
        if not row['complete']:
            continue
        comparison = dict(case=row['case'], configuration=row['configuration'], **delta(row, reference))
        comparison['same_inputs'] = row['input_sha256'] == reference['input_sha256']
        comparison['same_iterations'] = all(row[k] == reference[k] for k in ['pbe_iterations', 'hse_iterations'])
        comparison['trace_passed'] = row['ri_trace'] == ['gpu'] and row['xc_gpu_devices'] == ['0', '1', '2', '3']
        if row['configuration'] != 'baseline':
            comparison['trace_passed'] &= row['residency_trace'] == (['1'] if row['configuration'] == 'pr-resident' else ['0'])
        comparison['passed'] &= comparison['same_inputs'] and comparison['same_iterations'] and comparison['trace_passed']
        checks['validation_comparisons'].append(comparison)
    checks['validation_complete'] = (len(validation_rows) == len(checks['validation_comparisons']) == 3
                                     and all(c['passed'] for c in checks['validation_comparisons']))

expected_pr_hash = text(ROOT / 'logs/abacus-sha256.txt').split()[0] if text(ROOT / 'logs/abacus-sha256.txt') else None
for row in rows:
    if not row['complete']:
        continue
    directory = ROOT / 'results' / row['case']
    allocation = text(directory.parent / 'allocation.txt')
    linked = text(directory / 'linked-libraries.txt')
    settings = text(directory / 'run-settings.txt')
    expected_residency = '1' if row['configuration'] == 'pr-resident' else '0'
    rank_cpus = []
    rank_settings_ok = True
    for path in directory.glob('rank-*-settings.txt'):
        raw = path.read_text()
        affinity = re.search(r'Cpus_allowed_list:\s*([^\n]+)', raw)
        cpus = set()
        if affinity:
            for entry in affinity.group(1).split(','):
                ends = list(map(int, entry.split('-')))
                cpus.update(range(ends[0], ends[-1] + 1))
        rank_cpus.append(cpus)
        rank_settings_ok &= 'OMP_NUM_THREADS=4\n' in raw and 'OPENBLAS_NUM_THREADS=1\n' in raw
    affinity_ok = (len(rank_cpus) == row['ranks'] and all(len(c) == 8 for c in rank_cpus)
                   and len(set().union(*rank_cpus)) == sum(map(len, rank_cpus)))
    expected_hash = manifest['baseline_binary_sha256'] if row['configuration'] == 'baseline' else expected_pr_hash
    audit = dict(case=row['case'], rank_cpu_affinity_passed=affinity_ok,
                 rank_thread_settings_passed=rank_settings_ok,
                 residency_setting_passed=f'SAI_RI_RESIDENT={expected_residency}\n' in settings,
                 passed=(
        row['binary_sha256'] == expected_hash
        and affinity_ok and rank_settings_ok
        and f'SAI_RI_RESIDENT={expected_residency}\n' in settings
        and 'Partition=16V100 ' in allocation
        and f'NumTasks={row["ranks"]} ' in allocation
        and f'NumCPUs={8 * row["ranks"]} ' in allocation
        and f'TresPerNode=gres/gpu:{row["ranks"]}' in allocation
        and 'OMP_NUM_THREADS=4\n' in settings and 'OPENBLAS_NUM_THREADS=1\n' in settings
        and 'SAI_RI_DEVICE=gpu\n' in settings and 'SAI_LIBXC_DEVICE=gpu\n' in settings
        and '/hse06-gpu-libs-20261120/install/ddla/lib/' in linked
        and '/hse06-gpu-libs-20261120/install/libxc/lib/' in linked))
    checks['runtime_audits'].append(audit)

groups = []
for atoms, ranks in [(64, 1), (64, 4), (216, 4), (216, 16)]:
    candidates = [r for r in rows if r['case'].startswith('bench-') and r['atoms'] == atoms and r['ranks'] == ranks]
    if not candidates:
        continue
    refs = [r for r in candidates if r['configuration'] == 'baseline' and r['complete']]
    previous = next(r for r in prior_rows if r['case'].startswith('benchmark-')
                    and r['atoms'] == atoms and r['ranks'] == ranks and r['complete'])
    group = dict(atoms=atoms, gpus=ranks, configurations={}, complete=False,
                 same_node=len(set(r['node'] for r in candidates)) == 1)
    for config in CONFIGS:
        part = [r for r in candidates if r['configuration'] == config]
        done = [r for r in part if r['complete']]
        record = dict(repeats=len(done), complete=len(done) == len(part) == 2, cases=[r['case'] for r in part])
        if done:
            for key in ['workflow_wall_s', 'program_s', 'scf_s', 'exx_s', 'exx_force_s', 'force_s', 'max_rank_rss_gib', 'sum_rank_peak_rss_gib']:
                values = [r[key] for r in done if r[key] is not None]
                record[key] = statistics.median(values) if values else None
            record['wall_min_s'] = min(r['workflow_wall_s'] for r in done)
            record['wall_max_s'] = max(r['workflow_wall_s'] for r in done)
            record['nodes'] = sorted(set(r['node'] for r in done))
            record['pbe_iterations'] = sorted(set(r['pbe_iterations'] for r in done))
            record['hse_iterations'] = sorted(set(r['hse_iterations'] for r in done))
            for row in done:
                comparison = dict(case=row['case'], configuration=config, **delta(row, refs[0] if refs else previous))
                comparison['same_inputs_as_previous'] = row['input_sha256'] == previous['input_sha256']
                comparison['same_iterations'] = all(row[k] == previous[k] for k in ['pbe_iterations', 'hse_iterations'])
                comparison['passed'] &= comparison['same_inputs_as_previous'] and comparison['same_iterations']
                checks['benchmark_comparisons'].append(comparison)
        group['configurations'][config] = record
    if refs:
        baseline_wall = statistics.median(r['workflow_wall_s'] for r in refs)
        for config, record in group['configurations'].items():
            if record['repeats']:
                record['baseline_over_this'] = baseline_wall / record['workflow_wall_s']
                record['time_reduction_percent'] = 100 * (1 - record['workflow_wall_s'] / baseline_wall)
    group['complete'] = group['same_node'] and all(r['complete'] for r in group['configurations'].values())
    groups.append(group)
checks['benchmark_complete'] = (len(groups) == 4 and all(g['complete'] for g in groups)
                               and len(checks['benchmark_comparisons']) == 24
                               and all(c['passed'] for c in checks['benchmark_comparisons']))
checks['passed'] = (checks['validation_complete'] and checks['benchmark_complete']
                    and len(checks['runtime_audits']) == 27
                    and all(c['passed'] for c in checks['runtime_audits']))
save('validation.json', checks)
save('aggregate.json', {'groups': groups, 'validation_runs': validation_rows})
for row in rows:
    print(row['case'], row['complete'], 'wall', row.get('workflow_wall_s'), 'E', row.get('energy_ev'))
print('Validation:', checks['validation_complete'], 'Benchmark:', checks['benchmark_complete'], 'All:', checks['passed'])
if '--require-validation' in sys.argv:
    assert checks['validation_complete'] and all(c['passed'] for c in checks['runtime_audits'])
if '--require-complete' in sys.argv:
    assert checks['passed']
