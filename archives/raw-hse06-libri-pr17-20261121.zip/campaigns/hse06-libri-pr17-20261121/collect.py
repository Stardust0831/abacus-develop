#!/usr/bin/env python3
"""Fetch raw runtime/build evidence without build objects or charge restarts."""
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
remote = json.loads((root / 'manifest.json').read_text())['remote']
command = (f'cd {remote} && tar --exclude="*.wfn*" --exclude="*.restart*" '
           '--exclude="*.npy" --exclude="*.npz" --exclude="*.cube" '
           '-cf - results logs build-*.log campaign-*.log')
source = subprocess.Popen(['tssh', '-T', 'SAI-stardust', command], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
extract = subprocess.run(['tar', '-C', str(root), '-xf', '-'], stdin=source.stdout)
source.stdout.close()
error = source.stderr.read().decode(errors='replace')
status = source.wait()
if status not in (0, 1) or extract.returncode:
    raise RuntimeError((status, extract.returncode, error))
if error:
    print(error)
subprocess.run(['python3', str(root / 'analyze.py')], check=True)
