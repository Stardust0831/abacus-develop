I measured the end-to-end effect of this PR in ABACUS HSE06 calculations, using head `5025261859f0c8b53d84eb1e2476aaec3f7bf202` against LibRI `0e8afc3931ee4cdf564699811ca220215570dd6b`. The results show an additional application-level benefit from this PR, including when atomic forces are included.

All wall times below include the initial GGA/PBE SCF, HSE06 SCF, and complete atomic forces; stress is disabled. The hardware is NVIDIA V100-SXM2 16 GB with AMD Threadripper PRO 5995WX CPUs, using one MPI rank and four physical CPU cores per GPU, OpenMP=4 and BLAS threads=1. The ABACUS calculations use APNS v1 efficiency Si pseudopotential/orbitals, HSE06 with 25% short-range exchange and omega=0.11 bohr^-1, a 100 Ry cutoff, SCF threshold 1e-8, and RI PCA/C/V/DM thresholds of 1e-4. All ABACUS cases use `gamma_only=1`, `symmetry=-1`, `exx_symmetry_realspace=0`, and `exx_separate_loop=0`.

For context, I also measured the existing LibRI CPU/GPU backend switch at the baseline commit, using the same ABACUS executable and a displaced Si64 cell on 4 GPUs / 16 CPU cores. Holding the LibXC backend fixed isolates the LibRI backend change:

| Fixed LibXC backend | LibRI CPU / s | LibRI GPU / s | End-to-end speedup |
| --- | ---: | ---: | ---: |
| CPU | 135.69 | 88.20 | 1.54x |
| GPU | 129.87 | 82.90 | 1.57x |

These four configurations ran consecutively in one allocation, with one fresh start per configuration and backend tracing enabled. The first Si atom was displaced by (0.01, 0.02, -0.015) angstrom to produce nonzero forces. All four configurations took 12 GGA + 12 HSE iterations; the maximum force-vector difference from CPU/CPU was 3.74e-10 eV/angstrom. These are backend-switch measurements at the baseline commit, separate from the PR comparison below.

The final timing tables locate this backend benefit in EXX: with LibXC fixed on CPU, electronic EXX drops from 59.53 to 29.04 s and EXX forces from 39.18 to 20.75 s. These scopes save 48.92 s together, while external wall time saves 47.49 s. ELPA stays at 5.86 -> 5.96 s and the LibXC potential timer at 5.67 -> 5.57 s.

For the PR comparison, LibRI and LibXC both use their GPU backends. I rebuilt ABACUS against the PR and compared its default mode with explicitly enabled C/V residency. The ABACUS source, shared dependencies, compiler options, numerical inputs, and allocated resources were held fixed, apart from a small ABACUS initialization hook for the residency API. The baseline executable was rerun in each allocation. Each row below uses two independent starts per configuration, in the order baseline, PR default, PR resident, PR resident, PR default, baseline. Values are median wall times in seconds, followed by the observed range:

| Case | Baseline GPU / s [range] | PR default / s [range] | PR + C/V residency / s [range] | Speedup: default / resident |
| --- | ---: | ---: | ---: | ---: |
| Si64, 1 GPU | 79.95 [76.80, 83.10] | 68.20 [67.99, 68.40] | 59.52 [59.46, 59.57] | 1.17x / 1.34x |
| Si64, 4 GPUs | 82.92 [81.37, 84.47] | 69.39 [66.97, 71.81] | 64.11 [63.93, 64.29] | 1.19x / 1.29x |
| Si216, 4 GPUs | 284.45 [276.50, 292.39] | 211.96 [205.03, 218.89] | 174.00 [173.94, 174.06] | 1.34x / 1.63x |
| Si216, 16 GPUs | 240.95 [240.62, 241.27] | 231.56 [231.37, 231.74] | 209.35 [208.10, 210.59] | 1.04x / 1.15x |

The default PR reduces end-to-end time by 3.9%–25.5% in these cases; explicitly enabling C/V residency increases the reduction to 13.1%–38.8%. The Si216/4-GPU timing breakdown shows where this reduction occurs:

| Si216 / 4 GPUs: phase | Baseline GPU / s | PR default / s | PR + residency / s |
| --- | ---: | ---: | ---: |
| Electronic EXX (`cal_exx_elec`) | 87.74 | 56.27 | 39.66 |
| EXX forces (`cal_exx_force`) | 103.55 | 64.12 | 44.23 |
| Remaining wall, derived by subtraction | 93.16 | 91.58 | 90.11 |
| External wall | 284.45 | 211.96 | 174.00 |

The two non-overlapping EXX scopes save 107.40 s together, accounting for approximately 97.2% of the 110.45 s wall-time reduction with residency. Their call counts stay at seven electronic EXX calls and one force call. EXX geometry preparation stays near 30–31 s, effective-potential work near 19.6 s, and the LibXC potential timer near 7.1 s. Electronic EXX is nested within SCF and EXX forces within the complete-force timer; parent and child times must not be added together.

For Si216/16 GPUs, the two EXX scopes save 37.07 s, while wall time saves 31.60 s: other work offsets part of the gain. One visible increase is local-potential grid integration (`Gint.cal_gint_vl`), from 2.49 to 6.13 s with residency. The existing timers do not explain this increase. These are elapsed application timers on the logging MPI rank, including waits; the derived remainder is approximate. They do not separate packing, host/device transfer, GPU GEMM, allocation, or synchronization costs.

For residency, the hook calls `set_gpu_resident_options()` with `enabled=true`, `data_names={"Cs_", "Vs_"}`, and `budget_gib=0` (the upstream automatic budget). Both PR modes use the same executable. Cache hit counts and resident bytes were not instrumented. ABACUS is pinned to `4e9f1636b7ca27d1dc634711915c18087654b911`, DDLA to `7c0ca08b4349a527cec2a0c0af7d1a1082bd38c7`, and LibXC to `3c7794c5047d5f19c088b856b24879ac7174ddfe`; GCC 13.3, CUDA 12.9, SM70, and C++17 were used. Compiler macro/optimization/language options matched across all 1054 translation units. The single-GPU solver is cuSOLVER; the multi-GPU solver is ELPA.

All 24 PR timing runs and three additional displaced-Si64 validation runs completed with full forces and unchanged SCF iteration counts. Relative to the corresponding baseline, the maximum energy difference was 1.67e-12 eV/atom and the maximum atomic force-vector difference was 5.39e-9 eV/angstrom, within the preset limits of 1e-6 eV/atom and 1e-5 eV/angstrom. All 13 tests in the PR's GPU symmetry/residency/packing CTest suite passed.

These measurements cover symmetry-disabled Gamma-point Si calculations. The PR's batch-plan cache is restricted to the base atom filter, so enabling EXX real-space symmetry can change which optimizations apply. The main timing table uses ideal crystal positions; displaced structures are separate correctness checks. There are only two timing samples per configuration, and the two 4-GPU jobs shared a node during the early part of the run, using distinct allocated GPUs/CPU cores. The repeat ranges are included to show the observed variation.

<details>
<summary>Historical context: original ABACUS module, CP2K, and the first GPU-library build</summary>

The original module comparison and first GPU-build timings are also included in the archive. These are separate historical runs, each with two starts per configuration, and include GGA/PBE initialization and complete forces:

| Case | Original ABACUS module / s | CP2K / s | First GPU-library build / s |
| --- | ---: | ---: | ---: |
| Si64, 1 GPU | 852.13 | 490.43 | 84.50 |
| Si64, 4 GPUs | 237.88 | 140.67 | 78.20 |
| Si216, 4 GPUs | 1728.23 | 563.77 | 257.64 |
| Si216, 16 GPUs | 574.04 | 238.80 | 265.37 |

The original and new builds share the same ABACUS commit, but the original module used CPU/OpenMP LibRI `2.1.1-b0eff7a`. For Si216/4 GPUs, electronic EXX decreases from 759.13 to 80.06 s and EXX forces from 848.69 to 87.31 s, accounting for approximately 98% of the historical wall-time reduction. A displaced-Si64 module control on the same node as the backend experiment took 291.51 s; the new build using both libraries on CPU took 135.69 s. Thus the historical improvement also includes dependency/build changes whose individual contributions were not isolated. Only the same-executable switches above isolate the LibRI CPU/GPU backend effect. The first GPU timings and fresh PR baseline use the same binary, but only the fresh baseline is used for PR speedups.

CP2K is pinned to `356586e108ea6f7afb60a0a1ac3c2ad98805eeb6`, using DZVP-MOLOPT-SR-GTH, GTH-PBE-q4, cFIT3 ADMM, 400/60 Ry, EPS_SCF=1e-7, EPS_SCHWARZ=EPS_SCHWARZ_FORCES=1e-6, and exchange radii 5/6 angstrom for Si64/Si216. Only its accepted final force settings are included. For Si216/4 GPUs, four-center integrals take 360.10 s and their force derivatives 146.94 s. CP2K's `hfx_ks_matrix` includes both, so it must not be added to the derivative timer. CP2K reports maximum total time over MPI ranks, while ABACUS reports the logging rank. Different pseudopotentials, bases, ADMM/truncation and RI screening mean this is not an established equal-accuracy comparison.

Three initial GPU timing drivers failed during post-calculation recording after ABACUS exited successfully; their independent exit/timing records, converged SCF and complete force output passed validation. These driver failures remain documented in the archive. Historical node assignments, repeat ranges, all final timing rows and further interpretation are in `HISTORICAL_TIMERS.md`.

</details>

The accompanying `libri-pr17-hse06-testcases.zip` contains five runnable ABACUS cases, potential/orbital files, integration patches, build/run instructions, an original CP2K/module input package, and original numerical evidence for 31 backend/PR runs plus 25 historical runs. `TIMER_ANALYSIS.md` and `HISTORICAL_TIMERS.md` provide the timing breakdowns, with CSV/JSON exports and scripts that recompute them from the packaged logs.
