#!/bin/bash
set -euo pipefail
case_name=$1
case_dir=$2
ranks=$3
binary=$4
ri=$5
xc=$6
resident=$7
trace=$8
rank_timing=$9
script_dir=$(cd "$(dirname "$0")" && pwd)
package_dir=${LIBRI_BENCH_PACKAGE:-$(cd "$script_dir/.." && pwd)}
test -d "$package_dir/cases/$case_name"
test ! -e "$case_dir"
mkdir -p "$case_dir"
cp "$package_dir/cases/$case_name/INPUT" "$package_dir/cases/$case_name/STRU" \
   "$package_dir/cases/$case_name/KPT" "$package_dir/cases/$case_name/Si.upf" \
   "$package_dir/cases/$case_name/Si_gga_7au_100Ry_2s2p1d.orb" "$case_dir/"
export OMP_NUM_THREADS=4 OMP_PLACES=cores OMP_PROC_BIND=close OMP_DYNAMIC=FALSE
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export SAI_RI_DEVICE="$ri" SAI_LIBXC_DEVICE="$xc" SAI_RI_RESIDENT="$resident"
unset SAI_GPU_TRACE
if [[ "$trace" == 1 ]]; then export SAI_GPU_TRACE=1; fi
cd "$case_dir"
sha256sum "$binary" > executable-sha256.txt
ldd "$binary" > linked-libraries.txt
printf 'SAI_RI_DEVICE=%s\nSAI_LIBXC_DEVICE=%s\nSAI_RI_RESIDENT=%s\nOMP_NUM_THREADS=%s\nOPENBLAS_NUM_THREADS=%s\n' \
  "$ri" "$xc" "$resident" "$OMP_NUM_THREADS" "$OPENBLAS_NUM_THREADS" > run-settings.txt
program=("$binary")
if [[ "$rank_timing" == 1 ]]; then program=(bash "$script_dir/rank.sh" "$binary"); fi
set +e
/usr/bin/time -f '{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kb":%M,"exitcode":%x}' \
  -o time.json timeout 3600 mpirun -np "$ranks" --map-by "ppr:$ranks:node:pe=4" \
  --bind-to core "${program[@]}" > launcher.log 2>&1
status=$?
printf '%s\n' "$status" > exitcode.txt
exit "$status"
