#!/usr/bin/env python3
"""Run one recorded comparison group in an existing single-node allocation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def main():
    plans = json.loads((ROOT / 'run-plan.json').read_text())
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--group', required=True, choices=plans)
    parser.add_argument('--baseline', required=True, type=Path)
    parser.add_argument('--pr', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    plan = plans[args.group]
    binaries = {'baseline': args.baseline.resolve()}
    if args.pr:
        binaries['pr'] = args.pr.resolve()
    if any(r['binary'] == 'pr' for r in plan['runs']) and 'pr' not in binaries:
        parser.error('--pr is required for this comparison')
    output = args.output.resolve()
    if output.exists():
        parser.error('output directory already exists; use a fresh directory')
    commands = []
    for i, run in enumerate(plan['runs']):
        dest = output / f'{i:02d}-{run["case"]}-{run["label"]}'
        command = ['bash', str(ROOT / 'scripts/run-case.sh'), run['case'], str(dest),
                   str(plan['ranks']), str(binaries[run['binary']]), run['ri'], run['xc'],
                   str(run['resident']), str(int(run['trace'])), str(int(run['rank_timing']))]
        commands.append((run, dest, command))
        print(shlex.join(command), flush=True)
    if args.dry_run:
        return
    for name, binary in binaries.items():
        if not binary.is_file() or not os.access(binary, os.X_OK):
            parser.error(f'{name} executable is unavailable: {binary}')
    if os.environ.get('SLURM_JOB_NUM_NODES', '1') != '1':
        parser.error('the recorded protocol requires one node')
    if 'SLURM_NTASKS' in os.environ and int(os.environ['SLURM_NTASKS']) != plan['ranks']:
        parser.error('SLURM_NTASKS does not match this group')
    output.mkdir(parents=True)
    snapshot = output / 'scripts'
    snapshot.mkdir()
    for name in ['run.py', 'run-case.sh', 'rank.sh']:
        shutil.copy2(ROOT / 'scripts' / name, snapshot / name)
    (output / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    versions = {name: {'path': str(binary), 'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
                for name, binary in binaries.items()}
    (output / 'executables.json').write_text(json.dumps(versions, indent=2) + '\n')
    progress = []
    for run, dest, command in commands:
        # Execute a snapshot so editing the package cannot change a running shell.
        command[1] = str(snapshot / 'run-case.sh')
        env = os.environ.copy()
        env['LIBRI_BENCH_PACKAGE'] = str(ROOT)
        result = subprocess.run(command, env=env)
        record = dict(run, directory=dest.name, exitcode=result.returncode)
        progress.append(record)
        (output / 'progress.json').write_text(json.dumps(progress, indent=2) + '\n')
        if result.returncode:
            raise SystemExit(result.returncode)
        (dest / 'request.json').write_text(json.dumps(run, indent=2) + '\n')
    (output / 'complete.txt').write_text('All commands exited successfully. Check SCF and forces separately.\n')


if __name__ == '__main__':
    main()
