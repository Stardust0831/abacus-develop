#!/usr/bin/env python3
"""Verify and compare archived CP2K, module ABACUS, and GPU ABACUS timings."""
import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import statistics
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('timers', ROOT / 'scripts/analyze-timers.py')
timers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(timers)
from verify import NUMBER, last

STAGES = ['module', 'cp2k', 'gpu-first', 'baseline', 'pr-default', 'pr-resident']
LABELS = {'module': 'Original ABACUS module (CPU LibRI)', 'cp2k': 'CP2K, final force settings',
          'gpu-first': 'First GPU-library build, original timings',
          'baseline': 'Same GPU baseline, fresh PR timings', 'pr-default': 'PR #17 default',
          'pr-resident': 'PR #17 + C/V residency',
          'module-displaced-control': 'Original module, fresh displaced control',
          'ri-cpu-xc-cpu': 'New build, LibRI CPU / LibXC CPU',
          'ri-gpu-xc-cpu': 'New build, LibRI GPU / LibXC CPU',
          'ri-cpu-xc-gpu': 'New build, LibRI CPU / LibXC GPU',
          'ri-gpu-xc-gpu': 'New build, LibRI GPU / LibXC GPU'}
HA_EV = 27.211386245988
BOHR_A = 0.529177210903


def read(path):
    return json.loads(path.read_text())


def csv_save(name, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with (ROOT / 'results' / name).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def time_record(path):
    raw = path.read_text()
    result = json.loads(raw[raw.index('{'):])
    assert result['exitcode'] == 0, path
    return result['wall_s']


def parse_cp2k(path):
    log = path.read_text()
    assert log.count('T I M I N G') == 1, path
    records = {}
    for line in log.split('T I M I N G', 1)[1].splitlines():
        fields = line.split()
        if len(fields) != 7:
            continue
        try:
            value = dict(calls=int(fields[1]), average_stack_depth=float(fields[2]),
                         self_average_s=float(fields[3]), self_maximum_s=float(fields[4]),
                         total_average_s=float(fields[5]), seconds=float(fields[6]))
        except ValueError:
            continue
        assert fields[0] not in records, (path, fields[0])
        records[fields[0]] = value
    assert {'CP2K', 'scf_env_do_scf'}.issubset(records), path
    return records


def verify_history(row):
    path = ROOT / row['evidence_dir']
    allocation = (path / 'allocation.txt').read_text()
    assert re.search(r'\bPartition=(\S+)', allocation)[1] == '16V100'
    assert int(re.search(r'\bNumTasks=(\d+)', allocation)[1]) == row['ranks']
    assert re.search(r'\bNodeList=(\S+)', allocation)[1] == row['node']
    assert row['complete'] and row['exitcode'] == 0
    driver_exit = int((path / 'exitcode.txt').read_text())
    assert driver_exit == row.get('driver_exitcode', 0)
    if driver_exit:
        assert row['stage'] == 'gpu-first' and driver_exit == 127 and row['driver_recording_error']
    wall = time_record(path / 'time.json')
    if row['program'] == 'cp2k':
        wall += time_record(path / 'time-pbe.json')
        log = (path / 'output.log').read_text()
        pbe = (path / 'pbe.log').read_text()
        for content, phase in [(log, 'hse'), (pbe, 'pbe')]:
            assert 'PROGRAM ENDED AT' in content and 'SCF run converged' in content
            assert 'SCF run NOT converged' not in content
            iterations = int(last(r'outer SCF loop converged in\s+\d+ iterations or\s+(\d+) steps', content))
            assert iterations == row[phase + '_iterations']
        energy = float(last(r'ENERGY\| Total FORCE_EVAL.*?\[hartree\]\s+(' + NUMBER + ')', log)) * HA_EV
        forces = [tuple(float(x) * HA_EV / BOHR_A for x in values) for values in re.findall(
            r'^ FORCES\|\s+\d+\s+(' + NUMBER + r')\s+(' + NUMBER + r')\s+(' + NUMBER + r')\s+' + NUMBER,
            log, re.M)]
        source = (path / 'input.inp').read_text()
        assert float(last(r'EPS_SCHWARZ_FORCES\s+(\S+)', source)) == 1e-6
        assert 'RUN_TYPE ENERGY_FORCE' in source and 'DZVP-MOLOPT-SR-GTH' in source
        assert float(last(r'FRACTION\s+(\S+)', source)) == 0.25
        assert float(last(r'OMEGA\s+(\S+)', source)) == 0.11
    else:
        case = ('si64-displaced-g4' if row['stage'] == 'module-displaced-control'
                else f'si{row["atoms"]}-g{row["ranks"]}')
        for name in ['INPUT', 'STRU', 'KPT']:
            assert (path / name).read_bytes() == (ROOT / 'cases' / case / name).read_bytes()
        for name, digest in row.get('input_sha256', {}).items():
            assert hashlib.sha256((ROOT / 'cases' / case / name).read_bytes()).hexdigest() == digest
        if row['stage'] == 'gpu-first':
            versions = read(ROOT / 'versions.json')
            assert (path / 'executable-sha256.txt').read_text().split()[0] == versions['baseline_binary_sha256']
        log = (path / 'OUT.si/running_scf.log').read_text()
        stdout = (path / 'launcher.log').read_text()
        effective = (path / 'OUT.si/INPUT.info').read_text()
        assert '#SCF IS CONVERGED#' in log and 'Total  Time' in log and 'XC: HSE06' in log
        assert float(last(r'^\s*E_exx\s+\S+\s+(\S+)', log)) != 0
        residual = float(last(r'^\s*[A-Z]{2}\d+\s+' + NUMBER + r'\s+' + NUMBER
                              + r'\s+(' + NUMBER + r')\s+' + NUMBER, stdout))
        assert residual <= 1e-8
        for key, expected in [('symmetry', '-1'), ('exx_symmetry_realspace', '0'), ('gamma_only', '1')]:
            assert last(r'^\s*' + key + r'\s+(\S+)', effective) == expected
        energy = float(last(r'!FINAL_ETOT_IS\s+(' + NUMBER + ')', log))
        forces = [tuple(map(float, values)) for values in re.findall(
            r'^\s*Si\d+\s+(' + NUMBER + r')\s+(' + NUMBER + r')\s+(' + NUMBER + r')\s*$', log, re.M)]
        marker = re.search(r'Entering 2nd SCF|Updating EXX and rerun SCF', stdout)
        assert marker
        first = len(re.findall(r'^\s*[A-Z]{2}\d+\s+', stdout[:marker.start()], re.M))
        total = len(re.findall(r'^\s*[A-Z]{2}\d+\s+', stdout, re.M))
        assert (first, total - first) == (row['pbe_iterations'], row['hse_iterations'])
    assert abs(wall - row['workflow_wall_s']) < 1e-8
    assert math.isfinite(energy) and abs(energy - row['energy_ev']) < 1e-8
    assert len(forces) == row['atoms'] and all(math.isfinite(x) for force in forces for x in force)
    assert max(abs(a - b) for fa, fb in zip(forces, row['forces_ev_A']) for a, b in zip(fa, fb)) < 1e-12


def normalize(row, historical, raw_rows):
    path = ROOT / row['evidence_dir']
    cp = row['program'] == 'cp2k'
    stage = row['stage'] if historical else row['configuration']
    case = (('si64-displaced-g4' if stage == 'module-displaced-control' else f'si{row["atoms"]}-g{row["ranks"]}')
            if historical else row['input_case'])
    tables = {'hse': parse_cp2k(path / 'output.log'), 'pbe': parse_cp2k(path / 'pbe.log')} if cp else {
        'gga+hse+forces': timers.parse_timers(path / 'OUT.si/running_scf.log')}
    scope = 'TOTAL TIME MAXIMUM over MPI ranks' if cp else 'elapsed time on logging MPI rank'
    for phase, records in tables.items():
        if historical:
            for name, record in records.items():
                raw_rows.append(dict(run=row['id'], case=case, stage=stage, program=row['program'],
                                     phase=phase, timer=name, scope=scope, **record))
    if cp:
        t, p = tables['hse'], tables['pbe']
        electronic = t['integrate_four_center']['seconds']
        force = t['derivatives_four_center']['seconds']
        assert abs(t['hfx_ks_matrix']['seconds'] - row['hfx_ks_matrix_s']) < 1e-8
        assert abs(force - row['exx_force_s']) < 1e-8
        assert t['integrate_four_center']['calls'] == 8 and t['derivatives_four_center']['calls'] == 1
        scf = t['scf_env_do_scf']['seconds'] + p['scf_env_do_scf']['seconds']
        full_force = None  # qs_forces also contains energies and SCF.
        electronic_name, force_name = 'integrate_four_center', 'derivatives_four_center'
    else:
        t = tables['gga+hse+forces']
        electronic, force = t[timers.ELECTRONIC]['seconds'], t[timers.FORCE]['seconds']
        assert abs(electronic - row['exx_s']) < 1e-8 and abs(force - row['exx_force_s']) < 1e-8
        assert t[timers.ELECTRONIC]['calls'] == row['hse_iterations'] and t[timers.FORCE]['calls'] == 1
        scf = t['ESolver_KS.scf_loop']['seconds']
        full_force = t['ESolver_KS_LCAO.cal_force']['seconds']
        electronic_name, force_name = timers.ELECTRONIC, timers.FORCE
    remaining = row['workflow_wall_s'] - electronic - force
    assert remaining > 0
    return dict(id=row['id'], case=case, stage=stage, program=row['program'], node=row['node'],
                wall_s=row['workflow_wall_s'], exchange_integrals_s=electronic, exchange_forces_s=force,
                remaining_wall_s=remaining, scf_gga_hse_s=scf, complete_forces_s=full_force,
                pbe_seed_wall_s=row.get('pbe_wall_s'), pbe_iterations=row['pbe_iterations'],
                hse_iterations=row['hse_iterations'], exchange_timer=electronic_name,
                exchange_force_timer=force_name, timer_scope=scope,
                driver_exitcode=row.get('driver_exitcode'), driver_recording_error=row.get('driver_recording_error'),
                evidence_dir=row['evidence_dir']), tables


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plot', action='store_true', help='generate the all-version PNG/SVG chart with matplotlib')
    args = parser.parse_args()
    history = read(ROOT / 'results/history-runs.json')
    core = read(ROOT / 'results/runs.json')
    assert len(history) == 25 and len(core) == 31
    normalized, raw_rows, cp_tables = [], [], {}
    for historical, source in [(True, history), (False, core)]:
        for row in source:
            if historical:
                verify_history(row)
            result, tables = normalize(row, historical, raw_rows)
            normalized.append(result)
            if row['program'] == 'cp2k':
                cp_tables[row['id']] = tables
    timers.save('history-timer-rows.json', raw_rows)
    csv_save('history-timer-rows.csv', raw_rows)
    timers.save('all-version-runs.json', normalized)
    csv_save('all-version-runs.csv', normalized)
    summary, lookup, changes = [], {}, []
    fields = ['wall_s', 'exchange_integrals_s', 'exchange_forces_s', 'remaining_wall_s',
              'scf_gga_hse_s', 'complete_forces_s', 'pbe_seed_wall_s']
    for case in timers.CASES:
        lookup[case] = {}
        for stage in STAGES:
            rows = [r for r in normalized if r['case'] == case and r['stage'] == stage]
            assert len(rows) == 2, (case, stage, len(rows))
            record = dict(case=case, stage=stage, samples=len(rows),
                          nodes=','.join(sorted({r['node'] for r in rows})),
                          wall_min_s=min(r['wall_s'] for r in rows), wall_max_s=max(r['wall_s'] for r in rows),
                          pbe_iterations=rows[0]['pbe_iterations'], hse_iterations=rows[0]['hse_iterations'])
            for field in fields:
                record[field] = statistics.median(r[field] for r in rows) if all(r[field] is not None for r in rows) else None
            assert all((r['pbe_iterations'], r['hse_iterations']) == (record['pbe_iterations'], record['hse_iterations']) for r in rows)
            summary.append(record)
            lookup[case][stage] = record
        for a, b in [('module', 'gpu-first'), ('baseline', 'pr-default'), ('baseline', 'pr-resident')]:
            before, after = lookup[case][a], lookup[case][b]
            saved = {field: before[field] - after[field] for field in fields[:4]}
            assert abs(saved['wall_s'] - sum(saved[k] for k in fields[1:4])) < 1e-8
            changes.append(dict(case=case, comparison=f'{a} -> {b}',
                                scope='historical build comparison' if a == 'module' else 'paired PR comparison',
                                **{k.replace('_s', '_saved_s'): v for k, v in saved.items()},
                                exchange_share_of_wall_saving_percent=100 * (saved['exchange_integrals_s'] + saved['exchange_forces_s']) / saved['wall_s']))
    timers.save('all-version-summary.json', summary)
    csv_save('all-version-summary.csv', summary)
    timers.save('history-attribution.json', changes)
    csv_save('history-attribution.csv', changes)
    control_order = ['module-displaced-control', 'ri-cpu-xc-cpu', 'ri-gpu-xc-cpu', 'ri-cpu-xc-gpu', 'ri-gpu-xc-gpu']
    controls = [next(r for r in normalized if r['case'] == 'si64-displaced-g4' and r['stage'] == stage) for stage in control_order]
    assert len({r['node'] for r in controls}) == 1
    csv_save('module-and-backend-control.csv', controls)
    write_report(lookup, changes, controls, cp_tables, normalized)
    if args.plot:
        plot(lookup)
    print(f'PASS: {len(history)} historical energy/force runs verified; {len(normalized)} total recorded runs; '
          f'{len(raw_rows)} historical timer rows. Wrote HISTORICAL_TIMERS.md.')


def write_report(lookup, changes, controls, cp_tables, normalized):
    number, table = timers.number, timers.table
    wall_table = [[case] + [number(lookup[case][stage]['wall_s']) for stage in STAGES] for case in timers.CASES]
    phase_table = []
    for stage in STAGES:
        r = lookup['si216-g4'][stage]
        phase_table.append([LABELS[stage]] + [number(r[k]) for k in ['wall_s', 'exchange_integrals_s', 'exchange_forces_s', 'remaining_wall_s']])
    historical_changes = [r for r in changes if r['comparison'] == 'module -> gpu-first']
    cp_details = []
    for case in timers.CASES:
        runs = [r for r in normalized if r['case'] == case and r['stage'] == 'cp2k']
        row = lookup[case]['cp2k']
        parent = statistics.median(cp_tables[r['id']]['hse']['hfx_ks_matrix']['seconds'] for r in runs)
        cp_details.append([case, number(row['pbe_seed_wall_s']), number(parent), number(row['exchange_integrals_s']),
                           number(row['exchange_forces_s']), number(row['scf_gga_hse_s'])])
    text = [
        '# Historical CP2K and old/new ABACUS timing analysis', '',
        'This appendix adds the original CP2K and ABACUS module results and the first GPU-library build to the '
        'controlled LibRI backend / PR comparisons in [TIMER_ANALYSIS.md](TIMER_ANALYSIS.md). All measurements used '
        'the SAI `16V100` partition, one MPI rank and four physical CPU cores per allocated V100, OpenMP=4 and BLAS threads=1. '
        'Wall times include initial GGA/PBE SCF, HSE06 SCF, and complete atomic forces; stress is disabled. '
        'The main tables use ideal Si64/Si216 cells and two fresh starts per entry.', '',
        '**All-version wall times (seconds).** The original module and CP2K entries use the accepted final force-benchmark '
        'runs, not the earlier exploratory CP2K runs with loose force screening. Historical and fresh GPU-baseline timings '
        'are separate measurements of the same executable. Only the fresh baseline is used to evaluate the PR.', '',
        table(['Case', 'Original ABACUS module', 'CP2K final', 'First GPU build', 'Fresh GPU baseline', 'PR default', 'PR + residency'], wall_table), '',
        'The original ABACUS module and the new builds share ABACUS commit '
        '`4e9f1636b7ca27d1dc634711915c18087654b911`. The module used CPU/OpenMP LibRI `2.1.1-b0eff7a`; '
        'the first GPU build used LibRI `0e8afc3`, DDLA `7c0ca08`, LibXC `3c7794c`, and ABACUS integration patches. '
        'Thus “old/new” is a dependency/build comparison, not an ABACUS source-version comparison. '
        'Original and first-GPU runs used different nodes. Node names, repeat ranges, and phase definitions are retained in '
        '`results/all-version-summary.csv` and `results/all-version-runs.csv`.', '',
        '**Si216 / 4 GPUs: where the time went (seconds).** For ABACUS the exchange columns are '
        '`Exx_LRI.cal_exx_elec` and `Exx_LRI.cal_exx_force`. For CP2K they are the HSE run’s '
        '`integrate_four_center` and `derivatives_four_center`; these have different scope and rank aggregation from ABACUS. '
        'The remainder is external wall minus the two exchange timers, including all other work, waits and launcher overhead. '
        'It is an approximate diagnostic, not an independently measured phase.', '',
        table(['Configuration', 'Wall', 'Electronic exchange / integrals', 'Exchange forces / derivatives', 'Remaining wall'], phase_table), '',
        'From the original module to the first GPU build, electronic exchange saves 679.07 s and exchange forces '
        '761.38 s: together 97.95% of the 1470.59 s wall-time reduction. The GGA+HSE SCF parent drops '
        '822.19 -> 124.42 s and complete forces drop 855.74 -> 89.87 s. These parent timers include the exchange '
        'children and must not be added again. The ABACUS SCF iteration counts are unchanged across builds: '
        '12 GGA + 8 HSE for Si64, 12 GGA + 7 HSE for Si216.', '',
        table(['Case: module -> first GPU build', 'Wall saved / s', 'Electronic EXX saved / s', 'EXX forces saved / s', 'Remainder saved / s'],
              [[r['case']] + [number(r[k]) for k in ['wall_saved_s', 'exchange_integrals_saved_s', 'exchange_forces_saved_s', 'remaining_wall_saved_s']]
               for r in historical_changes]), '',
        '**Displaced Si64 / 4 GPUs: the CPU control matters.** The following measurements were made on the same node '
        '`16v100n17`, with identical inputs and resources, one start each and 12 GGA + 12 HSE iterations. '
        'The four backend combinations ran consecutively in one allocation, with tracing enabled; '
        'the original-module control was a separate allocation on that node.', '',
        table(['Build / backend', 'Wall / s', 'Electronic EXX / s', 'EXX forces / s', 'Remaining wall / s'],
              [[LABELS[r['stage']]] + [number(r[k]) for k in ['wall_s', 'exchange_integrals_s', 'exchange_forces_s', 'remaining_wall_s']]
               for r in controls]), '',
        'Even with both new libraries on CPU, wall time decreases from 291.51 to 135.69 s, with electronic EXX '
        '141.70 -> 59.53 s and EXX forces 102.39 -> 39.18 s. This gain already exists before selecting GPU backends; '
        'the experiment does not isolate its dependency/build causes. Holding LibXC on CPU, selecting LibRI GPU then '
        'reduces wall time 135.69 -> 88.20 s, electronic EXX 59.53 -> 29.04 s and EXX forces 39.18 -> 20.75 s. '
        'The corresponding wall reduction with LibXC fixed on GPU is 129.87 -> 82.90 s. '
        'These controlled switches support 1.54x / 1.57x LibRI-backend speedups; the much larger historical old/new ratios '
        'cannot be attributed entirely to GPU execution.', '',
        '**CP2K timing scopes.** CP2K is pinned to `356586e108ea6f7afb60a0a1ac3c2ad98805eeb6`. '
        'Its HSE input uses DZVP-MOLOPT-SR-GTH, GTH-PBE-q4, cFIT3 ADMM, 400/60 Ry, EPS_SCF=1e-7, '
        'EPS_SCHWARZ=EPS_SCHWARZ_FORCES=1e-6, and exchange cutoff radii 5 angstrom for Si64 / 6 angstrom for Si216. '
        'Each starts with a separate PBE seed and then HSE OT; wall time sums both launches. All accepted runs have '
        '8 PBE and 7 HSE iterations; the HSE timer records 8 integral calls and one derivative call.', '',
        table(['Case', 'PBE seed wall / s', 'hfx_ks_matrix (parent) / s', 'integrate_four_center / s',
               'derivatives_four_center / s', 'PBE + HSE SCF / s'], cp_details), '',
        '`hfx_ks_matrix` calls both four-center integrals and force derivatives, as shown in the '
        '[pinned source](evidence/timer-scope-sources/hfx_admm_utils.F) (calls at lines 1281/1361 and 1305/1379). '
        'It is not an electronic-only EXX timer and must not be added to the derivative timer. '
        'Similarly, `qs_forces` contains energies and SCF and is not a force-only phase. '
        'The historical parser’s CP2K field named `exx_s` represented this parent; the collected historical JSON '
        'renames it to `hfx_ks_matrix_s`, and the new all-version exports use the two child scopes explicitly.', '',
        'CP2K’s four-center integrals and derivatives dominate these runs. For Si216/4 GPUs they account for '
        '360.10 + 146.94 = 507.04 s of the 563.77 s workflow; the PBE seed alone takes 23.85 s. '
        'For Si64/1 GPU the corresponding values are 221.28 + 244.39 s of 490.43 s. '
        'The CP2K columns consistently use `TOTAL TIME MAXIMUM` over MPI ranks. ABACUS reports elapsed timers on '
        'the logging rank, with work and waits included; these are not GPU-kernel timings. Maxima of CP2K child timers '
        'can come from different ranks, so their sum is not an exact rank-resolved decomposition.', '',
        '**Comparison limits and evidence.** The CP2K / ABACUS comparison uses different pseudopotentials, bases, '
        'ADMM / exchange truncation versus RI screening, and SCF criteria. It does not establish equal numerical accuracy '
        'or an accuracy-normalized code ranking. CP2K’s short radii retain the original truncation warning. '
        'Only the final 1e-6 force-screening runs enter the timing table; the earlier fast 1e-4 force runs are excluded. '
        'The original report records the parameter-tightening checks and their limits. Absolute total energies are '
        'not compared between programs.', '',
        'Three first-GPU timing drivers exited 127 during post-calculation recording, after ABACUS itself exited 0. '
        'Their independent wall/exit records, convergence, full forces and numerical checks passed, so those scientific '
        'runs are retained. The driver failures remain explicit in the all-version exports and '
        '`evidence/history-checks/gpu-first/evidence-validation.json`. Later repeats completed normally. '
        'The accepted original Si216/4-GPU module run also remains valid despite cancellation of its batch’s redundant '
        'later work; acceptance is based on each calculation’s output and exit record.', '',
        'The package contains 31 core backend/PR runs plus 25 historical runs: 8 original-module timings, '
        '8 accepted CP2K timings (both PBE and HSE logs), 8 first-GPU timings, and the displaced module control. '
        'Historical inputs and logs are under `evidence/history/`; original reports and checks are under '
        '`evidence/history-checks/`. Archived reports retain their original references to separate campaign artifacts; '
        'use this appendix and the package README for the current bundle layout. CP2K inputs require the pinned module’s '
        'BASIS_MOLOPT, BASIS_ADMM and GTH_POTENTIALS data. ABACUS potential/orbital assets are in `cases/`. '
        'The historical launch commands are preserved under `evidence/original-scripts/original/` and `gpu-first/`. '
        'The original module-comparison input package, including final CP2K and ABACUS cases and its Slurm launcher, '
        'is included unchanged as `evidence/history-checks/original/reproduce-inputs.tar.gz`; extract it in a new '
        'directory and follow its README-REPRODUCE.md to rerun on SAI. The first GPU build can use the five core '
        'ABACUS inputs and the baseline executable described in BUILD.md.', '',
        '![Historical and controlled HSE06 timing phases](results/history-breakdown.png)', '',
        'Recompute and verify the 25 historical runs with `python3 scripts/analyze-history.py`; add `--plot` for PNG/SVG '
        'generation with matplotlib. The 31 core runs are checked by `python3 scripts/verify.py`. These commands analyze '
        'existing evidence and do not launch electronic-structure calculations. `results/history-timer-rows.csv` retains '
        'every printed historical timer, and the all-version / attribution CSV and JSON files retain unrounded derived values.',
    ]
    (ROOT / 'HISTORICAL_TIMERS.md').write_text('\n'.join(text) + '\n')


def plot(lookup):
    os.environ.setdefault('MPLCONFIGDIR', '/tmp/libri-pr17-timer-matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False, 'svg.fonttype': 'none'})
    figure, axes = plt.subplots(2, 2, figsize=(13, 9.0))
    colors = ['#3b6fad', '#168c68', '#c0c5cc']
    fields = ['exchange_integrals_s', 'exchange_forces_s', 'remaining_wall_s']
    labels = ['Electronic exchange / integrals', 'Exchange forces / derivatives', 'Remaining wall (derived)']
    short = ['Original\nmodule', 'CP2K', 'First GPU\nbuild', 'Fresh GPU\nbaseline', 'PR\ndefault', 'PR +\nresidency']
    for ax, case in zip(axes.flat, timers.CASES):
        bottoms = [0.0] * len(STAGES)
        for field, color in zip(fields, colors):
            heights = [lookup[case][stage][field] for stage in STAGES]
            bars = ax.bar(range(len(STAGES)), heights, bottom=bottoms, color=color, width=0.67)
            bars[1].set_hatch('///')
            bars[1].set_edgecolor('white')
            bars[1].set_linewidth(0.3)
            bottoms = [a + b for a, b in zip(bottoms, heights)]
        maximum = max(bottoms)
        for i, value in enumerate(bottoms):
            r = lookup[case][STAGES[i]]
            ax.errorbar(i, value, yerr=[[value - r['wall_min_s']], [r['wall_max_s'] - value]],
                        fmt='none', ecolor='#374151', capsize=3, linewidth=1)
            ax.text(i, r['wall_max_s'] + maximum * 0.022, timers.number(value, 1), ha='center', fontsize=9)
        ax.axvline(2.5, color='#64748b', linewidth=0.8, linestyle='--')
        ax.set_xticks(range(len(STAGES)), short, fontsize=9)
        atoms, gpus = case.split('-g')
        ax.set_title(f'{atoms.replace("si", "Si")} / {gpus} V100 GPU' + ('s' if gpus != '1' else ''))
        ax.set_ylabel('Time (s)')
        ax.set_ylim(0, maximum * 1.14)
        ax.grid(axis='y', alpha=0.17)
        ax.set_axisbelow(True)
    handles = [Patch(facecolor=c, label=l) for c, l in zip(colors, labels)]
    figure.legend(handles=handles, loc='upper center', bbox_to_anchor=(0.5, 0.945), ncol=3, frameon=False)
    figure.suptitle('HSE06 + forces: original modules, GPU libraries and LibRI PR #17', fontsize=16, y=0.985)
    figure.text(0.5, 0.025, 'Two-run medians; error bars show observed wall-time ranges. Dashed divider: historical runs | paired PR runs.\n'
                'Hatched CP2K bars use different timer scopes and numerical approximations; equal accuracy is not established.\n'
                'ABACUS: logging-rank elapsed time. CP2K: maximum total time over ranks. Remainder is derived by subtraction.',
                ha='center', fontsize=9)
    figure.tight_layout(rect=(0, 0.10, 1, 0.90))
    for suffix in ['png', 'svg']:
        figure.savefig(ROOT / 'results' / f'history-breakdown.{suffix}', dpi=180)
    plt.close(figure)


if __name__ == '__main__':
    main()
