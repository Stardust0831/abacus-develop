#!/bin/bash
#SBATCH --job-name=libri-hse-review
#SBATCH --partition=16V100
#SBATCH --nodes=1
#SBATCH --ntasks=4
#SBATCH --gpus-per-node=4
#SBATCH --time=01:30:00
#SBATCH --output=libri-review-%j.log
#SBATCH --export=ALL
set -eo pipefail
# Submit from the package root after loading the matching runtime libraries.
source /opt/sai/runtime/mps_mapping.d/16V100.bash
python3 "$SLURM_SUBMIT_DIR/scripts/run.py" "$@"
