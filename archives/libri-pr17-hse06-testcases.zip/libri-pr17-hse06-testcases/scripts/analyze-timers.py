#!/usr/bin/env python3
"""Compare the final ABACUS timing tables in the packaged original runs."""
import argparse
import csv
from decimal import Decimal, ROUND_HALF_UP
import json
import os
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[1]
CONFIGS = ['baseline', 'pr-default', 'pr-resident']
CASES = ['si64-g1', 'si64-g4', 'si216-g4', 'si216-g16']
ELECTRONIC = 'Exx_LRI.cal_exx_elec'
FORCE = 'Exx_LRI.cal_exx_force'


def number(value, places=2):
    return str(Decimal(str(round(value, 8))).quantize(Decimal(10) ** -places, rounding=ROUND_HALF_UP))


def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |',
                      '| ' + ' | '.join(['---'] * len(headers)) + ' |']
                     + ['| ' + ' | '.join(map(str, row)) + ' |' for row in rows])


def save(name, value):
    (ROOT / 'results' / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def save_csv(name, rows):
    with (ROOT / 'results' / name).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def parse_timers(path):
    log = path.read_text()
    assert log.count('TIME STATISTICS') == 1, path
    raw = log.split('TIME STATISTICS', 1)[1]
    timers = {}
    for line in raw.splitlines():
        if 'MEMORY(MB)' in line:
            break
        fields = line.split()
        if len(fields) == 5 and fields[0] == 'total':
            fields = [''] + fields
        if len(fields) != 6:
            continue
        try:
            value = dict(seconds=float(fields[2]), calls=int(fields[3]),
                         average_s=float(fields[4]), percent=float(fields[5]))
        except ValueError:
            continue
        key = '.'.join(fields[:2]).lstrip('.')
        assert key not in timers, (path, key)
        timers[key] = value
    assert {'total', ELECTRONIC, FORCE}.issubset(timers), path
    return timers


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plot', action='store_true', help='also generate PNG/SVG charts using matplotlib')
    args = parser.parse_args()
    runs = json.loads((ROOT / 'results/runs.json').read_text())
    raw_rows = []
    for row in runs:
        row['timers'] = parse_timers(ROOT / row['evidence_dir'] / 'OUT.si/running_scf.log')
        for name, record in row['timers'].items():
            raw_rows.append(dict(run=row['id'], experiment=row['experiment'], case=row['input_case'],
                                 configuration=row['configuration'], timer=name, **record))
        for timer, field in [(ELECTRONIC, 'exx_s'), (FORCE, 'exx_force_s'),
                             ('ESolver_KS.scf_loop', 'scf_s'),
                             ('ESolver_KS_LCAO.cal_force', 'force_s'), ('total', 'program_s')]:
            assert abs(row['timers'][timer]['seconds'] - row[field]) < 1e-8
        assert row['timers'][ELECTRONIC]['calls'] == row['hse_iterations']
        assert row['timers'][FORCE]['calls'] == 1
        assert row['timers'][ELECTRONIC]['seconds'] <= row['scf_s']
        assert row['timers'][FORCE]['seconds'] <= row['force_s']
        assert row['program_s'] <= row['workflow_wall_s']
        row['wall_remainder_s'] = row['workflow_wall_s'] - row['exx_s'] - row['exx_force_s']
    save('timer-rows.json', raw_rows)
    save_csv('timer-rows.csv', raw_rows)

    summaries = []
    lookup = {}
    attribution = []
    for case in CASES:
        group = [r for r in runs if r['experiment'] == 'pr' and r['input_case'] == case]
        all_names = sorted(set().union(*(r['timers'] for r in group)))
        lookup[case] = {}
        for configuration in CONFIGS:
            part = [r for r in group if r['configuration'] == configuration]
            assert len(part) == 2
            values = {name: statistics.median(r[name] for r in part)
                      for name in ['workflow_wall_s', 'wall_remainder_s', 'exx_s', 'exx_force_s']}
            for name in all_names:
                observed = [r['timers'][name] for r in part if name in r['timers']]
                complete = len(observed) == len(part)
                times = [v['seconds'] for v in observed]
                record = dict(case=case, configuration=configuration, timer=name,
                              samples=len(part), samples_printed=len(observed),
                              median_s=statistics.median(times) if complete else None,
                              minimum_s=min(times) if complete else None,
                              maximum_s=max(times) if complete else None,
                              calls=','.join(map(str, sorted(set(v['calls'] for v in observed)))))
                summaries.append(record)
                values[name] = record['median_s']
            lookup[case][configuration] = values
        for start, end in [('baseline', 'pr-default'), ('pr-default', 'pr-resident'), ('baseline', 'pr-resident')]:
            a, b = lookup[case][start], lookup[case][end]
            wall = a['workflow_wall_s'] - b['workflow_wall_s']
            electronic = a[ELECTRONIC] - b[ELECTRONIC]
            force = a[FORCE] - b[FORCE]
            remainder = a['wall_remainder_s'] - b['wall_remainder_s']
            assert abs(wall - electronic - force - remainder) < 1e-7
            attribution.append(dict(case=case, comparison=f'{start} -> {end}',
                                    wall_saved_s=wall, electronic_exx_saved_s=electronic,
                                    exx_force_saved_s=force, remainder_saved_s=remainder,
                                    exx_saved_over_wall_saved_percent=100 * (electronic + force) / wall))
    save('timer-summary.json', summaries)
    save_csv('timer-summary.csv', summaries)
    save('timer-attribution.json', attribution)
    save_csv('timer-attribution.csv', attribution)

    backend = []
    for xc in ['cpu', 'gpu']:
        rows = [r for r in runs if r['experiment'] == 'backend' and r['xc'] == xc]
        a = next(r for r in rows if r['ri'] == 'cpu')
        b = next(r for r in rows if r['ri'] == 'gpu')
        for name, field in [('External wall', 'workflow_wall_s'), ('Electronic EXX', 'exx_s'),
                            ('EXX forces', 'exx_force_s'), ('Remaining wall (derived)', 'wall_remainder_s')]:
            backend.append(dict(fixed_libxc=xc, timer=name, libri_cpu_s=a[field],
                                libri_gpu_s=b[field], seconds_saved=a[field] - b[field]))
    save_csv('backend-timers.csv', backend)

    focus = lookup['si216-g4']
    selected = [('External wall', 'workflow_wall_s'),
                ('Electronic EXX: cal_exx_elec', ELECTRONIC),
                ('EXX forces: cal_exx_force', FORCE),
                ('Remaining wall, subtracting the two EXX phases', 'wall_remainder_s'),
                ('EXX geometry preparation: cal_exx_ions', 'Exx_LRI.cal_exx_ions'),
                ('ELPA diagonalization: elpa_solve', 'DiagoElpaNative.elpa_solve'),
                ('Effective potential: Potential.cal_veff', 'Potential.cal_veff'),
                ('LibXC potential: v_xc_libxc', 'XC_Functional_Libxc.v_xc_libxc'),
                ('Local-potential grid integration: Gint.cal_gint_vl', 'Gint.cal_gint_vl')]
    # A timer missing from any sample is censored by the 1% output threshold.
    entries = []
    for label, key in selected:
        values = [focus[c].get(key) for c in CONFIGS]
        saved = values[0] - values[2] if all(v is not None for v in [values[0], values[2]]) else None
        entries.append([label] + [number(v) if v is not None else 'not fully printed' for v in values]
                       + [number(saved) if saved is not None else 'not fully printed'])
    main_delta = next(a for a in attribution if a['case'] == 'si216-g4' and a['comparison'] == 'baseline -> pr-resident')
    summary_rows = []
    for case in CASES:
        values = lookup[case]
        delta = next(a for a in attribution if a['case'] == case and a['comparison'] == 'baseline -> pr-resident')
        summary_rows.append([case] + [number(delta[k]) for k in
                                     ['wall_saved_s', 'electronic_exx_saved_s', 'exx_force_saved_s', 'remainder_saved_s']])
    parent_rows = []
    for case in CASES:
        a, b = lookup[case]['baseline'], lookup[case]['pr-resident']
        parent_rows.append([case, number(a['ESolver_KS.scf_loop']) + ' -> ' + number(b['ESolver_KS.scf_loop']),
                            number(a['ESolver_KS_LCAO.cal_force']) + ' -> ' + number(b['ESolver_KS_LCAO.cal_force'])])
    text = [
        '# Where the end-to-end time was reduced', '',
        'The final ABACUS timing tables locate the main savings in electronic exact exchange and exact-exchange forces. '
        'The call counts are unchanged: 8 electronic EXX calls for ideal Si64, 7 for ideal Si216, '
        '12 for displaced Si64, and one EXX-force call in every run. The change is time per call, with the same convergence work.', '',
        '**PR comparison, Si216 / 4 V100 GPUs.** All entries below are medians of the same two runs per configuration, in seconds. '
        'The two EXX rows and the derived remainder add up to the external wall time. The later diagnostic timers overlap '
        'the remainder or each other and must not be added to those rows.', '',
        table(['Timer / phase', 'Baseline GPU', 'PR default', 'PR + residency', 'Baseline -> resident seconds saved'], entries), '',
        f'The electronic EXX timer saves {number(main_delta["electronic_exx_saved_s"])} s and the EXX-force timer saves '
        f'{number(main_delta["exx_force_saved_s"])} s, together about {number(main_delta["exx_saved_over_wall_saved_percent"], 1)}% '
        f'of the {number(main_delta["wall_saved_s"])} s reduction in external wall time. '
        'EXX geometry preparation stays near 30–31 s and effective-potential work near 19.6 s. '
        'ELPA decreases by about 2 s; its baseline samples span 14.58–18.05 s and the resident samples 14.29–14.34 s. '
        'Those small sample counts and the shared node do not establish an ELPA optimization.', '',
        '**Baseline GPU -> PR + residency, all formal cases.** Positive values denote time saved; a negative remainder means '
        'the time outside the two EXX phases increased. The remainder includes other computation, communication/waiting and process launch/exit; '
        'it is calculated by subtraction, not measured by a separate timer.', '',
        table(['Case', 'Wall saved / s', 'Electronic EXX saved / s', 'EXX forces saved / s', 'Remainder saved / s'], summary_rows), '',
        'For Si216/16 GPUs, electronic EXX drops from 72.90 to 57.99 s and EXX forces from 87.29 to 65.13 s, '
        'saving 37.07 s inside those scopes. The external wall time saves 31.60 s because the derived remainder rises by 5.47 s. '
        'One visible increase is `Gint.cal_gint_vl`: 2.49 [2.48, 2.50] -> 2.82 [2.77, 2.86] -> 6.13 [6.10, 6.15] s '
        'for baseline/default/resident. This is local-potential grid integration, distinct from evaluating the LibXC functional. '
        '`HamiltLCAO.updateHk` and `HSolverLCAO.solve` contain this work, so their increases must not be counted again. '
        'ELPA remains essentially unchanged at 23.92 -> 23.97 s. A smaller grid-integration increase also appears in Si64 '
        '(single GPU: 2.32 -> 3.41 s; four GPUs: 1.43 -> 3.02 s). The existing timers do not establish why these increases occur.', '',
        '**Parent scopes.** Electronic EXX is included in the SCF loop, and EXX forces are included in the complete force calculation. '
        'These parent scopes show where the user-visible savings occur, but summing them with their children would double count.', '',
        table(['Case', 'SCF loop: baseline -> resident / s', 'Complete forces: baseline -> resident / s'], parent_rows), '',
        '**LibRI CPU -> GPU backend switch at the baseline commit.** Displaced Si64, four GPUs, one run per configuration; '
        'the LibXC backend is held fixed within each comparison.', '',
        table(['Fixed LibXC', 'Phase', 'LibRI CPU / s', 'LibRI GPU / s', 'Saved / s'],
              [[r['fixed_libxc'], r['timer'], number(r['libri_cpu_s']), number(r['libri_gpu_s']), number(r['seconds_saved'])]
               for r in backend]), '',
        'With LibXC fixed to CPU, electronic EXX drops from 59.53 to 29.04 s and EXX forces from 39.18 to 20.75 s. '
        'Together they save 48.92 s, while total wall time saves 47.49 s. ELPA stays at 5.86 -> 5.96 s '
        'and LibXC at 5.67 -> 5.57 s. The same localization is seen with LibXC fixed to GPU. '
        'Switching LibXC itself is a separate effect: its potential timer drops from 5.67 to 2.68 s with LibRI fixed to CPU, '
        'and from 5.57 to 2.62 s with LibRI fixed to GPU.', '',
        '**Interpretation and limits.** These are elapsed times from the final running log, recorded with MPI_Wtime in the MPI build '
        'on the logging rank. They include work and waits inside each function; they are not CUDA kernel timings or a sum across ranks. '
        'The default output suppresses timers below 1% of program time, so missing entries are kept as missing rather than zero. '
        'Per-run values are rounded by ABACUS to 0.01 s before aggregation. The plotted remainder combines these internal timers '
        'with the external MPI-launch wall clock and is an approximate diagnostic decomposition. '
        'With only two formal samples, minor changes and shared-node variation do not establish causation.', '',
        'The observed reduction is consistent with the PR optimizing packing, batch-plan reuse and data residency within LibRI. '
        'The application timing table does not separate host packing, host-to-device transfer, GPU GEMM, allocation or synchronization. '
        'Assigning an exact fraction to any of those operations would require additional profiling.', '',
        'The source scopes were checked in pinned ABACUS `4e9f1636b7ca`: '
        '`source/source_base/timer.cpp` (`MPI_Wtime` and the 1% display threshold), '
        '`source/source_base/global_file.cpp` (running log), '
        '`source/source_lcao/module_ri/exx_lri.hpp` (`cal_exx_elec` / `cal_exx_force`), '
        '`source/source_esolver/esolver_ks.cpp` and `esolver_ks_lcao.cpp` (parent scopes).', '',
        '![EXX phases and remaining wall time](results/timer-breakdown.png)', '',
        'Recompute the tables with `python3 scripts/analyze-timers.py`; add `--plot` to regenerate the PNG/SVG chart using matplotlib. '
        'The full printed timing table is exported to `results/timer-rows.csv`, all per-configuration medians/ranges to '
        '`results/timer-summary.csv`, and the differences to `results/timer-attribution.csv`.',
    ]
    (ROOT / 'TIMER_ANALYSIS.md').write_text('\n'.join(text) + '\n')
    if args.plot:
        plot(lookup)
    print(f'Parsed {len(runs)} final timing tables, {len(raw_rows)} timer rows; wrote TIMER_ANALYSIS.md.')


def plot(lookup):
    os.environ.setdefault('MPLCONFIGDIR', '/tmp/libri-pr17-timer-matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False,
                         'axes.spines.right': False, 'svg.fonttype': 'none'})
    figure, axes = plt.subplots(2, 2, figsize=(10.7, 7.5))
    colors = ['#3b6fad', '#168c68', '#c0c5cc']
    labels = ['Electronic EXX', 'EXX forces', 'Remaining wall (derived)']
    for ax, case in zip(axes.flat, CASES):
        values = lookup[case]
        bottoms = [0.0] * 3
        for key, color, label in zip(['exx_s', 'exx_force_s', 'wall_remainder_s'], colors, labels):
            heights = [values[c][key] for c in CONFIGS]
            ax.bar(range(3), heights, bottom=bottoms, color=color, width=0.63, label=label)
            for i, height in enumerate(heights):
                ax.text(i, bottoms[i] + height / 2, number(height, 1), ha='center', va='center',
                        color='white' if key != 'wall_remainder_s' else '#202631', fontsize=10)
            bottoms = [a + b for a, b in zip(bottoms, heights)]
        maximum = max(bottoms)
        for i, height in enumerate(bottoms):
            ax.text(i, height + 0.025 * maximum, number(height, 1), ha='center', fontsize=10)
        atoms, gpus = case.split('-g')
        ax.set_title(f'{atoms.replace("si", "Si")} / {gpus} V100 GPU' + ('s' if gpus != '1' else ''))
        ax.set_xticks(range(3), ['Baseline GPU', 'PR default', 'PR + residency'])
        ax.set_ylabel('Time (s)')
        ax.set_ylim(0, maximum * 1.14)
        ax.grid(axis='y', alpha=0.17)
        ax.set_axisbelow(True)
    handles, legend_labels = axes.flat[0].get_legend_handles_labels()
    figure.legend(handles, legend_labels, loc='upper center', bbox_to_anchor=(0.5, 0.94), ncol=3, frameon=False)
    figure.suptitle('LibRI PR #17: where HSE06 wall time decreased', fontsize=15, y=0.98)
    figure.text(0.5, 0.023, 'Two-run medians. Full initial GGA SCF, HSE06 SCF and forces included.\n'
                'EXX timings are from the logging rank; remainder = external wall minus the two EXX scopes.',
                ha='center', fontsize=9)
    figure.tight_layout(rect=(0, 0.075, 1, 0.89))
    for suffix in ['png', 'svg']:
        figure.savefig(ROOT / 'results' / f'timer-breakdown.{suffix}', dpi=180)
    plt.close(figure)


if __name__ == '__main__':
    main()
