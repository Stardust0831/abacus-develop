#!/usr/bin/env python3
"""Verify the packaged original evidence without launching ABACUS."""
import hashlib
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
NUMBER = r'[-+]?\d+(?:\.\d*)?(?:[EeDd][-+]?\d+)?'


def last(pattern, content):
    matches = re.findall(pattern, content, re.M)
    if not matches:
        raise AssertionError(f'missing output pattern: {pattern}')
    return matches[-1]


def main():
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    rows = json.loads((ROOT / 'results/runs.json').read_text())
    versions = json.loads((ROOT / 'versions.json').read_text())
    assert len(rows) == 31
    parsed = {}
    for row in rows:
        path = ROOT / row['evidence_dir']
        log = (path / 'OUT.si/running_scf.log').read_text()
        stdout = (path / 'launcher.log').read_text()
        effective = (path / 'OUT.si/INPUT.info').read_text()
        timing = (path / 'time.json').read_text()
        timer = json.loads(timing[timing.index('{'):])
        assert timer['exitcode'] == int((path / 'exitcode.txt').read_text()) == 0
        assert abs(timer['wall_s'] - row['workflow_wall_s']) < 1e-8
        assert '#SCF IS CONVERGED#' in log and 'Total  Time' in log and 'XC: HSE06' in log
        assert float(last(r'^\s*E_exx\s+\S+\s+(\S+)', log)) != 0
        residual = float(last(r'^\s*[A-Z]{2}\d+\s+' + NUMBER + r'\s+' + NUMBER
                              + r'\s+(' + NUMBER + r')\s+' + NUMBER, stdout))
        assert residual <= 1e-8
        for key, expected in [('symmetry', '-1'), ('exx_symmetry_realspace', '0'), ('gamma_only', '1')]:
            assert last(r'^\s*' + key + r'\s+(\S+)', effective) == expected
        forces = [tuple(map(float, f)) for f in re.findall(
            r'^\s*Si\d+\s+(' + NUMBER + r')\s+(' + NUMBER + r')\s+(' + NUMBER + r')\s*$', log, re.M)]
        assert len(forces) == row['atoms'] and all(math.isfinite(v) for f in forces for v in f)
        energy = float(last(r'!FINAL_ETOT_IS\s+(' + NUMBER + ')', log))
        assert abs(energy - row['energy_ev']) < 1e-9
        iterations = re.findall(r'^\s*[A-Z]{2}\d+\s+', stdout, re.M)
        marker = re.search(r'Entering 2nd SCF|Updating EXX and rerun SCF', stdout)
        assert marker
        first = len(re.findall(r'^\s*[A-Z]{2}\d+\s+', stdout[:marker.start()], re.M))
        assert (first, len(iterations) - first) == (row['pbe_iterations'], row['hse_iterations'])
        for name, digest in row['input_sha256'].items():
            assert hashlib.sha256((ROOT / 'cases' / row['input_case'] / name).read_bytes()).hexdigest() == digest
            if name in ['INPUT', 'STRU', 'KPT']:
                assert hashlib.sha256((path / name).read_bytes()).hexdigest() == digest
        assert (path / 'executable-sha256.txt').read_text().split()[0] == row['binary_sha256']
        binary_key = 'pr_binary_sha256' if row['configuration'] in ['pr-default', 'pr-resident'] else 'baseline_binary_sha256'
        assert row['binary_sha256'] == versions[binary_key]
        if row['experiment'] != 'backend':
            rank_times = list(path.glob('rank-*-time.json'))
            assert len(rank_times) == row['ranks']
            assert all(json.loads(p.read_text())['exitcode'] == 0 for p in rank_times)
        parsed[row['id']] = {'energy': energy, 'forces': forces, 'iterations': (first, len(iterations) - first)}
    maximum_energy = 0.0
    maximum_force = 0.0
    for row in rows:
        item = parsed[row['id']]
        reference = parsed[row['reference_id']]
        energy_delta = abs(item['energy'] - reference['energy']) / row['atoms']
        force_delta = max(math.sqrt(sum((a - b) ** 2 for a, b in zip(fa, fb)))
                          for fa, fb in zip(item['forces'], reference['forces']))
        assert energy_delta <= 1e-6 and force_delta <= 1e-5
        assert item['iterations'] == reference['iterations']
        maximum_energy = max(maximum_energy, energy_delta)
        maximum_force = max(maximum_force, force_delta)
    ctests = (ROOT / 'evidence/checks/libri-ctest.log').read_text()
    assert '100% tests passed, 0 tests failed out of 13' in ctests
    assert len(re.findall(r'Test\s+#\d+:.*Passed', ctests)) == 13
    print(f'PASS: {len(rows)} complete HSE06 energy/force runs; 13 LibRI CTests.')
    print(f'Maximum within-comparison energy difference: {maximum_energy:.6e} eV/atom')
    print(f'Maximum within-comparison force-vector difference: {maximum_force:.6e} eV/angstrom')


if __name__ == '__main__':
    main()
