# ABACUS HSE06 cases for LibRI PR #17

This package contains the inputs and original numerical evidence for switching LibRI between CPU and GPU at `0e8afc3`, and upgrading that GPU baseline to PR #17 at `5025261`, with C/V residency disabled or enabled. It also includes the original CP2K / ABACUS module comparison and the first GPU-library build's timings: 31 core runs plus 25 historical runs, 56 recorded calculations in total. `PR_COMMENT_DRAFT.md` contains the proposed discussion text. Full commits and executable identities are in `versions.json`; original module names and the CP2K commit are in `results/history-sources.json`.

The recorded calculations include initial GGA/PBE SCF, HSE06 SCF, and full atomic forces. Stress is disabled. The ABACUS cases use Gamma-only, nonmagnetic Si, fixed occupations, APNS v1 efficiency Si potential/orbitals, a 100 Ry cutoff, SCF=1e-8, RI PCA/C/V/DM=1e-4, HSE short-range exchange=0.25, omega=0.11 bohr^-1, and `exx_separate_loop=0`. All effective ABACUS inputs confirm `symmetry=-1`, `exx_symmetry_realspace=0`, and `gamma_only=1`. CP2K uses DZVP-MOLOPT-SR-GTH + cFIT3 ADMM with final force screening of 1e-6; its full settings and different accuracy/timer scope are documented in the historical analysis below.

| Case directory | Atoms | MPI ranks / V100 GPUs | Physical CPU cores | Eigensolver | Positions |
| --- | ---: | ---: | ---: | --- | --- |
| `cases/si64-g1` | 64 | 1 | 4 | cuSOLVER | Ideal diamond, a=5.431 angstrom |
| `cases/si64-g4` | 64 | 4 | 16 | ELPA | Ideal diamond |
| `cases/si216-g4` | 216 | 4 | 16 | ELPA | Ideal diamond |
| `cases/si216-g16` | 216 | 16 | 64 | ELPA | Ideal diamond |
| `cases/si64-displaced-g4` | 64 | 4 | 16 | ELPA | First atom shifted by (0.01, 0.02, -0.015) angstrom |

Each case contains all five required files: `INPUT`, `STRU`, `KPT`, `Si.upf`, and `Si_gga_7au_100Ry_2s2p1d.orb`. They are byte-identical to the corresponding executed inputs. Original metadata in the potential/orbital files is retained; asset provenance and checksums are recorded in `versions.json`. The main timing table uses ideal structures; the displaced cell provides nonzero-force validation.

## Inspect the recorded results

Run from this directory:

```bash
sha256sum --check --quiet SHA256SUMS
python3 scripts/verify.py
python3 scripts/analyze-timers.py
python3 scripts/analyze-history.py
```

`results/runs.json` and `results/runs.csv` contain 31 runs: four backend-switch cases, 24 PR timings, and three PR force-validation cases. The derived comparisons are in `results/backend-comparison.csv` and `results/pr-comparison.csv`. Original SCF/force logs, effective inputs, launch output, timer output, exit codes and executable hashes are under `evidence/runs/`. The existing scientific acceptance records and CTest log are under `evidence/checks/`. The verification script checks the packaged evidence, input identities, timings, convergence, HSE identification, complete forces, and numerical differences; it does not launch computations.

[TIMER_ANALYSIS.md](TIMER_ANALYSIS.md) locates the backend and PR savings in electronic EXX and EXX forces. [HISTORICAL_TIMERS.md](HISTORICAL_TIMERS.md) adds 25 historical runs: eight original-module timings, eight accepted CP2K timings, eight first-GPU timings, and a displaced module control. Their raw inputs, both CP2K phases, final logs, and allocation records are under `evidence/history/`, with reports/checks under `evidence/history-checks/`. `analyze-history.py` verifies those 25 runs before generating its analysis. The three historical post-calculation driver failures remain explicit; program exit codes and full numerical output are checked separately.

The complete printed timers and all-version medians/ranges are exported as CSV/JSON under `results/`. The analysis scripts regenerate the tables from original logs; `--plot` also regenerates their PNG/SVG charts and requires matplotlib. Other analysis uses Python's standard library. The CP2K `hfx_ks_matrix` timer includes both integrals and force derivatives; the analysis uses its child scopes to avoid double counting. Missing ABACUS timers below the display threshold are not treated as zero. Historical old/new ABACUS ratios include dependency/build differences; CP2K/ABACUS equal accuracy is not established.

For the original CP2K and ABACUS module cases, extract `evidence/history-checks/original/reproduce-inputs.tar.gz` into a fresh directory and follow its `README-REPRODUCE.md`. This archived input package includes the final input pairs, APNS assets and SAI Slurm launcher. It uses the pinned modules, including CP2K's installed basis/potential data files. The first GPU build uses the core ABACUS cases and baseline executable described below. All measurements in this archive predate these new timer-analysis scripts; no new calculations were launched to generate the analysis.

The backend-switch experiment used one ABACUS binary, four consecutive CPU/GPU combinations, and one fresh start per combination with backend tracing enabled. Its speedup is calculated while holding the LibXC backend fixed. The PR experiment used one allocation per size/resource group, two fresh starts per configuration, and the order baseline/default/resident/resident/default/baseline. Tracing was disabled for those timings. Every run started from atomic charge with no previous wavefunction reuse. The backend-switch and PR tables are separate experiments; their ratios should not be multiplied into a combined measured speedup.

## Rerun with the recorded ABACUS variants

Prepare two executables as described in `BUILD.md`, then load their matching MPI/CUDA/DDLA/LibXC and other runtime libraries. The `SAI_*` switches below are supplied by the included ABACUS patches and are not stock ABACUS input options. Set the baseline and PR executable paths:

```bash
export ABACUS_BASE=/absolute/path/to/baseline/abacus
export ABACUS_PR=/absolute/path/to/pr17/abacus
```

Inspect a plan without creating output or launching MPI:

```bash
python3 scripts/run.py --group pr-si64-g4 \
  --baseline "$ABACUS_BASE" --pr "$ABACUS_PR" --output /tmp/new-si64-g4 --dry-run
```

Within an existing single-node allocation with 4 V100 GPUs and 16 physical CPU cores, run the backend comparison or the displaced validation:

```bash
python3 scripts/run.py --group backend-si64-displaced-g4 \
  --baseline "$ABACUS_BASE" --output runs/backend
python3 scripts/run.py --group validation-si64-displaced-g4 \
  --baseline "$ABACUS_BASE" --pr "$ABACUS_PR" --output runs/validation
```

The four main timing groups are `pr-si64-g1`, `pr-si64-g4`, `pr-si216-g4`, and `pr-si216-g16`. Run each in a matching allocation. For example, submit from this directory on SAI after loading the runtime environment and selecting your account/QoS:

```bash
sbatch --account=YOUR_ACCOUNT --qos=flood-gpu \
  --ntasks=4 --gpus-per-node=4 scripts/run.sbatch \
  --group pr-si216-g4 --baseline "$ABACUS_BASE" --pr "$ABACUS_PR" \
  --output "$PWD/runs/si216-g4"
```

For Si64/1 GPU, use `--ntasks=1 --gpus-per-node=1` and the corresponding 1-GPU QoS. For Si216/16 GPUs, use `--ntasks=16 --gpus-per-node=16`. The SAI template uses partition `16V100`; other schedulers can invoke `scripts/run.py` directly inside their allocation. On the measured partition, Slurm allocated eight hardware threads and 15 GiB host RAM per GPU. MPI bound each rank to four physical CPU cores; OpenMP=4 and BLAS threads=1.

The helpers require Python 3, Bash, OpenMPI-compatible `mpirun`, GNU `time`, `timeout`, `sha256sum`, and `ldd`. Use a new output directory for each run. Runtime scripts are snapshotted before execution. The timer covers MPI launch and the full ABACUS calculation, excluding queue time, environment setup, file copying and evidence collection. The backend group launches ABACUS directly; the PR groups also use the same per-rank timer as the recorded PR runs. Check convergence and numerical results after a rerun; a zero process exit alone is not a scientific acceptance check.

## Scope of the evidence

The new portable helpers were assembled from the executed launch scripts and checked by syntax validation and plan inspection. The measurements in `evidence/` are from the original completed runs, whose launch scripts are preserved in `evidence/original-scripts/`.

The main PR comparison has two samples per configuration. The Si64/4-GPU and Si216/4-GPU jobs initially shared a node with distinct GPUs/CPU cores; their time ranges are preserved. These data do not establish universal speedups. In the pinned PR, batch-plan caching requires the base atom filter and is bypassed when EXX real-space symmetry selects `Filter_Atom_Symmetry`. C/V residency has no identical filter restriction, but its actual hit counts and resident bytes were not measured. Symmetry-enabled correctness tests passed; symmetry-enabled application performance was not measured.
