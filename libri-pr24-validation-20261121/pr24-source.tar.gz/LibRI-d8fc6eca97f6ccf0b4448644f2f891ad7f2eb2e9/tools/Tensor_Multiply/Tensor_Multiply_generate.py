# ===================
#  Author: Peize Lin
#  date: 2023.08.17
# ===================

import Tensor_Multiply
import Tensor_Multiply_UnitTest
import textwrap

def generate_cal(T_list, file_name):
	with open(file_name, "w") as file:
		file.write(textwrap.dedent("""\
			// ===================
			//  Author: Peize Lin
			//  date: 2023.08.03
			// ===================

			#pragma once

			#include "Tensor_Multiply.h"

			namespace RI
			{

			namespace Tensor_Multiply
			{
			"""))

		for Txy, Tx, Ty in T_list:
			Tensor_Multiply.generate_cal(Txy, Tx, Ty, file)
			print("", file=file)

		file.write(textwrap.dedent("""\
			}

			}
			"""))



def generate_test(T_list, file_name):
	with open(file_name, "w") as file:
		file.write(textwrap.dedent("""\
			// ===================
			//  Author: Peize Lin
			//  date: 2023.08.03
			// ===================

			#pragma once

			#include "Tensor_Multiply-test.hpp"

			#define FOR_0(i,N)	\
				for(std::size_t i=0; i<N; ++i)

			namespace Tensor_Multiply_Test
			{
			"""))

		for Txy, Tx, Ty in T_list:
			Tensor_Multiply_UnitTest.generate_test(Txy, Tx, Ty, file)
			print("", file=file)

		file.write(textwrap.dedent("""\
			}

			#undef FOR_0
			"""))





def generate_test_head(T_list, file_name):
	with open(file_name,"w") as file:
		file.write(textwrap.dedent("""\
			// ===================
			//  Author: Peize Lin
			//  date: 2023.08.03
			// ===================

			#pragma once

			#include "RI/global/Tensor_Multiply.h"

			namespace Tensor_Multiply_Test
			{
				template<typename Tdata>
				RI::Tensor<Tdata> init_tensor(const RI::Shape_Vector &shape)
				{
					RI::Tensor<Tdata> T(shape);
					const std::size_t size = T.shape.get_shape_all();
					for(std::size_t i=0; i<size; ++i)
						T.ptr()[i] = i;
					return T;
				}
			}

			#include "Tensor_Multiply-22-test.hpp"
			#include "Tensor_Multiply-23-test.hpp"
			#include "Tensor_Multiply-32-test.hpp"
			#include "Tensor_Multiply-33-test.hpp"

			namespace Tensor_Multiply_Test
			{
				template<typename Tdata>
				void main()
				{
			"""))

		for Txy, Tx, Ty in T_list:
			file.write(textwrap.indent(textwrap.dedent(f"""\
				{"".join(Txy)}_{"".join(Tx)}_{"".join(Ty)}_test<Tdata>();
				"""), "\t"*2))

		file.write(textwrap.dedent("""\
				}
			}
			"""))


T_list_all = {
	"22": [
			[["x0","y0"], ["x0","a"], ["y0","a"]],
			[["x0","y1"], ["x0","a"], ["a","y1"]],
			[["x1","y0"], ["a","x1"], ["y0","a"]],
			[["x1","y1"], ["a","x1"], ["a","y1"]],
		],
	"23": [
			[["x0","y0","y1"], ["x0","a"], ["y0","y1","a"]],
			[["x0","y1","y2"], ["x0","a"], ["a","y1","y2"]],
			[["x1","y0","y1"], ["a","x1"], ["y0","y1","a"]],
			[["x1","y1","y2"], ["a","x1"], ["a","y1","y2"]],
		],
	"32": [
			[["x0","x1","y0"], ["x0","x1","a"], ["y0","a"]],
			[["x0","x1","y1"], ["x0","x1","a"], ["a","y1"]],
			[["x1","x2","y0"], ["a","x1","x2"], ["y0","a"]],
			[["x1","x2","y1"], ["a","x1","x2"], ["a","y1"]],
		],
	"33": [
			[["x0","y0"], ["x0","a","b"], ["y0","a","b"]],
			[["x0","y2"], ["x0","a","b"], ["a","b","y2"]],
			[["x2","y0"], ["a","b","x2"], ["y0","a","b"]],
			[["x2","y2"], ["a","b","x2"], ["a","b","y2"]],
			[["x0","x1","y0","y1"], ["x0","x1","a"], ["y0","y1","a"]],
			[["x0","x1","y1","y2"], ["x0","x1","a"], ["a","y1","y2"]],
			[["x1","x2","y0","y1"], ["a","x1","x2"], ["y0","y1","a"]],
			[["x1","x2","y1","y2"], ["a","x1","x2"], ["a","y1","y2"]],
		  ],
}

for label,T_list in T_list_all.items():
	generate_cal(T_list, f"../../include/RI/global/Tensor_Multiply-{label}.hpp")
	generate_test(T_list, f"../../unittests/global/Tensor_Multiply-{label}-test.hpp")
generate_test_head(sum(T_list_all.values(),[]), "../../unittests/global/Tensor_Multiply-test.hpp")