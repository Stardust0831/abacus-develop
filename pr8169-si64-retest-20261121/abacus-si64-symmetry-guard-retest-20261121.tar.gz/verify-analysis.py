#!/usr/bin/env python3
"""Independent Decimal check of reported deltas/timing and failed-check retention."""
import copy
from decimal import Decimal
import importlib.util
import json
import math
from pathlib import Path
import re

root = Path(__file__).resolve().parent
report = json.loads((root/'analysis.json').read_text())
rows = json.loads((root/'summary.json').read_text())
raw = {}
for row in rows:
    run = (root/row['path']/'OUT.si/running_scf.log').read_text()
    energy_line = next(line for line in reversed(run.splitlines()) if '!FINAL_ETOT_IS' in line)
    energy = Decimal(energy_line.split()[1])
    block = run.split('#TOTAL-FORCE (eV/Angstrom)#')[-1]
    forces=[]
    for line in block.splitlines():
        cells=line.split()
        if len(cells)==4 and re.fullmatch(r'Si\d+',cells[0]):
            forces.append([Decimal(x) for x in cells[1:]])
    assert len(forces)==64
    time=json.loads((root/row['path']/'time.json').read_text(),parse_float=Decimal)
    exx={}
    for line in run.splitlines():
        cells=line.split()
        if len(cells)>=4 and cells[0]=='Exx_LRI' and cells[1] in ('cal_exx_elec','cal_exx_force'):
            exx[cells[1]]=Decimal(cells[2])
    remainder=time['wall_s']-exx['cal_exx_elec']-exx['cal_exx_force']
    assert abs(float(remainder)-row['remainder_s'])<1e-10
    raw[row['block'],row['structure'],row['variant']] = (energy,forces)
comparisons=[]
for c in report['comparisons']:
    ae,af=raw[c['block'],c['structure'],c['before']]
    be,bf=raw[c['block'],c['structure'],c['after']]
    de=abs(ae-be)/64
    df=max(sum((a-b)**2 for a,b in zip(f,g)).sqrt() for f,g in zip(af,bf))
    assert abs(float(de)-c['energy_delta_ev_atom'])<5e-14
    assert abs(float(df)-c['max_force_vector_delta_ev_angstrom'])<1e-15
    expected=de<=Decimal(str(c['energy_limit_ev_atom'])) and df<=Decimal(str(c['force_limit_ev_angstrom']))
    assert expected==c['passed']
    comparisons.append(dict(block=c['block'],structure=c['structure'],before=c['before'],after=c['after'],
                            decimal_energy_delta_ev_atom=str(de),decimal_max_force_vector_delta_ev_angstrom=str(df),passed=expected))
# Inject a known excessive error in memory only; verify failure is returned and
# the subsequent valid comparison still runs. Original files are never edited.
spec=importlib.util.spec_from_file_location('campaign_analyzer',root/'analyze.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
a=next(r for r in rows if r['variant']=='pr_cpu' and r['structure']=='ideal')
b=copy.deepcopy(a);b['variant']='pr_gpu';b['energy_ev']+=0.064;b['forces_ev_angstrom'][0][0]+=0.001
bad=module.compare(a,b,True)
good=module.compare(a,copy.deepcopy(a),True)
assert bad['passed'] is False and good['passed'] is True and len(module.checks)==2
assert module.limits=={'energy_ev_atom':1e-6,'force_vector_ev_angstrom':1e-5,'same_binary_energy_ev_atom':1e-8,'same_binary_force_vector_ev_angstrom':1e-6}
result=dict(passed=True,records=len(rows),independent_comparisons=comparisons,
            injected_error_retained=bad,subsequent_comparison_completed=good['passed'],
            input_files_changed=False)
(root/'audit/independent-analysis-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':True,'records':len(rows),'comparisons':len(comparisons),'injected_failure_preserved':True}))
