#!/usr/bin/env python3
import hashlib
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
previous = Path('/org/org-open-sai/proj-sai-hpc-software/runtime-tests/hse06-gpu-libs-20261120')
parser = argparse.ArgumentParser()
parser.add_argument('block', type=int, choices=(0, 1))
parser.add_argument('--displaced-only', action='store_true')
parser.add_argument('--print-plan', action='store_true')
args = parser.parse_args()
# Guard against accidentally dropping the recovery flag in a batch wrapper.
args.displaced_only = args.displaced_only or os.environ.get('SLURM_JOB_NAME') == 'pr8169-displaced-recover'
block = args.block
variants = ['module', 'experimental', 'pr_cpu', 'pr_gpu']
if block == 1:
    variants.reverse()
requests = [(variant, 'ideal') for variant in variants]
if block == 1:
    requests += [('pr_cpu', 'displaced'), ('pr_gpu', 'displaced')]
if args.displaced_only:
    if block != 1:
        raise ValueError('Displaced recovery belongs to logical block 1')
    requests = [('pr_cpu', 'displaced'), ('pr_gpu', 'displaced')]
if args.print_plan:
    print(json.dumps(requests))
    sys.exit(0)
prefix = 'recovery-' if args.displaced_only else ''
out = root / 'results' / f'{prefix}block{block}-{os.environ["SLURM_JOB_ID"]}'
out.mkdir(parents=True, exist_ok=False)
for name, command in [('allocation.txt', ['scontrol', 'show', 'job', '-o', os.environ['SLURM_JOB_ID']]),
                      ('lscpu.txt', ['lscpu']), ('gpu.txt', ['nvidia-smi', '-q'])]:
    with (out/name).open('w') as stream:
        subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True)
(out/'environment.json').write_text(json.dumps({k:v for k,v in os.environ.items()
    if k.startswith(('SLURM_', 'CUDA_', 'OMP_'))}, indent=2))
results = []
for index, (variant, structure) in enumerate(requests):
    name = 'abacus-si64-cusolvermp-loop0' if structure == 'ideal' else 'abacus-si64-displaced-normal'
    dest = out/f'{index:02d}-{structure}-{variant}'
    shutil.copytree(previous/'inputs'/name, dest)
    for data in (previous/'data').iterdir():
        shutil.copy2(data, dest/data.name)
    inp = dest/'INPUT'
    text = inp.read_text()
    solver_lines = [line for line in text.splitlines() if line.split() and line.split()[0] == 'ks_solver']
    assert len(solver_lines) == 1, solver_lines
    original_solver = solver_lines[0].split()[1]
    assert original_solver in ('elpa', 'cusolvermp', 'cusolver'), original_solver
    text = text.replace(solver_lines[0], 'ks_solver cusolver')
    if variant.startswith('pr_'):
        text += f'\ndevice_exx {variant[3:]}\n'
    inp.write_text(text)
    hashes = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir() if p.is_file()}
    request = dict(index=index, block=block, variant=variant, structure=structure,
                   input_hashes=hashes, start_unix=time.time(), job_id=os.environ['SLURM_JOB_ID'],
                   recovery=args.displaced_only, original_solver=original_solver,
                   frozen_input=str(previous/'inputs'/name))
    (dest/'request.json').write_text(json.dumps(request, indent=2)+'\n')
    print('START', dest.name, time.strftime('%FT%T%z'), flush=True)
    with (dest/'driver.log').open('w') as stream:
        process = subprocess.run(['bash', str(root/'run-case.sh'), str(dest), variant],
                                 stdout=stream, stderr=subprocess.STDOUT)
    request.update(exitcode=process.returncode, end_unix=time.time(), directory=str(dest))
    results.append(request)
    (out/'progress.json').write_text(json.dumps(results, indent=2)+'\n')
    print('END', dest.name, process.returncode, round(request['end_unix']-request['start_unix'], 2), flush=True)
    if process.returncode:
        sys.exit(process.returncode)
(out/'complete.txt').write_text(time.strftime('%FT%T%z')+'\n')
