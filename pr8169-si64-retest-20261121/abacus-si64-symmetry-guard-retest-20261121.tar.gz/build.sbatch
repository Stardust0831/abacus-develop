#!/bin/bash
#SBATCH --job-name=pr8169-symmetry-guard
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-gpu
#SBATCH --nodes=1
#SBATCH --ntasks=4
#SBATCH --gpus-per-node=4
#SBATCH --time=00:30:00
#SBATCH --output=build-%j.log
#SBATCH --export=ALL
set -euo pipefail
task_root=/org/org-open-sai/proj-sai-hpc-software/runtime-tests/abacus-libri-symmetry-benchmark-20261121
source_root=/org/org-open-sai/proj-sai-hpc-software/runtime-tests/abacus-pr8169-ready-20261121
previous=/org/org-open-sai/proj-sai-hpc-software/runtime-tests/hse06-gpu-libs-20261120
cd "$task_root"
source "$previous/build-env.sh"
source /opt/sai/runtime/mps_mapping.d/16V100.bash
set +u
module load libxc/7.0.0-auto
set -u
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export LD_LIBRARY_PATH="$previous/install/ddla/lib:${LD_LIBRARY_PATH:-}"
for backend in cpu gpu; do
  cmake --build "$source_root/build/abacus-$backend" --target MODULE_IO_read_item_serial --parallel 24 \
    > "logs/input-$backend-build.log" 2>&1
  ctest --test-dir "$source_root/build/abacus-$backend" -V -R '^MODULE_IO_read_item_serial$' \
    > "logs/input-$backend-test.log" 2>&1
done
cmake --build "$source_root/build/abacus-gpu" --target abacus_std_gpu --parallel 28 \
  > logs/abacus-build.log 2>&1
mkdir -p bin
cp "$source_root/build/abacus-gpu/abacus_std_gpu" bin/abacus-pr
sha256sum bin/abacus-pr > logs/abacus-sha256.txt
ldd bin/abacus-pr > logs/abacus-ldd.txt
bin/abacus-pr --version > logs/abacus-version.txt
bin/abacus-pr -h device_exx > logs/device-exx-help.txt
python3 check-input.py > logs/cli-test.log 2>&1
touch logs/build-passed
