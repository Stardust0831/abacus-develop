#!/bin/bash
#SBATCH --job-name=pr8169-si64-retest
#SBATCH --account=proj-sai-hpc-software
#SBATCH --partition=16V100
#SBATCH --qos=flood-1o2gpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gpus-per-node=1
#SBATCH --time=01:00:00
#SBATCH --output=campaign-%j.log
#SBATCH --export=ALL
set -euo pipefail
task_root=/org/org-open-sai/proj-sai-hpc-software/runtime-tests/abacus-libri-symmetry-benchmark-20261121
source /opt/sai/runtime/mps_mapping.d/16V100.bash
test -f "$task_root/logs/build-passed"
python3 -u "$task_root/campaign.py" "$1"
