**ABACUS HSE06 Si64 benchmark audit — FAIL — 2026-11-21**

There are 8/10 completed scientific run records, all retained in this report, including any failed checks. The complete analyzer reports 8/10 individual run checks passing and 8/8 numerical comparisons passing; the frozen-input, source and environment audit passes.

**Campaign failure:** job 2670089 exited 1 after the eight ideal runs had finished. The driver asserted that the displaced original INPUT must contain `ks_solver cusolvermp`, but that frozen INPUT contains `ks_solver elpa`. The CPU displaced directory was copied before this assertion; neither displaced executable was launched. The two force-validation runs therefore remain unperformed. This is a failed full benchmark check, regardless of the ideal-run performance results; no failed numerical comparison has been discarded. `audit/campaign-failure.json` and `campaign-2670089.log` preserve the evidence.

Current paired-node means reproduce the earlier approximately 10× full-build speedup: original module 842.83 s → experimental build 85.66 s, **9.84×**. The current PR CPU/GPU backend comparison is **2.95×** (252.59 → 85.60 s). Original module → current PR GPU is 9.85×. These are distinct comparisons: module → experimental includes build/dependency changes; module → PR additionally changes ABACUS source. Only pr_cpu → pr_gpu uses the same executable and dependencies with just device_exx changed.

**Current ideal-Si64 measurements, two repetitions per variant.** Each repetition is paired on one node; values are means with min–max ranges, in seconds. All wall times include the fresh GGA start, HSE SCF and forces.

| Variant | n | Wall mean [range] | Electronic EXX mean [range] | EXX force mean [range] | Remainder mean [range] |
| --- | --- | --- | --- | --- | --- |
| module | 2 | 842.83 [841.74–843.92] | 359.89 [359.71–360.08] | 398.01 [397.61–398.42] | 84.92 [84.05–85.79] |
| experimental | 2 | 85.66 [78.71–92.62] | 26.30 [23.86–28.73] | 29.11 [26.29–31.92] | 30.26 [28.56–31.97] |
| pr_cpu | 2 | 252.59 [252.45–252.73] | 104.27 [104.09–104.44] | 115.65 [115.36–115.93] | 32.68 [32.36–33.00] |
| pr_gpu | 2 | 85.60 [82.75–88.45] | 24.98 [24.55–25.41] | 28.02 [26.35–29.69] | 32.60 [31.85–33.35] |

The sole additive partition is `wall = Exx_LRI::cal_exx_elec + Exx_LRI::cal_exx_force + remainder`. Electronic EXX runs during SCF; EXX forces run afterward. Remainder is subtraction from `/usr/bin/time` elapsed time and includes all other computation, setup and launcher/container overhead. ABACUS timers are printed to 0.01 s. The setup done before the timed mpirun command is excluded from this wall time and is visible in campaign start/end timestamps.

**Paired speedups and wall-time savings.**

| Comparison | 16v100n14 speedup / saved | 16v100n22 speedup / saved | Ratio of means / mean saved |
| --- | --- | --- | --- |
| module → experimental | 10.694× / 763.03 s | 9.112× / 751.30 s | 9.839× / 757.16 s |
| module → pr_gpu | 10.172× / 758.99 s | 9.541× / 755.47 s | 9.846× / 757.23 s |
| pr_cpu → pr_gpu | 3.054× / 169.98 s | 2.854× / 164.00 s | 2.951× / 166.99 s |

| Comparison | Electronic EXX saved | EXX force saved | Remainder saved |
| --- | --- | --- | --- |
| module → experimental | 333.60 s (44.06%) | 368.91 s (48.72%) | 54.65 s (7.22%) |
| module → pr_gpu | 334.91 s (44.23%) | 370.00 s (48.86%) | 52.32 s (6.91%) |
| pr_cpu → pr_gpu | 79.28 s (47.48%) | 87.62 s (52.47%) | 0.08 s (0.05%) |

Percentages refer to the total wall saving; a negative component indicates time increased. The ratio of means is reported separately from the two node-paired ratios.

**Nested timing diagnostics, means in seconds. These overlap the additive partition and must not be added to it.**

| Variant | SCF parent | All-force parent | LCAO solver | LibXC potential | Effective potential | EXX ion setup |
| --- | --- | --- | --- | --- | --- | --- |
| module | 423.26 | 403.55 | 31.09 | 20.25 | 30.35 | unavailable |
| experimental | 46.25 | 30.62 | 7.99 | 4.03 | 10.16 | 2.42 |
| pr_cpu | 126.24 | 117.64 | 6.55 | 8.16 | 13.70 | 2.60 |
| pr_gpu | 46.98 | 29.89 | 6.59 | 8.18 | 13.70 | 2.65 |

Timer names are respectively `ESolver_KS::scf_loop`, `ESolver_KS_LCAO::cal_force`, `HSolverLCAO::solve`, `XC_Functional_Libxc::v_xc_libxc`, `Potential::cal_veff`, and `Exx_LRI::cal_exx_ions`. `Potential::update_from_charge` is a function/title, not the effective-potential timer. ABACUS suppresses timers smaller than 1% of total runtime; an absent diagnostic is unavailable, never zero. Solver and LibXC differences between builds cannot be assigned wholly to EXX acceleration.

**All requested run statuses.** Detailed force vectors, settings, hashes and every check are in `summary.json`, `analysis.json` and `asset-environment-audit.json`; `summary.csv` contains all observed timing columns. Missing runs have no invented timing or numerical data.

| Job / block | Structure / variant | Wall s | Electronic / force EXX s | GGA + HSE iterations | Final density residual | Energy eV | Run checks |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2670088 / 0 | ideal / module | 841.74 | 360.08 / 397.61 | 12 + 8 | 6.56734e-09 | -7244.018052984140 | PASS |
| 2670088 / 0 | ideal / experimental | 78.71 | 23.86 / 26.29 | 12 + 8 | 6.56521e-09 | -7244.018053122975 | PASS |
| 2670088 / 0 | ideal / pr_cpu | 252.73 | 104.44 / 115.93 | 12 + 8 | 6.567e-09 | -7244.018052984155 | PASS |
| 2670088 / 0 | ideal / pr_gpu | 82.75 | 24.55 / 26.35 | 12 + 8 | 6.56628e-09 | -7244.018052984093 | PASS |
| 2670089 / 1 | ideal / pr_gpu | 88.45 | 25.41 / 29.69 | 12 + 8 | 6.56664e-09 | -7244.018052984140 | PASS |
| 2670089 / 1 | ideal / pr_cpu | 252.45 | 104.09 / 115.36 | 12 + 8 | 6.56706e-09 | -7244.018052984151 | PASS |
| 2670089 / 1 | ideal / experimental | 92.62 | 28.73 / 31.92 | 12 + 8 | 6.56368e-09 | -7244.018053122973 | PASS |
| 2670089 / 1 | ideal / module | 843.92 | 359.71 / 398.42 | 12 + 8 | 6.56688e-09 | -7244.018052984137 | PASS |
| 2670089 / 1 | displaced / pr_cpu | — | — | — | — | — | NOT STARTED |
| 2670089 / 1 | displaced / pr_gpu | — | — | — | — | — | NOT STARTED |

Each run is required to have exit code 0 in both the shell and time record, a converged SCF with final density residual ≤1e-8, a normal end marker, finite total energy, nonzero finite EXX energy, 64 finite force vectors and EXX electronic/force timers. Iterations are counted separately before and after the HSE transition; both the launcher and detailed SCF logs are checked.

**Numerical comparisons with the original thresholds, without reference changes.** Cross-build comparisons use the original module on the same node: |ΔE|/64 ≤1e-6 eV/atom and max per-atom force-vector norm |ΔF| ≤1e-5 eV/Å. Same-PR CPU/GPU comparisons require ≤1e-8 eV/atom and ≤1e-6 eV/Å. Force-vector deltas are Euclidean norms, not maximum components.

| Block / structure | Comparison | |ΔE| eV/atom | max |ΔF| eV/Å | Energy / force result |
| --- | --- | --- | --- | --- |
| 0 / ideal | module → experimental | 2.1693e-09 | 1.27279e-09 | PASS / PASS |
| 0 / ideal | module → pr_cpu | 2.27374e-13 | 2.23607e-10 | PASS / PASS |
| 0 / ideal | module → pr_gpu | 7.38964e-13 | 4.58258e-10 | PASS / PASS |
| 0 / ideal | pr_cpu → pr_gpu | 9.66338e-13 | 3.16228e-10 | PASS / PASS |
| 1 / ideal | module → experimental | 2.1693e-09 | 1.27279e-09 | PASS / PASS |
| 1 / ideal | module → pr_cpu | 2.13163e-13 | 2.23607e-10 | PASS / PASS |
| 1 / ideal | module → pr_gpu | 4.26326e-14 | 3.16228e-10 | PASS / PASS |
| 1 / ideal | pr_cpu → pr_gpu | 1.7053e-13 | 1.41421e-10 | PASS / PASS |

| Structure | Variant | Block | Maximum force norm eV/Å |
| --- | --- | --- | --- |
| ideal | module | 0 | 1.10709e-05 |
| ideal | experimental | 0 | 1.10716e-05 |
| ideal | pr_cpu | 0 | 1.10708e-05 |
| ideal | pr_gpu | 0 | 1.10707e-05 |
| ideal | pr_gpu | 1 | 1.10707e-05 |
| ideal | pr_cpu | 1 | 1.10707e-05 |
| ideal | experimental | 1 | 1.10716e-05 |
| ideal | module | 1 | 1.10707e-05 |

All completed calculations use `symmetry -1`; the generated inputs confirm `exx_symmetry_realspace 0`. This respects the current GPU LibRI path supported by the PR and avoids relying on symmetry to make a force check look trivial. Ideal Si64 still has small numerical residual forces. The planned separate displaced structure moves only the first Si by (+0.01, +0.02, −0.015) Å, verified from the original fractional coordinates, and would need to yield a maximum force greater than 1e-3 eV/Å in both PR runs. That pair is designed to test nontrivial forces, with one CPU/GPU repetition and no displaced original-module comparator in this campaign. When those runs are absent, ideal-structure agreement alone does not validate nontrivial forces. No claim is made here about symmetry=1 support.

**Failed checks preserved:** 2; see the full entries below.
```json
[
  {
    "check": "all_ten_runs_present",
    "passed": false,
    "observed": 8,
    "missing": [
      [
        1,
        "displaced",
        "pr_cpu"
      ],
      [
        1,
        "displaced",
        "pr_gpu"
      ]
    ],
    "extra": []
  },
  {
    "check": "campaign_complete",
    "passed": false,
    "job_id": 2670089
  }
]
```

**Jobs, hardware and dataset.**

| Job | State | Exit | Node | Start | End | Elapsed |
| --- | --- | --- | --- | --- | --- | --- |
| 2670088 | COMPLETED | 0:0 | 16v100n14 | 2026-11-21T13:16:47 | 2026-11-21T13:38:18 | 00:21:31 |
| 2670089 | FAILED | 1:0 | 16v100n22 | 2026-11-21T13:16:47 | 2026-11-21T13:38:30 | 00:21:43 |

Benchmark jobs 2670088 (block 0) and 2670089 (block 1) were allocated on partition `16V100`, each with a one-hour limit, one Tesla V100-SXM2-16GB, one MPI rank, four OpenMP threads and BLAS thread count one. Both hosts have an AMD Ryzen Threadripper PRO 5995WX (64 physical cores, two SMT threads/core). Slurm allocates eight logical CPUs per GPU; `mpirun --map-by ppr:1:node:pe=4 --bind-to core` exposes four core pairs. The archived rank-placement probes and runtime thread summaries agree with this configuration; individual OpenMP thread scheduling was not sampled. The nodes were not requested exclusively. Raw `lscpu`, `nvidia-smi -q`, Slurm allocation, module, affinity and shared-library records are included.

Slurm times and campaign timestamps are Asia/Shanghai. The container’s internal text timestamps can be UTC, so elapsed `/usr/bin/time` values are used for timing. The scheduler start precedes the Python campaign START record by about one second. Block 0 runs module → experimental → pr_cpu → pr_gpu; block 1 reverses that order and then runs displaced pr_cpu → pr_gpu. This provides two independent nodes and both execution orders, but only two ideal repetitions and no statistical confidence interval.

The frozen dataset is Si64 in a 10.862 Å cubic cell, 832 LCAO basis functions, the APNS efficiency `Si_gga_7au_100Ry_2s2p1d.orb` orbital and `Si.upf`, Γ-only, double precision, 128 bands, 100 Ry, HSE06 (25% exact exchange, erfc ω=0.11), `scf_thr 1e-8`, `exx_separate_loop 0`, RI screening thresholds 1e-4, fresh atomic charge starts, forces on and stress off. Original input files come from `hse06-gpu-libs-20261120/inputs/{abacus-si64-cusolvermp-loop0,abacus-si64-displaced-normal}`; the completed ideal runs transform `ks_solver cusolvermp` → `cusolver`, plus the PR `device_exx` selector. The frozen displaced INPUT instead uses `elpa`; the driver failed its solver assertion before transforming or launching that pair. All original assets and run inputs were checked byte-for-byte with hashes. The unchanged original frozen INPUT files are separately archived.

| Asset | SHA256 |
| --- | --- |
| Si.upf | f7e77a752acc9d9a66409715ed5454752aa1ce6dad7d924cab3246fd30a3daec |
| Si_gga_7au_100Ry_2s2p1d.orb | 20ecb1f5b75f80065a5f47157d0024974cf6df1f035336ed192de2cb42521249 |

**Executable and source provenance.**

| Variant | ABACUS source / dependency scope | Executable or image SHA256 |
| --- | --- | --- |
| module | beta13 4e9f1636b7ca27d1dc634711915c18087654b911; original SAI container, CPU LibRI, CPU LibXC 7.0.0 | a085b32d873f6815e28e39342ad4fbcdf245c0488c2eec24ad9ff161a82ba531 (SIF image) |
| experimental | same beta13 source with recorded integration patch; GPU LibRI 0e8afc3931ee4cdf564699811ca220215570dd6b and GPU LibXC 3c7794c5047d5f19c088b856b24879ac7174ddfe | c4d2155489301a4d7a5bdd25e8da41d967a8b285b024bcfe9990c3825279a023 |
| pr_cpu / pr_gpu | f2667c6eed30e661a36bfb0ae1844802c99f171e; released LibRI v0.3.0.0 and CPU LibXC 7.0.0; only device_exx changes | 7a008e1274516d1c7d592c73bddd8afd24886bde147197dec7e96f9df2de0e64 |

Native builds use DDLA `7c0ca08b4349a527cec2a0c0af7d1a1082bd38c7`. The PR binary was built in existing job 2670062; CPU/GPU input unit-test logs, eight CLI guard cases, compile/link logs, CMake caches, source guard.patch and the original module build information are archived. All 7,693 tracked remote PR source files were checked against pinned commit f2667c6: 7,690 are byte-exact Git blobs and three Windows .bat files match after the CRLF checkout conversion explicitly required by .gitattributes. The actual SIF image was hashed and matches its catalog; both native executables were rehashed. Earlier source-verification records retained in provenance describe an older commit and are explicitly superseded by this campaign’s full-tree audit. A later coordinator docs-only commit does not change the executable identity reported here.

**Historical approximately 10× result, context only.** These are the earlier measurements, not repetitions from the current jobs, and are not pooled with the current sample.

| Historical variant | n | Wall mean [range] s | Electronic EXX s | EXX force s | Remainder s | LibXC s | Solver s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| module | 2 | 852.13 [850.56–853.70] | 364.28 | 402.31 | 85.54 | 20.94 | 29.55 |
| gpu-first | 2 | 84.50 [80.07–88.92] | 25.89 | 28.30 | 30.31 | 4.19 | 6.30 |

Historical wall speedup is 10.08×. Original-module repetitions came from job 2652177; experimental repetitions came from jobs 2655071 and 2655265. The experimental binary is identical to the one used now. Source records and historical timer rows are included under `historical/`; the current paired-node measurements are the evidence for this retest. Both historical and current module → experimental comparisons include compiler/build/dependency changes, so neither establishes an isolated 10× LibRI backend effect.

**Analysis changes and collection.** `audit/analyze-before.py` and `audit/collect-before.py` retain the supplied scripts. The revised analyzer corrects the effective-potential label, records all comparisons before returning a failure status, checks finite energies/forces and exact residuals, checks original hashes and runtime settings, reports sample ranges and retains all timings independently of numerical acceptance. Optional suppressed diagnostics remain null. The original numerical tolerances and reference inputs are unchanged. `audit-assets.py` independently checks frozen inputs, dependency links, geometry, source and recorded environment. No executable, build, submitted job or source code was modified by this audit.

The archive `abacus-si64-symmetry-guard-retest-20261121.tar.gz` contains all raw run inputs/assets and every task output ≤10 MiB, plus scripts, frozen originals, build/test/CLI logs and provenance. `raw-file-manifest.json` records paths, sizes and SHA256 hashes; larger omitted files have size/hash/reason entries. Wavefunctions, executables, build intermediates, coordinator PR drafts and worker task specifications are excluded. CLI PP_ORB symlink dependencies are materialized under `cli-assets/PP_ORB`; the original symlink is recorded without archiving it. The manifest intentionally does not hash itself. `archive-receipt.json` and `archive.sha256` are external companion receipts, avoiding a circular archive checksum. The collector verifies every archived member and payload hash before reporting success; local transfer verification is recorded separately.

Local task: `/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-symmetry-benchmark-20261121`. Remote task: `/org/org-open-sai/proj-sai-hpc-software/runtime-tests/abacus-libri-symmetry-benchmark-20261121`. To reproduce analysis on an extracted archive: `python3 analyze.py`, then `python3 audit-assets.py` and `python3 make-report.py`. The remote-only `capture-provenance.py` reads existing sources/build metadata; it does not launch computations.

Publication links: **[coordinator: evidence archive]**, **[coordinator: issue #52 update]**, **[coordinator: PR links]**.
