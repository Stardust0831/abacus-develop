#!/usr/bin/env python3
"""Audit the paired Si64 rerun and decompose wall-time savings."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys

root = Path(__file__).resolve().parent
num = r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?'
variants = ['module', 'experimental', 'pr_cpu', 'pr_gpu']
limits = {'energy_ev_atom': 1e-6, 'force_vector_ev_angstrom': 1e-5,
          'same_binary_energy_ev_atom': 1e-8, 'same_binary_force_vector_ev_angstrom': 1e-6}


def last(pattern, text):
    matches = re.findall(pattern, text, re.M)
    assert matches, pattern
    return matches[-1]


def timer(text, owner, name):
    matches = re.findall(r'^\s*' + re.escape(owner) + r'\s+' + re.escape(name)
                         + r'\s+(' + num + r')\s+(\d+)\s+', text, re.M)
    return (float(matches[-1][0]), int(matches[-1][1])) if matches else (None, None)


def parse(path):
    request = json.loads((path/'request.json').read_text())
    run = (path/'OUT.si/running_scf.log').read_text()
    stdout = (path/'launcher.log').read_text()
    elapsed = json.loads((path/'time.json').read_text())
    assert int((path/'exitcode.txt').read_text()) == elapsed['exitcode'] == 0
    assert '#SCF IS CONVERGED#' in run and 'Total  Time' in run
    energy = float(last(r'!FINAL_ETOT_IS\s+(' + num + ')', run))
    exchange = float(last(r'^\s*E_exx\s+' + num + r'\s+(' + num + ')', run))
    assert abs(exchange) > 1
    forces = [list(map(float, row)) for row in re.findall(
        r'^\s*Si\d+\s+(' + num + r')\s+(' + num + r')\s+(' + num + r')\s*$', run, re.M)]
    assert len(forces) == 64 and all(math.isfinite(x) for row in forces for x in row)
    pattern = r'^\s*[A-Z]{2}\d+\s+' + num + r'\s+' + num + r'\s+(' + num + r')\s+' + num
    residuals = [float(x) for x in re.findall(pattern, stdout, re.M)]
    marker = re.search(r'Entering 2nd SCF|Updating EXX and rerun SCF', stdout)
    assert marker and residuals and residuals[-1] <= 1e-8
    pbe = len(re.findall(pattern, stdout[:marker.start()], re.M))
    info = (path/'OUT.si/INPUT').read_text() if (path/'OUT.si/INPUT').exists() else (path/'OUT.si/INPUT.info').read_text()
    settings = dict(re.findall(r'^\s*(symmetry|exx_symmetry_realspace|gamma_only|cal_force|cal_stress|device_exx|device)\s+(\S+)', info, re.M))
    assert settings['symmetry'] == '-1'
    assert settings['cal_force'].lower() in ('1', 'true')
    assert settings['cal_stress'].lower() in ('0', 'false')
    assert settings['exx_symmetry_realspace'].lower() in ('0', 'false')
    assert settings['gamma_only'].lower() in ('1', 'true')
    if request['variant'].startswith('pr_'):
        assert settings['device_exx'] == request['variant'][3:]
    for name, digest in request['input_hashes'].items():
        assert hashlib.sha256((path/name).read_bytes()).hexdigest() == digest, (path, name)
    row = {k:request[k] for k in ('block', 'variant', 'structure')}
    row.update(path=str(path.relative_to(root)), wall_s=elapsed['wall_s'], energy_ev=energy,
               exx_energy_ev=exchange, forces_ev_angstrom=forces, pbe_iterations=pbe,
               hse_iterations=len(residuals)-pbe, final_residual=residuals[-1], settings=settings,
               input_hashes=request['input_hashes'],
               max_force_ev_angstrom=max(math.sqrt(sum(x*x for x in f)) for f in forces))
    labels = {'exx_electronic_s':('Exx_LRI', 'cal_exx_elec'),
              'exx_force_s':('Exx_LRI', 'cal_exx_force'), 'exx_ions_s':('Exx_LRI','cal_exx_ions'),
              'scf_s':('ESolver_KS','scf_loop'), 'force_s':('ESolver_KS_LCAO','cal_force'),
              'solver_s':('HSolverLCAO','solve'), 'libxc_s':('XC_Functional_Libxc','v_xc_libxc'),
              'effective_potential_s':('Potential','update_from_charge')}
    for key, pair in labels.items():
        row[key], calls = timer(run, *pair)
        if key in ('exx_electronic_s', 'exx_force_s'):
            row[key.replace('_s','_calls')] = calls
            assert row[key] is not None
    row['remainder_s'] = row['wall_s'] - row['exx_electronic_s'] - row['exx_force_s']
    row['node'] = last(r'\bNodeList=(\S+)', (path.parent/'allocation.txt').read_text())
    return row


rows = [parse(path.parent) for path in sorted((root/'results').glob('*/*/exitcode.txt'))]
(root/'summary.json').write_text(json.dumps(rows, indent=2)+'\n')
if '--partial' in sys.argv:
    print(json.dumps([{k:r[k] for k in ('block','variant','structure','wall_s','exx_electronic_s','exx_force_s','energy_ev','pbe_iterations','hse_iterations')}
                      for r in rows], indent=2))
    raise SystemExit
assert len(rows) == 10, len(rows)
comparisons = []
for block in (0, 1):
    subset = {r['variant']:r for r in rows if r['structure']=='ideal' and r['block']==block}
    assert set(subset) == set(variants)
    assert len({r['node'] for r in subset.values()}) == 1
    reference = subset['module']
    for variant, row in subset.items():
        for asset in ('STRU','KPT','Si.upf','Si_gga_7au_100Ry_2s2p1d.orb'):
            assert row['input_hashes'][asset] == reference['input_hashes'][asset]
        stripped = [line for line in (root/row['path']/'INPUT').read_text().splitlines()
                    if line.strip() and not line.startswith('device_exx ')]
        ref_text = [line for line in (root/reference['path']/'INPUT').read_text().splitlines() if line.strip()]
        assert stripped == ref_text
        delta_e = abs(row['energy_ev']-reference['energy_ev'])/64
        delta_f = max(math.sqrt(sum((a-b)**2 for a,b in zip(f,g)))
                      for f,g in zip(row['forces_ev_angstrom'],reference['forces_ev_angstrom']))
        assert delta_e <= limits['energy_ev_atom'] and delta_f <= limits['force_vector_ev_angstrom']
        comparisons.append(dict(block=block, variant=variant, energy_delta_ev_atom=delta_e,
                                max_force_vector_delta_ev_angstrom=delta_f))
for structure in ('ideal','displaced'):
    blocks = (0,1) if structure=='ideal' else (1,)
    for block in blocks:
        pair = {r['variant']:r for r in rows if r['structure']==structure and r['block']==block and r['variant'].startswith('pr_')}
        a,b = pair['pr_cpu'],pair['pr_gpu']
        delta_e = abs(a['energy_ev']-b['energy_ev'])/64
        delta_f = max(math.sqrt(sum((x-y)**2 for x,y in zip(f,g)))
                      for f,g in zip(a['forces_ev_angstrom'],b['forces_ev_angstrom']))
        assert delta_e <= limits['same_binary_energy_ev_atom'] and delta_f <= limits['same_binary_force_vector_ev_angstrom']
        if structure=='displaced':
            assert a['max_force_ev_angstrom'] > 1e-3
        comparisons.append(dict(block=block, structure=structure, variant='pr_cpu_vs_pr_gpu',
                                energy_delta_ev_atom=delta_e,max_force_vector_delta_ev_angstrom=delta_f))
keys=['wall_s','exx_electronic_s','exx_force_s','remainder_s','exx_ions_s','scf_s','force_s','solver_s','libxc_s','effective_potential_s']
groups={}
for variant in variants:
    selected=[r for r in rows if r['structure']=='ideal' and r['variant']==variant]
    group={'samples':2, 'range_wall_s':[min(r['wall_s'] for r in selected),max(r['wall_s'] for r in selected)]}
    for key in keys:
        values=[r[key] for r in selected]
        group[key]=statistics.mean(values) if all(x is not None for x in values) else None
    groups[variant]=group
decompositions=[]
for old,new in [('module','experimental'),('module','pr_gpu'),('pr_cpu','pr_gpu')]:
    a,b=groups[old],groups[new]
    saving=a['wall_s']-b['wall_s']
    phases=[]
    for key in ['exx_electronic_s','exx_force_s','remainder_s']:
        delta=a[key]-b[key]
        phases.append(dict(component=key,before=a[key],after=b[key],saved_s=delta,share_of_total_saving=delta/saving))
    decompositions.append(dict(before=old,after=new,speedup=a['wall_s']/b['wall_s'],saved_s=saving,phases=phases))
report=dict(passed=True,accepted_runs=len(rows),limits=limits,groups=groups,
            comparisons=comparisons,decompositions=decompositions,
            paired_speedups=[dict(block=block,before=old,after=new,speedup=
                next(r['wall_s'] for r in rows if r['block']==block and r['structure']=='ideal' and r['variant']==old)/
                next(r['wall_s'] for r in rows if r['block']==block and r['structure']=='ideal' and r['variant']==new))
                for block in (0,1) for old,new in [('module','experimental'),('module','pr_gpu'),('pr_cpu','pr_gpu')]])
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
with (root/'summary.csv').open('w') as output:
    fields=['block','node','structure','variant']+keys+['pbe_iterations','hse_iterations','energy_ev','max_force_ev_angstrom']
    writer=csv.DictWriter(output,fieldnames=fields,extrasaction='ignore'); writer.writeheader();writer.writerows(rows)
print(json.dumps({'passed':True,'groups':groups,'decompositions':decompositions},indent=2))
