#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
previous = Path('/org/org-open-sai/proj-sai-hpc-software/runtime-tests/hse06-gpu-libs-20261120')
block = int(sys.argv[1])
out = root / 'results' / f'block{block}-{os.environ["SLURM_JOB_ID"]}'
out.mkdir(parents=True, exist_ok=False)
for name, command in [('allocation.txt', ['scontrol', 'show', 'job', '-o', os.environ['SLURM_JOB_ID']]),
                      ('lscpu.txt', ['lscpu']), ('gpu.txt', ['nvidia-smi', '-q'])]:
    with (out/name).open('w') as stream:
        subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True)
(out/'environment.json').write_text(json.dumps({k:v for k,v in os.environ.items()
    if k.startswith(('SLURM_', 'CUDA_', 'OMP_'))}, indent=2))
variants = ['module', 'experimental', 'pr_cpu', 'pr_gpu']
if block == 1:
    variants.reverse()
requests = [(variant, 'ideal') for variant in variants]
if block == 1:
    requests += [('pr_cpu', 'displaced'), ('pr_gpu', 'displaced')]
results = []
for index, (variant, structure) in enumerate(requests):
    name = 'abacus-si64-cusolvermp-loop0' if structure == 'ideal' else 'abacus-si64-displaced-normal'
    dest = out/f'{index:02d}-{structure}-{variant}'
    shutil.copytree(previous/'inputs'/name, dest)
    for data in (previous/'data').iterdir():
        shutil.copy2(data, dest/data.name)
    inp = dest/'INPUT'
    text = inp.read_text()
    assert 'ks_solver cusolvermp' in text
    text = text.replace('ks_solver cusolvermp', 'ks_solver cusolver')
    if variant.startswith('pr_'):
        text += f'\ndevice_exx {variant[3:]}\n'
    inp.write_text(text)
    hashes = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir() if p.is_file()}
    request = dict(index=index, block=block, variant=variant, structure=structure,
                   input_hashes=hashes, start_unix=time.time())
    (dest/'request.json').write_text(json.dumps(request, indent=2)+'\n')
    print('START', dest.name, time.strftime('%FT%T%z'), flush=True)
    with (dest/'driver.log').open('w') as stream:
        process = subprocess.run(['bash', str(root/'run-case.sh'), str(dest), variant],
                                 stdout=stream, stderr=subprocess.STDOUT)
    request.update(exitcode=process.returncode, end_unix=time.time(), directory=str(dest))
    results.append(request)
    (out/'progress.json').write_text(json.dumps(results, indent=2)+'\n')
    print('END', dest.name, process.returncode, round(request['end_unix']-request['start_unix'], 2), flush=True)
    if process.returncode:
        sys.exit(process.returncode)
(out/'complete.txt').write_text(time.strftime('%FT%T%z')+'\n')
