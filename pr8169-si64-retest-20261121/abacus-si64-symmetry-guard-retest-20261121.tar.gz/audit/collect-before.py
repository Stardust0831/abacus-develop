#!/usr/bin/env python3
"""Collect reproducibility inputs and every small output for this campaign."""
import hashlib
import json
from pathlib import Path
import tarfile

root=Path(__file__).resolve().parent
selected={}
omitted=[]
for directory in ('results','logs','cli'):
    for path in (root/directory).rglob('*'):
        if not path.is_file() or path.is_symlink():
            continue
        name=str(path.relative_to(root))
        size=path.stat().st_size
        if size>10*1024*1024:
            omitted.append({'path':name,'bytes':size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        else:
            selected[name]=path
for path in root.iterdir():
    if path.is_file() and path.suffix in ('.py','.sh','.sbatch','.json','.csv','.log','.patch','.md'):
        selected[path.name]=path
manifest={'files':[{'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
                   for name,p in sorted(selected.items())],
          'omitted_over_10_mib':omitted,'not_included':['executables','build intermediates','public dependency sources']}
path=root/'raw-file-manifest.json'
path.write_text(json.dumps(manifest,indent=2)+'\n')
selected[path.name]=path
archive=root/'abacus-si64-symmetry-guard-retest-20261121.tar.gz'
with tarfile.open(archive,'w:gz') as output:
    for name,path in sorted(selected.items()):
        output.add(path,arcname=name,recursive=False)
print(json.dumps({'archive':archive.name,'files':len(selected),'bytes':archive.stat().st_size,
                  'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'omitted':len(omitted)}))
