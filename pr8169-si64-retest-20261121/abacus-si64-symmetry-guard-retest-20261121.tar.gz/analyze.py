#!/usr/bin/env python3
"""Audit all paired Si64 runs, preserving failures and non-additive diagnostics."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys

root = Path(__file__).resolve().parent
num = r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?'
variants = ['module', 'experimental', 'pr_cpu', 'pr_gpu']
limits = {'energy_ev_atom': 1e-6, 'force_vector_ev_angstrom': 1e-5,
          'same_binary_energy_ev_atom': 1e-8, 'same_binary_force_vector_ev_angstrom': 1e-6}
labels = {'exx_electronic_s': ('Exx_LRI', 'cal_exx_elec'),
          'exx_force_s': ('Exx_LRI', 'cal_exx_force'), 'exx_ions_s': ('Exx_LRI', 'cal_exx_ions'),
          'scf_s': ('ESolver_KS', 'scf_loop'), 'force_s': ('ESolver_KS_LCAO', 'cal_force'),
          'solver_s': ('HSolverLCAO', 'solve'), 'libxc_s': ('XC_Functional_Libxc', 'v_xc_libxc'),
          'effective_potential_s': ('Potential', 'cal_veff')}
keys = ['wall_s', 'exx_electronic_s', 'exx_force_s', 'remainder_s', 'exx_ions_s',
        'scf_s', 'force_s', 'solver_s', 'libxc_s', 'effective_potential_s']
checks = []


def check(name, passed, **details):
    checks.append(dict(check=name, passed=bool(passed), **details))
    return bool(passed)


def last(pattern, text):
    matches = re.findall(pattern, text, re.M)
    if not matches:
        raise ValueError('Missing pattern: ' + pattern)
    return matches[-1]


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def timer(text, owner, name):
    matches = re.findall(r'^\s*' + re.escape(owner) + r'\s+' + re.escape(name)
                         + r'\s+(' + num + r')\s+(\d+)\s+', text, re.M)
    return (float(matches[-1][0]), int(matches[-1][1])) if matches else (None, None)


def parameters(text):
    return {parts[0]: ' '.join(parts[1:]) for line in text.splitlines()
            if len(parts := line.split('#', 1)[0].split()) > 1}


def parse(path):
    request = json.loads((path/'request.json').read_text())
    row = {k: request[k] for k in ('block', 'variant', 'structure')}
    row.update(path=str(path.relative_to(root)), input_hashes=request['input_hashes'])
    row['job_id'] = int(request.get('job_id', path.parent.name.rsplit('-', 1)[1]))
    row['recovery'] = request.get('recovery', False)
    begin = len(checks)
    def audit(name, passed, **details):
        return check(name, passed, path=row['path'], **details)
    try:
        run = (path/'OUT.si/running_scf.log').read_text()
        stdout = (path/'launcher.log').read_text()
        elapsed = json.loads((path/'time.json').read_text())
        status = int((path/'exitcode.txt').read_text())
        row.update(exitcode=status, time_exitcode=elapsed['exitcode'], wall_s=elapsed['wall_s'],
                   scf_converged='#SCF IS CONVERGED#' in run,
                   normal_termination='Total  Time' in run)
        audit('exit_codes', status == elapsed['exitcode'] == 0, observed=[status, elapsed['exitcode']])
        audit('converged_and_normal_termination', row['scf_converged'] and row['normal_termination'])
        row['energy_ev'] = float(last(r'!FINAL_ETOT_IS\s+(' + num + ')', run))
        row['energy_ev_atom'] = row['energy_ev']/64
        row['exx_energy_ev'] = float(last(r'^\s*E_exx\s+' + num + r'\s+(' + num + ')', run))
        audit('finite_final_energy', math.isfinite(row['energy_ev']))
        audit('nonzero_finite_exx', math.isfinite(row['exx_energy_ev']) and abs(row['exx_energy_ev']) > 1,
              observed=row['exx_energy_ev'])
        force_text = run.split('#TOTAL-FORCE (eV/Angstrom)#')[-1]
        forces = [list(map(float, entry)) for entry in re.findall(
            r'^\s*Si\d+\s+(' + num + r')\s+(' + num + r')\s+(' + num + r')\s*$', force_text, re.M)]
        row.update(forces_ev_angstrom=forces, force_count=len(forces),
                   max_force_ev_angstrom=max((math.sqrt(sum(x*x for x in f)) for f in forces), default=None))
        audit('64_finite_force_vectors', len(forces) == 64 and all(math.isfinite(x) for f in forces for x in f),
              observed=len(forces))
        pattern = r'^\s*[A-Z]{2}\d+\s+' + num + r'\s+' + num + r'\s+(' + num + r')\s+' + num
        residuals = [float(x) for x in re.findall(pattern, stdout, re.M)]
        exact_residuals = [float(x) for x in re.findall(r'Electron density deviation\s*=\s*(' + num + ')', run)]
        marker = re.search(r'Entering 2nd SCF|Updating EXX and rerun SCF', stdout)
        pbe = len(re.findall(pattern, stdout[:marker.start()], re.M)) if marker else None
        row.update(pbe_iterations=pbe, hse_iterations=len(residuals)-pbe if pbe is not None else None,
                   final_residual=exact_residuals[-1] if exact_residuals else None,
                   stdout_final_residual=residuals[-1] if residuals else None)
        audit('gga_and_hse_iterations', marker is not None and pbe > 0 and row['hse_iterations'] > 0,
              observed=[pbe, row['hse_iterations']])
        audit('final_residual_threshold', bool(residuals and exact_residuals)
              and 0 <= residuals[-1] <= 1e-8 and 0 <= exact_residuals[-1] <= 1e-8,
              observed=row['final_residual'], limit=1e-8)
        audit('iteration_log_agreement', len(residuals) == len(exact_residuals),
              observed=[len(residuals), len(exact_residuals)])
        info_file = path/'OUT.si/INPUT'
        if not info_file.exists():
            info_file = path/'OUT.si/INPUT.info'
        all_settings = parameters(info_file.read_text())
        setting_names = ['symmetry', 'exx_symmetry_realspace', 'gamma_only', 'cal_force', 'cal_stress',
                         'device_exx', 'device', 'ks_solver', 'scf_thr', 'init_chg', 'nbands', 'ecutwfc',
                         'exx_separate_loop', 'dft_functional']
        row['settings'] = settings = {k: all_settings[k] for k in setting_names if k in all_settings}
        expected = dict(symmetry='-1', exx_symmetry_realspace='0', gamma_only='1', cal_force='1',
                        cal_stress='0', device='gpu', ks_solver='cusolver', init_chg='atomic', nbands='128',
                        exx_separate_loop='0', dft_functional='hse')
        for key, value in expected.items():
            observed = settings.get(key, '').lower().replace('false', '0').replace('true', '1')
            audit('setting_' + key, observed == value, expected=value, observed=settings.get(key))
        for key, value in [('scf_thr', 1e-8), ('ecutwfc', 100)]:
            audit('setting_' + key, float(settings.get(key, 'nan')) == value,
                  expected=value, observed=settings.get(key))
        if request['variant'].startswith('pr_'):
            audit('device_exx', settings.get('device_exx') == request['variant'][3:], observed=settings.get('device_exx'))
        row['input_parameters'] = parameters((path/'INPUT').read_text())
        actual_hashes = {name: digest(path/name) for name in request['input_hashes']}
        audit('original_request_asset_hashes', actual_hashes == request['input_hashes'], observed=actual_hashes)
        for key, pair in labels.items():
            row[key], calls = timer(run, *pair)
            row[key.removesuffix('_s') + '_calls'] = calls
            if key in ('exx_electronic_s', 'exx_force_s') or row[key] is not None:
                audit('timer_' + key, row[key] is not None and row[key] >= 0, observed=row[key], timer='::'.join(pair))
        # ABACUS print_all suppresses timers below 1% of total runtime.
        # A missing optional diagnostic is unavailable, never zero or a failed computation.
        row['unprinted_diagnostic_timers'] = [k for k in labels if row[k] is None]
        row['remainder_s'] = row['wall_s'] - row['exx_electronic_s'] - row['exx_force_s']
        audit('wall_positive_nonoverlapping_partition', math.isfinite(row['wall_s']) and row['wall_s'] > 0
              and row['remainder_s'] >= 0, observed=row['remainder_s'])
        audit('exx_call_counts', row['exx_electronic_calls'] == row['hse_iterations'] and row['exx_force_calls'] == 1,
              observed=[row['exx_electronic_calls'], row['exx_force_calls']])
        row['node'] = last(r'\bNodeList=(\S+)', (path.parent/'allocation.txt').read_text())
        row['executable_or_launcher_sha256'] = (path/'executable-or-launcher-sha256.txt').read_text().split()[0]
        expected_sha = {'experimental': 'c4d2155489301a4d7a5bdd25e8da41d967a8b285b024bcfe9990c3825279a023',
                        'pr_cpu': '7a008e1274516d1c7d592c73bddd8afd24886bde147197dec7e96f9df2de0e64',
                        'pr_gpu': '7a008e1274516d1c7d592c73bddd8afd24886bde147197dec7e96f9df2de0e64'}
        if row['variant'] in expected_sha:
            audit('executable_sha256', row['executable_or_launcher_sha256'] == expected_sha[row['variant']])
        run_settings = dict(line.split('=', 1) for line in (path/'run-settings.txt').read_text().splitlines())
        row['run_environment'] = run_settings
        audit('omp4_blas1_one_visible_gpu', run_settings.get('OMP_NUM_THREADS') == '4'
              and run_settings.get('OPENBLAS_NUM_THREADS') == '1'
              and len(run_settings.get('CUDA_VISIBLE_DEVICES', '').split(',')) == 1
              and bool(run_settings.get('CUDA_VISIBLE_DEVICES')))
        placement = (path/'rank-placement.txt').read_text()
        row['rank_affinity'] = last(r'current affinity list:\s*([^\n]+)', placement)
        audit('runtime_mpi1_omp4', bool(re.search(r'^\s*1\s+Gamma\s+1\s+4\s+4\s*$', stdout, re.M)))
    except (OSError, ValueError, TypeError, KeyError, IndexError, ZeroDivisionError) as error:
        row['parse_error'] = f'{type(error).__name__}: {error}'
        audit('parse_complete', False, error=row['parse_error'])
    row['run_checks_passed'] = all(c['passed'] for c in checks[begin:])
    return row


def compare(a, b, same_binary):
    identifier = dict(block=a['block'], structure=a['structure'], before=a['variant'], after=b['variant'],
                      comparison='same_PR_binary' if same_binary else 'cross_build')
    e_limit = limits['same_binary_energy_ev_atom' if same_binary else 'energy_ev_atom']
    f_limit = limits['same_binary_force_vector_ev_angstrom' if same_binary else 'force_vector_ev_angstrom']
    try:
        if len(a['forces_ev_angstrom']) != 64 or len(b['forces_ev_angstrom']) != 64:
            raise ValueError('Comparison requires 64 force vectors in both records')
        de = abs(a['energy_ev']-b['energy_ev']) / 64
        df = max(math.sqrt(sum((x-y)**2 for x, y in zip(f, g)))
                 for f, g in zip(a['forces_ev_angstrom'], b['forces_ev_angstrom']))
        identifier.update(energy_delta_ev_atom=de, max_force_vector_delta_ev_angstrom=df,
                          total_energy_delta_ev=abs(a['energy_ev']-b['energy_ev']),
                          energy_limit_ev_atom=e_limit, force_limit_ev_angstrom=f_limit,
                          energy_passed=math.isfinite(de) and de <= e_limit,
                          force_passed=math.isfinite(df) and df <= f_limit)
        identifier['passed'] = identifier['energy_passed'] and identifier['force_passed']
    except (ValueError, KeyError, TypeError) as error:
        identifier.update(passed=False, error=str(error))
    check('numerical_comparison', **identifier)
    return identifier


def main():
    partial = '--partial' in sys.argv
    paths = sorted((root/'results').glob('*/*/request.json'))
    rows = [parse(path.parent) for path in paths if not partial or (path.parent/'exitcode.txt').exists()]
    expected = {(block, 'ideal', variant) for block in (0, 1) for variant in variants}
    expected |= {(1, 'displaced', v) for v in ('pr_cpu', 'pr_gpu')}
    by_key = {(r['block'], r['structure'], r['variant']): r for r in rows}
    if not partial:
        check('all_ten_runs_present', len(rows) == 10 and set(by_key) == expected,
              observed=len(rows), missing=sorted(expected-set(by_key)), extra=sorted(set(by_key)-expected))
        manifest = json.loads((root/'manifest.json').read_text())
        recovery_jobs = manifest.get('recovery_jobs', [])
        for job in (2670088, 2670089):
            block = 0 if job == 2670088 else 1
            if job == 2670089 and recovery_jobs:
                check('original_ideal_runs_complete_before_driver_failure',
                      all((r := by_key.get((block, 'ideal', v))) and r.get('exitcode') == 0 for v in variants), job_id=job)
            else:
                check('campaign_complete', (root/f'results/block{block}-{job}/complete.txt').is_file(), job_id=job)
        for job in recovery_jobs:
            selected = [r for r in rows if r['job_id'] == job]
            check('recovery_campaign_complete', (root/f'results/recovery-block1-{job}/complete.txt').is_file(), job_id=job)
            check('recovery_exactly_missing_pair', len(selected) == 2
                  and {(r['structure'], r['variant']) for r in selected} == {('displaced','pr_cpu'),('displaced','pr_gpu')}, job_id=job)
    comparisons = []
    for block, structure, variant in sorted(by_key):
        row = by_key[block, structure, variant]
        reference = by_key.get((block, structure, 'module' if structure == 'ideal' else 'pr_cpu'))
        if reference:
            check('same_node', row.get('node') == reference.get('node') and row.get('node') is not None, path=row['path'])
            assets = ['STRU', 'KPT', 'Si.upf', 'Si_gga_7au_100Ry_2s2p1d.orb']
            check('paired_identical_assets', all(row['input_hashes'].get(a) == reference['input_hashes'].get(a) for a in assets), path=row['path'])
            clean = lambda r: {k: v for k, v in r.get('input_parameters', {}).items() if k != 'device_exx'}
            check('input_equal_except_device_exx', bool(clean(row)) and clean(row) == clean(reference), path=row['path'])
            if structure == 'ideal' and variant != 'module':
                comparisons.append(compare(reference, row, False))
        if variant == 'pr_gpu' and (cpu := by_key.get((block, structure, 'pr_cpu'))):
            comparisons.append(compare(cpu, row, True))
            if structure == 'displaced':
                check('displaced_nontrivial_forces', all((x.get('max_force_ev_angstrom') or 0) > 1e-3 for x in (cpu, row)),
                      observed=[cpu.get('max_force_ev_angstrom'), row.get('max_force_ev_angstrom')])
    # Include every available timing record regardless of numerical comparison outcome.
    groups = {}
    for variant in variants:
        selected = [r for r in rows if r['structure'] == 'ideal' and r['variant'] == variant]
        group = {'samples': len(selected), 'ranges_s': {}}
        for key in keys:
            values = [r.get(key) for r in selected]
            valid = bool(values) and all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)
            group[key] = statistics.mean(values) if valid else None
            group['ranges_s'][key] = [min(values), max(values)] if valid else None
        groups[variant] = group
    pairs = [('module', 'experimental'), ('module', 'pr_gpu'), ('pr_cpu', 'pr_gpu')]
    decompositions, paired = [], []
    for old, new in pairs:
        a, b = groups[old], groups[new]
        if a['wall_s'] and b['wall_s'] and all(a[k] is not None and b[k] is not None for k in keys[:4]):
            saving = a['wall_s'] - b['wall_s']
            phases = [dict(component=k, before=a[k], after=b[k], saved_s=a[k]-b[k],
                           share_of_total_saving=(a[k]-b[k])/saving if saving else None)
                      for k in ['exx_electronic_s', 'exx_force_s', 'remainder_s']]
            decompositions.append(dict(before=old, after=new, speedup=a['wall_s']/b['wall_s'], saved_s=saving, phases=phases))
        for block in (0, 1):
            aa, bb = by_key.get((block, 'ideal', old)), by_key.get((block, 'ideal', new))
            if aa and bb and aa.get('wall_s') and bb.get('wall_s'):
                paired.append(dict(block=block, node=aa.get('node'), before=old, after=new,
                                   speedup=aa['wall_s']/bb['wall_s'], saved_s=aa['wall_s']-bb['wall_s']))
    passed = all(c['passed'] for c in checks)
    report = dict(passed=passed, partial=partial, expected_runs=10, observed_runs=len(rows),
                  run_checks_passed=sum(r['run_checks_passed'] for r in rows), limits=limits, groups=groups,
                  comparisons=comparisons, decompositions=decompositions, paired_speedups=paired,
                  checks=checks, failed_checks=[c for c in checks if not c['passed']],
                  timer_labels={k: '::'.join(v) for k, v in labels.items()},
                  timing_note='Only wall = electronic EXX + EXX force + remainder is additive; all other timers are nested diagnostics. All timing records are retained even if a numerical check fails.')
    for name, value in [('summary.json', rows), ('analysis.json', report)]:
        (root/name).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
    with (root/'summary.csv').open('w', newline='') as output:
        fields = ['job_id', 'recovery', 'block', 'node', 'structure', 'variant', 'exitcode', 'run_checks_passed'] + keys + [
            'pbe_iterations', 'hse_iterations', 'final_residual', 'energy_ev', 'energy_ev_atom', 'exx_energy_ev', 'force_count', 'max_force_ev_angstrom']
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction='ignore')
        writer.writeheader(); writer.writerows(rows)
    print(json.dumps({k: report[k] for k in ('passed', 'partial', 'observed_runs', 'run_checks_passed', 'groups', 'failed_checks')}, indent=2))
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
