#!/bin/bash
set -eo pipefail
case_dir=$1
variant=$2
task_root=/org/org-open-sai/proj-sai-hpc-software/runtime-tests/abacus-libri-symmetry-benchmark-20261121
previous=/org/org-open-sai/proj-sai-hpc-software/runtime-tests/hse06-gpu-libs-20261120
unset SAI_GPU_TRACE SAI_RI_DEVICE SAI_LIBXC_DEVICE
if [[ "$variant" == module ]]; then
  source /etc/profile.d/lmod.sh
  module purge
  module use /home/stardust/sai-hpc-software/modulefiles/apps
  module load abacus/develop-beta-20261116-4e9f1636b7ca-rf678a701a42f-b5b5f95b9e21c
  binary=$(command -v abacus)
else
  source "$previous/build-env.sh"
  if [[ "$variant" == experimental ]]; then
    export LD_LIBRARY_PATH="$previous/install/ddla/lib:$previous/install/libxc/lib:${LD_LIBRARY_PATH:-}"
    export SAI_RI_DEVICE=gpu SAI_LIBXC_DEVICE=gpu
    binary="$previous/install/abacus/bin/abacus"
  else
    set +u
    module load libxc/7.0.0-auto
    set -u
    export LD_LIBRARY_PATH="$previous/install/ddla/lib:${LD_LIBRARY_PATH:-}"
    binary="$task_root/bin/abacus-pr"
  fi
fi
export OMP_NUM_THREADS=4 OMP_PLACES=cores OMP_PROC_BIND=close OMP_DYNAMIC=FALSE
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_EXPORT_ENV=ALL
export OMPI_MCA_plm_slurm_args=--external-launcher PRTE_MCA_plm_slurm_args=--external-launcher
cd "$case_dir"
(set +u; module -t list) > modules.txt 2>&1
sha256sum "$binary" > executable-or-launcher-sha256.txt
if [[ "$variant" != module ]]; then ldd "$binary" > linked-libraries.txt; fi
printf 'variant=%s\nOMP_NUM_THREADS=%s\nOPENBLAS_NUM_THREADS=%s\nCUDA_VISIBLE_DEVICES=%s\n' \
  "$variant" "$OMP_NUM_THREADS" "$OPENBLAS_NUM_THREADS" "${CUDA_VISIBLE_DEVICES:-}" > run-settings.txt
mpirun -np 1 --map-by ppr:1:node:pe=4 --bind-to core bash -c \
  'hostname; taskset -pc $$; printf "CUDA_VISIBLE_DEVICES=%s\n" "${CUDA_VISIBLE_DEVICES:-}"' > rank-placement.txt 2>&1
set +e
/usr/bin/time -f '{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kb":%M,"exitcode":%x}' \
  -o time.json timeout 3600 mpirun -np 1 --map-by ppr:1:node:pe=4 \
  --bind-to core "$binary" > launcher.log 2>&1
status=$?
printf '%s\n' "$status" > exitcode.txt
exit "$status"
