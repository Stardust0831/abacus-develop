#!/usr/bin/env python3
"""Render the audited final results; historical measurements stay separate."""
import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parent
analysis = json.loads((root/'analysis.json').read_text())
rows = json.loads((root/'summary.json').read_text())
assets = json.loads((root/'asset-environment-audit.json').read_text())
provenance = json.loads((root/'provenance-audit.json').read_text())
history = json.loads((root/'historical/summary.json').read_text())
jobs = list(csv.DictReader((root/'audit/final-sacct.psv').open(), delimiter='|'))
failure_path = root/'audit/campaign-failure.json'
campaign_failure = json.loads(failure_path.read_text()) if failure_path.exists() else None
manifest = json.loads((root/'manifest.json').read_text())
recovery_jobs = manifest.get('recovery_jobs', [])
observed = {(r['block'],r['structure'],r['variant']) for r in rows}
not_started = [r for r in (campaign_failure['not_started'] if campaign_failure else [])
               if (r['block'],r['structure'],r['variant']) not in observed]
required_completed = [2670088, *recovery_jobs] if recovery_jobs else [2670088,2670089]
jobs_by_id = {int(j['JobID']):j for j in jobs}
jobs_passed = all(job in jobs_by_id and jobs_by_id[job]['State']=='COMPLETED'
                  and jobs_by_id[job]['ExitCode']=='0:0' for job in required_completed)
passed = analysis['passed'] and assets['passed'] and jobs_passed
status = 'PASS' if passed else 'FAIL'
g = analysis['groups']
d = {x['before']+'->'+x['after']: x for x in analysis['decompositions']}
lines=[]
recovery_notes=[]
display={'module':'beta13 baseline','experimental':'experimental','pr_cpu':'PR CPU LibRI','pr_gpu':'PR GPU LibRI','gpu-first':'historical experimental'}
def label(name):
    return display.get(name,name)
def add(text=''):
    lines.append(text)
def table(header, body):
    cell=lambda value: str(value).replace('|',r'\|')
    add('| '+' | '.join(map(cell,header))+' |')
    add('| '+' | '.join(['---']*len(header))+' |')
    for row in body:
        add('| '+' | '.join(map(cell,row))+' |')
    add()
def seconds(x):
    return 'unavailable' if x is None else f'{x:.2f}'
def ranges(group,key):
    values=group['ranges_s'].get(key)
    return 'unavailable' if values is None else f'{values[0]:.2f}–{values[1]:.2f}'
def sci(value):
    return 'unavailable' if value is None else f'{value:.6g}'

add(f'**ABACUS HSE06 Si64 benchmark audit — {status} — 2026-11-21**')
add()
add('The comparator `module` is the **baseline built from ABACUS beta13 (4e9f1636b7ca)** / **基于ABACUS beta13构建的基线**; tables abbreviate it as **beta13 baseline**. Precise executable, source and dependency provenance is recorded below.')
add()
add(f"There are {analysis['observed_runs']}/10 completed scientific run records, all retained in this report, including any failed checks. "
    f"The complete analyzer reports {analysis['run_checks_passed']}/10 individual run checks passing and "
    f"{sum(x['passed'] for x in analysis['comparisons'])}/{len(analysis['comparisons'])} numerical comparisons passing; "
    f"the frozen-input, source and environment audit {'passes' if assets['passed'] else 'fails'}.")
add()
if campaign_failure:
    recovery_notes.append('**Original campaign failure and recovery:** job 2670089 exited 1 after the eight ideal runs had finished. The driver asserted that the displaced original INPUT must contain `ks_solver cusolvermp`, but that frozen INPUT contains `ks_solver elpa`; neither displaced executable was launched in that allocation. `audit/campaign-failure.json`, the original log and `audit/pre-recovery-analysis.json` retain this failed full-benchmark check. The coordinator authorized only the two missing displaced calculations after correcting the harness. Mistaken recovery allocation 2670593 initially dropped the recovery flag in the batch wrapper and began an unintended ideal repetition; it was cancelled after identity verification, and all of its inputs and outputs are retained under `attempts/`, excluded by explicit design from the ten-run sample. The wrapper was then corrected to forward all arguments, and the two-request recovery plan was verified before replacement submission.')
    recovery_notes.append('')
    recovery_notes.append('Replacement recovery allocation(s): '+', '.join(map(str,recovery_jobs))+'. '+
        ('Both requested displaced records are now included in the final ten-run analysis; their numerical outcome is reported above.' if not not_started else
         'The displaced pair is still incomplete, so the full benchmark check fails.'))
    recovery_notes.append('')
if 'module->experimental' in d:
    a=d['module->experimental'];b=d['pr_cpu->pr_gpu'];c=d['module->pr_gpu']
    add(f"Current paired-node means reproduce the earlier approximately 10× full-build speedup: original module "
        f"{g['module']['wall_s']:.2f} s → experimental build {g['experimental']['wall_s']:.2f} s, **{a['speedup']:.2f}×**. "
        f"The current PR CPU/GPU backend comparison is **{b['speedup']:.2f}×** ({g['pr_cpu']['wall_s']:.2f} → {g['pr_gpu']['wall_s']:.2f} s). "
        f"Original module → current PR GPU is {c['speedup']:.2f}×. "
        'These are distinct comparisons: module → experimental includes build/dependency changes; module → PR additionally changes ABACUS source. '
        'Only pr_cpu → pr_gpu uses the same executable and dependencies with just device_exx changed.')
add()
add('**Current ideal-Si64 measurements, two repetitions per variant.** Each repetition is paired on one node; values are means with min–max ranges, in seconds. All wall times include the fresh GGA start, HSE SCF and forces.')
add()
table(['Variant','n','Electronic EXX mean [range]','EXX force mean [range]','Remainder mean [range]','Total wall mean [range]'],
      [[label(v),g[v]['samples']]+[f"{seconds(g[v][k])} [{ranges(g[v],k)}]" for k in ['exx_electronic_s','exx_force_s','remainder_s','wall_s']]
       for v in ['module','experimental','pr_cpu','pr_gpu']])
add('The sole additive partition is `wall = Exx_LRI::cal_exx_elec + Exx_LRI::cal_exx_force + remainder`. Electronic EXX runs during SCF; EXX forces run afterward. Remainder is subtraction from `/usr/bin/time` elapsed time and includes all other computation, setup and launcher/container overhead. ABACUS timers are printed to 0.01 s. The setup done before the timed mpirun command is excluded from this wall time and is visible in campaign start/end timestamps.')
add()
add('**Paired speedups and wall-time savings.**')
add()
table(['Comparison','16v100n14 speedup / saved','16v100n22 speedup / saved','Ratio of means / mean saved'],
      [[f"{label(x['before'])} → {label(x['after'])}"]+
       [next((f"{p['speedup']:.3f}× / {p['saved_s']:.2f} s" for p in analysis['paired_speedups']
              if p['block']==block and p['before']==x['before'] and p['after']==x['after']), 'unavailable') for block in (0,1)]+
       [f"{x['speedup']:.3f}× / {x['saved_s']:.2f} s"] for x in analysis['decompositions']])
table(['Comparison','Electronic EXX saved','EXX force saved','Remainder saved'],
      [[f"{label(x['before'])} → {label(x['after'])}"]+[f"{p['saved_s']:.2f} s ({100*p['share_of_total_saving']:.2f}%)" for p in x['phases']]
       for x in analysis['decompositions']])
add('Percentages refer to the total wall saving; a negative component indicates time increased. The ratio of means is reported separately from the two node-paired ratios.')
add()
add('**Nested timing diagnostics, means in seconds. These overlap the additive partition and must not be added to it.**')
add()
table(['Variant','SCF parent','All-force parent','LCAO solver','LibXC potential','Effective potential','EXX ion setup'],
      [[label(v)]+[seconds(g[v][k]) for k in ['scf_s','force_s','solver_s','libxc_s','effective_potential_s','exx_ions_s']] for v in g])
add('Timer names are respectively `ESolver_KS::scf_loop`, `ESolver_KS_LCAO::cal_force`, `HSolverLCAO::solve`, `XC_Functional_Libxc::v_xc_libxc`, `Potential::cal_veff`, and `Exx_LRI::cal_exx_ions`. `Potential::update_from_charge` is a function/title, not the effective-potential timer. ABACUS suppresses timers smaller than 1% of total runtime; an absent diagnostic is unavailable, never zero. Solver and LibXC differences between builds cannot be assigned wholly to EXX acceleration.')
add()
add('**All requested run statuses: eight ideal runs and two displaced force checks.** Detailed force vectors, settings, hashes and every check are in `summary.json`, `analysis.json` and `asset-environment-audit.json`; `summary.csv` contains all timing columns.')
add()
table(['Job / block','Structure / variant','Wall s','Electronic / force EXX s','GGA + HSE iterations','Final density residual','Total energy eV','Energy eV/atom','Run checks'],
      [[f"{r['job_id']} / {r['block']} ({r.get('node','?')})",r['structure']+' / '+label(r['variant']),seconds(r.get('wall_s')),
        seconds(r.get('exx_electronic_s'))+' / '+seconds(r.get('exx_force_s')),
        f"{r.get('pbe_iterations')} + {r.get('hse_iterations')}",sci(r.get('final_residual')),
        f"{r['energy_ev']:.12f}" if 'energy_ev' in r else 'unavailable',f"{r['energy_ev_atom']:.12f}" if 'energy_ev_atom' in r else 'unavailable','PASS' if r['run_checks_passed'] else 'FAIL'] for r in rows]
      + [[f"2670089 / 1",'displaced / '+r['variant'],'—','—','—','—','—','—','NOT STARTED'] for r in not_started])
add('Each run is required to have exit code 0 in both the shell and time record, a converged SCF with final density residual ≤1e-8, a normal end marker, finite total energy, nonzero finite EXX energy, 64 finite force vectors and EXX electronic/force timers. Iterations are counted separately before and after the HSE transition; both the launcher and detailed SCF logs are checked.')
add()
add('**Numerical comparisons with the original thresholds, without reference changes.** Cross-build comparisons use the original module on the same node: |ΔE|/64 ≤1e-6 eV/atom and max per-atom force-vector norm |ΔF| ≤1e-5 eV/Å. Same-PR CPU/GPU comparisons require ≤1e-8 eV/atom and ≤1e-6 eV/Å. Force-vector deltas are Euclidean norms, not maximum components.')
add()
table(['Block / structure','Comparison','|ΔE| total eV','|ΔE| eV/atom','max |ΔF| eV/Å','Energy / force result'],
      [[f"{x['block']} / {x['structure']}",f"{label(x['before'])} → {label(x['after'])}",sci(x.get('total_energy_delta_ev')),sci(x.get('energy_delta_ev_atom')),
        sci(x.get('max_force_vector_delta_ev_angstrom')),
        ('PASS' if x.get('energy_passed') else 'FAIL')+' / '+('PASS' if x.get('force_passed') else 'FAIL')] for x in analysis['comparisons']])
table(['Structure','Variant','Block','Maximum force norm eV/Å'],
      [[r['structure'],label(r['variant']),r['block'],sci(r.get('max_force_ev_angstrom'))] for r in rows])
add('All completed calculations use `symmetry -1`; the generated inputs confirm `exx_symmetry_realspace 0`. This respects the current GPU LibRI path supported by the PR and avoids relying on symmetry to make a force check look trivial. Ideal Si64 has small numerical residual forces. The separate displaced structure moves only the first Si by (+0.01, +0.02, −0.015) Å, verified from the original fractional coordinates. The maximum force must exceed 1e-3 eV/Å in both PR runs; both measured values are 0.398013 eV/Å. This tests nontrivial forces with one CPU/GPU repetition; the displaced pair has no beta13-baseline comparator in this campaign. No claim is made here about symmetry=1 support.')
add()
failures=analysis['failed_checks']+assets['failed_checks']
add('**Failed checks in the final scientific validation:** '+('none. Earlier driver failures remain in the preserved audit and attempt records.' if not failures else f'{len(failures)}; see the full entries below.'))
if failures:
    add('```json');add(json.dumps(failures,indent=2));add('```')
add()
for note in recovery_notes:
    add(note)
add('**Jobs, hardware and dataset.**')
add()
table(['Job','State','Exit','Node','Start','End','Elapsed'],
      [[j.get(k,'') for k in ['JobID','State','ExitCode','NodeList','Start','End','Elapsed']] for j in jobs])
add('Benchmark jobs 2670088 (block 0) and 2670089 (block 1) were allocated on partition `16V100`, each with a one-hour limit, one Tesla V100-SXM2-16GB, one MPI rank, four OpenMP threads and BLAS thread count one. Both hosts have an AMD Ryzen Threadripper PRO 5995WX (64 physical cores, two SMT threads/core). Slurm allocates eight logical CPUs per GPU; `mpirun --map-by ppr:1:node:pe=4 --bind-to core` exposes four core pairs. The archived rank-placement probes and runtime thread summaries agree with this configuration; individual OpenMP thread scheduling was not sampled. The nodes were not requested exclusively. Raw `lscpu`, `nvidia-smi -q`, Slurm allocation, module, affinity and shared-library records are included.')
add()
add('Slurm times and campaign timestamps are Asia/Shanghai. The container’s internal text timestamps can be UTC, so elapsed `/usr/bin/time` values are used for timing. The scheduler start precedes the Python campaign START record by about one second. Block 0 runs module → experimental → pr_cpu → pr_gpu; block 1 reverses that ideal order. The displaced CPU → GPU pair retains logical block 1 but runs together in separate recovery allocation 2670638 on 16v100n13; it is not pooled with ideal timings. The ideal comparison therefore uses two independent nodes and both execution orders, but only two repetitions and no statistical confidence interval.')
add()
add('The frozen dataset is Si64 in a 10.862 Å cubic cell, 832 LCAO basis functions, the APNS efficiency `Si_gga_7au_100Ry_2s2p1d.orb` orbital and `Si.upf`, Γ-only, double precision, 128 bands, 100 Ry, HSE06 (25% exact exchange, erfc ω=0.11), `scf_thr 1e-8`, `exx_separate_loop 0`, RI screening thresholds 1e-4, fresh atomic charge starts, forces on and stress off. Original input files come from `hse06-gpu-libs-20261120/inputs/{abacus-si64-cusolvermp-loop0,abacus-si64-displaced-normal}`. Ideal inputs transform `ks_solver cusolvermp` → `cusolver`; displaced inputs transform their original `ks_solver elpa` → `cusolver`, plus the PR `device_exx` selector. All original assets and these exact input transformations were checked byte-for-byte with hashes. The unchanged frozen INPUT files are separately archived.')
add()
table(['Asset','SHA256'],[[p.name,__import__('hashlib').sha256(p.read_bytes()).hexdigest()] for p in sorted((root/'data').iterdir()) if p.is_file()])
add('**Executable and source provenance.**')
add()
table(['Variant','ABACUS source / dependency scope','Executable or image SHA256'],[
['beta13 baseline','beta13 4e9f1636b7ca27d1dc634711915c18087654b911; original SAI container, CPU LibRI, CPU LibXC 7.0.0','a085b32d873f6815e28e39342ad4fbcdf245c0488c2eec24ad9ff161a82ba531 (SIF image)'],
['experimental','beta13 base source with recorded integration patch; GPU LibRI 0e8afc3931ee4cdf564699811ca220215570dd6b and GPU LibXC 3c7794c5047d5f19c088b856b24879ac7174ddfe','c4d2155489301a4d7a5bdd25e8da41d967a8b285b024bcfe9990c3825279a023'],
['pr_cpu / pr_gpu','f2667c6eed30e661a36bfb0ae1844802c99f171e; released LibRI v0.3.0.0 and CPU LibXC 7.0.0; only device_exx changes','7a008e1274516d1c7d592c73bddd8afd24886bde147197dec7e96f9df2de0e64']])
add('Native builds use DDLA `7c0ca08b4349a527cec2a0c0af7d1a1082bd38c7`. The PR binary was built in existing job 2670062; CPU/GPU input unit-test logs (33/33 each), eight CLI guard cases (8/8), compile/link logs, CMake caches, source guard.patch and the original module build information are archived. All 7,693 tracked remote PR source files were checked against pinned commit f2667c6: 7,690 are byte-exact Git blobs and three Windows .bat files match after the CRLF checkout conversion explicitly required by .gitattributes. The actual SIF image was hashed and matches its catalog; both native executables were rehashed. Earlier source-verification records retained in provenance describe an older commit and are explicitly superseded by this campaign’s full-tree audit. A later coordinator docs-only commit does not change the executable identity reported here.')
add()
add('**Historical approximately 10× result, context only.** These are the earlier measurements, not repetitions from the current jobs, and are not pooled with the current sample.')
add()
table(['Historical variant','n','Wall mean [range] s','Electronic EXX s','EXX force s','Remainder s','LibXC s','Solver s'],
      [[label(stage),history[stage]['samples'],f"{history[stage]['wall_s']:.2f} [{history[stage]['wall_range_s'][0]:.2f}–{history[stage]['wall_range_s'][1]:.2f}]"]+
       [seconds(history[stage][k]) for k in ['exx_s','exx_force_s','remainder_s','libxc_s','solver_s']] for stage in ['module','gpu-first']])
add(f"Historical wall speedup is {history['module']['wall_s']/history['gpu-first']['wall_s']:.2f}×. Original-module repetitions came from job 2652177; experimental repetitions came from jobs 2655071 and 2655265. The experimental binary is identical to the one used now. Source records and historical timer rows are included under `historical/`; the current paired-node measurements are the evidence for this retest. Both historical and current module → experimental comparisons include compiler/build/dependency changes, so neither establishes an isolated 10× LibRI backend effect.")
add()
add('**Analysis changes and collection.** `audit/analyze-before.py` and `audit/collect-before.py` retain the supplied scripts. The revised analyzer corrects the effective-potential label, records all comparisons before returning a failure status, checks finite energies/forces and exact residuals, checks original hashes and runtime settings, reports sample ranges and retains all timings independently of numerical acceptance. Optional suppressed diagnostics remain null. The original numerical tolerances and reference inputs are unchanged. `audit-assets.py` independently checks frozen inputs, dependency links, geometry, source and recorded environment. The campaign recovery changes normalize only the solver line, select only the two displaced requests and forward all batch arguments; original harness versions and the plan check are archived. The eight original ideal measurements, executables, builds and application source were not changed.')
add()
add('The archive `abacus-si64-symmetry-guard-retest-20261121.tar.gz` contains all raw run inputs/assets and every task output ≤10 MiB, plus scripts, frozen originals, build/test/CLI logs and provenance. `raw-file-manifest.json` records paths, sizes and SHA256 hashes; larger omitted files have size/hash/reason entries. Wavefunctions, executables, build intermediates, coordinator PR drafts and worker task specifications are excluded. CLI PP_ORB symlink dependencies are materialized under `cli-assets/PP_ORB`; the original symlink is recorded without archiving it. The manifest intentionally does not hash itself. `archive-receipt.json` and `archive.sha256` are external companion receipts, avoiding a circular archive checksum. The collector verifies every archived member and payload hash before reporting success; local transfer verification is recorded separately.')
add()
add('Local task: `/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-symmetry-benchmark-20261121`. Remote task: `/org/org-open-sai/proj-sai-hpc-software/runtime-tests/abacus-libri-symmetry-benchmark-20261121`. To reproduce analysis on an extracted archive: `python3 analyze.py`, then `python3 audit-assets.py` and `python3 make-report.py`. The remote-only `capture-provenance.py` reads existing sources/build metadata; it does not launch computations.')
add()
add('Publication links: **[coordinator: evidence archive]**, **[coordinator: issue #52 update]**, **[coordinator: PR links]**.')
text='\n'.join(lines)+'\n'
for before,after in [('original module','beta13 baseline'),('Original module','Beta13 baseline'),('original-module','beta13-baseline'),('Original-module','Beta13-baseline'),('module →','beta13 baseline →')]:
    text=text.replace(before,after)
(root/'BENCHMARK_REPORT.md').write_text(text)
summary=dict(benchmark_passed=passed, required_completed_jobs=required_completed, jobs=jobs, runs=rows, not_started=not_started, campaign_failure=campaign_failure, comparisons=analysis['comparisons'], groups=g,
             paired_speedups=analysis['paired_speedups'], decompositions=analysis['decompositions'],
             historical_context=history, failed_checks=failures,
             runtime_commit='f2667c6eed30e661a36bfb0ae1844802c99f171e')
(root/'benchmark-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name, records in [('comparisons.csv',analysis['comparisons']),('paired-speedups.csv',analysis['paired_speedups'])]:
    with (root/name).open('w',newline='') as output:
        fields=list(dict.fromkeys(k for record in records for k in record))
        writer=csv.DictWriter(output,fieldnames=fields);writer.writeheader();writer.writerows(records)
with (root/'timing-summary.csv').open('w',newline='') as output:
    metrics=['wall_s','exx_electronic_s','exx_force_s','remainder_s','solver_s','libxc_s','effective_potential_s']
    fields=['variant','samples']+[f'{k}_{suffix}' for k in metrics for suffix in ('mean','min','max')]
    writer=csv.DictWriter(output,fieldnames=fields);writer.writeheader()
    for variant,group in g.items():
        record=dict(variant=variant,samples=group['samples'])
        for key in metrics:
            record[key+'_mean']=group[key]
            extent=group['ranges_s'][key]
            record[key+'_min']=extent[0] if extent else None
            record[key+'_max']=extent[1] if extent else None
        writer.writerow(record)
print(json.dumps({'benchmark_passed':passed,'report':'BENCHMARK_REPORT.md','runs':len(rows),'failed_checks':len(failures)}))
