#!/usr/bin/env python3
"""Read existing sources/build metadata; write evidence only inside this task."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
remote = Path('/org/org-open-sai/proj-sai-hpc-software/runtime-tests/abacus-libri-symmetry-benchmark-20261121')
assert root == remote, 'Run this capture script in the remote task directory only'
previous = remote.parent/'hse06-gpu-libs-20261120'
source = remote.parent/'abacus-pr8169-ready-20261121'
records = []


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024*1024), b''):
            h.update(data)
    return h.hexdigest()


def copy(src, relative):
    dest = root/relative
    assert dest.is_relative_to(root)
    if not src.is_file():
        records.append(dict(source=str(src), destination=str(relative), missing=True))
        return
    assert src.stat().st_size <= 10*1024*1024, str(src)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    records.append(dict(source=str(src), destination=str(relative), bytes=dest.stat().st_size, sha256=digest(dest)))


for name in ['abacus-si64-cusolvermp-loop0', 'abacus-si64-displaced-normal']:
    for path in sorted((previous/'inputs'/name).rglob('*')):
        if path.is_file():
            copy(path, Path('frozen-inputs')/name/path.relative_to(previous/'inputs'/name))
for path in sorted((previous/'data').rglob('*')):
    if path.is_file():
        copy(path, Path('data')/path.relative_to(previous/'data'))
for name in ['manifest.json', 'source-sha256.json', 'modified-files.json', 'patch-verification.json',
             'build-env.sh', 'build-abacus.sbatch', 'build-deps.sbatch', 'abacus-gpu-libs.patch', 'REPRODUCE.md']:
    copy(previous/name, Path('provenance/experimental')/name)
for path in sorted((previous/'logs').iterdir()):
    if path.is_file() and path.stat().st_size <= 10*1024*1024:
        copy(path, Path('provenance/experimental/logs')/path.name)
for name in ['source-verification.json', 'source-verification-before-guard.json', 'validate.sbatch']:
    copy(source/name, Path('provenance/pr')/name)
for backend in ['cpu', 'gpu']:
    copy(source/'build'/('abacus-'+backend)/'CMakeCache.txt', Path('provenance/pr')/('CMakeCache-'+backend+'.txt'))
for path in sorted((source/'logs').iterdir()):
    if path.is_file() and path.stat().st_size <= 10*1024*1024:
        copy(path, Path('provenance/pr/earlier-build-logs')/path.name)
manifest = json.loads((root/'manifest.json').read_text())
changed = {}
for name, expected in manifest['changed_files'].items():
    actual = digest(source/'abacus'/name)
    changed[name] = dict(expected_sha256=expected, actual_sha256=actual, passed=actual == expected)
    copy(source/'abacus'/name, Path('provenance/pr/source')/name)
for name in ['.gitattributes', 'source/source_base/timer.cpp', 'cmake/modules/FindLibRI.cmake', 'source/source_estate/module_pot/potential_new.cpp',
             'source/source_lcao/module_ri/exx_lri.hpp', 'source/source_hamilt/module_xc/libxc_pot.cpp']:
    copy(source/'abacus'/name, Path('provenance/pr/source')/name)
for name in ['source/source_estate/module_pot/potential_new.cpp', 'source/source_lcao/module_ri/exx_lri.hpp']:
    copy(previous/'src/abacus'/name, Path('provenance/experimental/source')/name)
# Materialize only assets referenced by the archived CLI validation inputs.
for name in ['Si_dojo_nsoc.upf', 'Si_dojo_6au_sz.orb']:
    copy(source/'abacus/tests/PP_ORB'/name, Path('cli-assets/PP_ORB')/name)
expected_tree = json.loads((root/'audit/pr-source-expected-tree.json').read_text())
tree_checks = []
for entry in expected_tree['entries']:
    if entry['type'] != 'blob':
        tree_checks.append(dict(path=entry['path'], skipped_type=entry['type']))
        continue
    path = source/'abacus'/entry['path']
    if not path.exists() and not path.is_symlink():
        tree_checks.append(dict(path=entry['path'], passed=False, missing=True))
        continue
    content = os.readlink(path).encode() if entry['mode'] == '120000' else path.read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    exact = actual == entry['git_blob_sha1']
    # The pinned .gitattributes explicitly checks out *.bat as CRLF.
    # Preserve the byte mismatch and verify Git's declared LF-normalized blob.
    lf = content.replace(b'\r\n', b'\n')
    normalized = hashlib.sha1(b'blob ' + str(len(lf)).encode() + b'\0' + lf).hexdigest()
    allowed_eol = path.suffix == '.bat' and '*.bat text eol=crlf' in (source/'abacus/.gitattributes').read_text()
    tree_checks.append(dict(path=entry['path'], passed=exact or (allowed_eol and normalized == entry['git_blob_sha1']),
                            byte_exact=exact, actual_git_blob_sha1=actual,
                            eol_normalized_match=allowed_eol and normalized == entry['git_blob_sha1']))
(root/'audit/pr-source-actual-tree.json').write_text(json.dumps(tree_checks, indent=2)+'\n')
binaries = {str(path): {'sha256': digest(path), 'bytes': path.stat().st_size}
            for path in [root/'bin/abacus-pr', previous/'install/abacus/bin/abacus']}
headers = {str(p.relative_to(source/'deps/LibRI-0.3.0.0')): digest(p)
           for p in sorted((source/'deps/LibRI-0.3.0.0/include').rglob('*')) if p.is_file()}
(root/'provenance/pr/libri-release-header-sha256.json').write_text(json.dumps(headers, indent=2)+'\n')
report = dict(pr_commit=expected_tree['commit'], changed_files=changed, binaries=binaries,
              full_source_compared=sum('passed' in x for x in tree_checks),
              full_source_mismatches=[x for x in tree_checks if x.get('passed') is False],
              full_source_crlf_checkouts=[x for x in tree_checks if x.get('byte_exact') is False and x.get('passed')],
              full_source_skipped=[x for x in tree_checks if 'skipped_type' in x],
              libri_release_header_count=len(headers), copies=records)
report['passed'] = all(x['passed'] for x in changed.values()) and not report['full_source_mismatches'] and not any(x.get('missing') for x in records)
(root/'provenance-audit.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k != 'copies'}, indent=2))
