#!/usr/bin/env python3
"""Verify frozen inputs, provenance, recorded runtime configuration and displacement."""
import hashlib
import json
import math
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parent
checks = []

def check(name, passed, **details):
    checks.append(dict(check=name, passed=bool(passed), **details))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def params(text):
    return {bits[0]: ' '.join(bits[1:]) for line in text.splitlines()
            if len(bits := line.split('#', 1)[0].split()) > 1}

rows = json.loads((root/'summary.json').read_text())
provenance = json.loads((root/'provenance-audit.json').read_text())
check('pinned_pr_source_tree', provenance['passed'], commit=provenance['pr_commit'],
      compared=provenance['full_source_compared'], mismatches=provenance['full_source_mismatches'],
      declared_crlf_checkouts=provenance['full_source_crlf_checkouts'])
for entry in provenance['copies']:
    check('copied_input_or_provenance_hash', not entry.get('missing') and sha(root/entry['destination']) == entry.get('sha256'), path=entry['destination'])
image = json.loads((root/'provenance/module/image-sha256-verification.json').read_text())
check('original_module_image', image['passed'] and image['actual_sha256'] == 'a085b32d873f6815e28e39342ad4fbcdf245c0488c2eec24ad9ff161a82ba531', evidence=image)
for row in rows:
    name = 'abacus-si64-cusolvermp-loop0' if row['structure'] == 'ideal' else 'abacus-si64-displaced-normal'
    source = root/'frozen-inputs'/name
    path = root/row['path']
    actual = (path/'INPUT').read_text()
    expected = (source/'INPUT').read_text()
    original_solver_lines = [line for line in expected.splitlines() if line.split() and line.split()[0]=='ks_solver']
    assert len(original_solver_lines)==1 and original_solver_lines[0].split()[1] in ('elpa','cusolvermp','cusolver')
    expected = expected.replace(original_solver_lines[0], 'ks_solver cusolver')
    if row['variant'].startswith('pr_'):
        expected += '\ndevice_exx ' + row['variant'][3:] + '\n'
    check('exact_input_transformation', actual == expected, path=row['path'])
    for asset in ['STRU', 'KPT']:
        check('frozen_input_asset', sha(path/asset) == sha(source/asset), path=row['path']+'/'+asset)
    for asset in ['Si.upf', 'Si_gga_7au_100Ry_2s2p1d.orb']:
        check('frozen_data_asset', sha(path/asset) == sha(root/'data'/asset), path=row['path']+'/'+asset)
    if row['variant'].startswith('pr_'):
        libs = (path/'linked-libraries.txt').read_text()
        check('standard_cpu_libxc_linked', '/opt/devtools/libxc/libxc-7.0.0-avx2/lib/libxc.so' in libs
              and '/hse06-gpu-libs-20261120/install/libxc/' not in libs, path=row['path'])
    if row['variant'] == 'experimental':
        libs = (path/'linked-libraries.txt').read_text()
        check('experimental_gpu_libxc_linked', '/hse06-gpu-libs-20261120/install/libxc/' in libs, path=row['path'])
    if row['variant'] != 'module':
        libs = (path/'linked-libraries.txt').read_text()
        check('native_ddla_linked', '/hse06-gpu-libs-20261120/install/ddla/' in libs, path=row['path'])
    mask = row['rank_affinity']
    cpus=[]
    for part in mask.split(','):
        bits=list(map(int,part.split('-')))
        cpus.extend(range(bits[0],bits[-1]+1))
    # Both nodes are single-socket 64-core/128-thread 5995WX machines;
    # the recorded masks have corresponding CPU IDs separated by 64.
    low = [c for c in cpus if c < 64]
    check('four_core_affinity_mask', len(low)==4 and set(cpus)==set(low + [c+64 for c in low]),
          path=row['path'], mask=mask, interpretation='four physical cores, two SMT siblings per core')


def stru(path):
    lines=[line.strip() for line in path.read_text().splitlines() if line.strip()]
    n=lines.index('ATOMIC_POSITIONS')
    assert lines[n+1]=='Direct' and lines[n+2]=='Si' and int(lines[n+4])==64
    coords=[list(map(float,line.split()[:3])) for line in lines[n+5:n+69]]
    m=lines.index('LATTICE_VECTORS')
    lattice=[list(map(float,line.split())) for line in lines[m+1:m+4]]
    lat0=float(lines[lines.index('LATTICE_CONSTANT')+1])
    return coords,lattice,lat0

ideal,lattice,lat0=stru(root/'frozen-inputs/abacus-si64-cusolvermp-loop0/STRU')
displaced,lattice_b,lat0_b=stru(root/'frozen-inputs/abacus-si64-displaced-normal/STRU')
check('same_lattice', lattice==lattice_b and lat0==lat0_b)
bohr_angstrom=0.529177210903
deltas=[[sum((b[j]-a[j])*lattice[j][k] for j in range(3))*lat0*bohr_angstrom for k in range(3)]
        for a,b in zip(ideal,displaced)]
check('only_first_si_displaced', all(abs(a-b)<1e-9 for a,b in zip(deltas[0],[0.01,0.02,-0.015]))
      and all(x==0 for row in deltas[1:] for x in row), observed_first_atom_angstrom=deltas[0])
cli=json.loads((root/'cli-validation.json').read_text())
check('cli_eight_expected_outcomes', len(cli)==8 and all(x['passed'] for x in cli), observed=cli)
for backend in ['cpu','gpu']:
    log=(root/f'logs/input-{backend}-test.log').read_text()
    check('input_unit_tests_'+backend, '100% tests passed, 0 tests failed' in log)
check('build_success_marker', (root/'logs/build-passed').is_file())
report=dict(passed=all(c['passed'] for c in checks), checks=checks,
            failed_checks=[c for c in checks if not c['passed']],
            displacement_angstrom=deltas[0],
            limitations=['Affinity is the recorded mpirun rank-placement probe using the same binding flags; per-thread scheduling during each calculation was not sampled.',
                         'OMP_PLACES/OMP_PROC_BIND/MKL_NUM_THREADS/SAI_RI_DEVICE/SAI_LIBXC_DEVICE are evidenced by the run script; runtime logs independently confirm MPI=1 and OpenMP=4.'])
(root/'asset-environment-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
sys.exit(0 if report['passed'] else 1)
