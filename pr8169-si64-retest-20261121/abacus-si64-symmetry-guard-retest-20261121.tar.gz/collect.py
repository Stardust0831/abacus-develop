#!/usr/bin/env python3
"""Archive all small task evidence; exclude artifacts, private drafts and compute binaries."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

root = Path(__file__).resolve().parent
limit = 10*1024*1024
archive_name = 'abacus-si64-symmetry-guard-retest-20261121.tar.gz'
selected, omitted = {}, []
excluded_generated = {'raw-file-manifest.json', archive_name, 'archive-receipt.json',
                      'archive-verification.json', 'archive.sha256', 'SHA256SUMS'}
excluded_directories = {'__pycache__', '.git', 'build', 'bin'}
evidence_dirs = ['results', 'attempts', 'logs', 'cli', 'frozen-inputs', 'data', 'provenance', 'audit', 'cli-assets', 'historical']


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def select(path):
    name = path.relative_to(root).as_posix()
    if path.is_symlink():
        omitted.append({'path': name, 'reason': 'symlink; referenced CLI assets materialized under cli-assets',
                        'target': str(path.readlink())})
        return
    if not path.is_file():
        return
    reason = None
    lower = path.name.lower()
    if path.name in excluded_generated or path.name.startswith('PR_BODY') or lower.startswith('pr-body'):
        return
    if lower.endswith('-task.md'):
        return
    if path.suffix in ('.gz', '.zip', '.xz', '.tar', '.pyc'):
        return
    if lower.startswith(('wfc', 'wavefunc', 'lowf')) or path.suffix.lower() in ('.wfc', '.o', '.a', '.so'):
        reason = 'wavefunction, binary or build intermediate'
    if 'bin' in path.relative_to(root).parts or 'build' in path.relative_to(root).parts:
        reason = 'binary or build intermediate'
    size = path.stat().st_size
    if size > limit:
        reason = 'over_10_mib' if reason is None else reason + '; over_10_mib'
    item = dict(path=name, bytes=size, sha256=sha256(path))
    if reason:
        omitted.append(dict(**item, reason=reason))
    else:
        selected[name] = (path, item)


for dirname in evidence_dirs:
    for path in sorted((root/dirname).rglob('*')):
        if '__pycache__' not in path.parts:
            select(path)
for path in sorted(root.iterdir()):
    if path.is_file():
        select(path)
for path in sorted((root/'bin').rglob('*')):
    select(path)
manifest = dict(files=[item for path, item in selected.values()], omitted=omitted,
                size_limit_bytes=limit,
                manifest_self_reference='raw-file-manifest.json is included in the archive but intentionally not hashed inside itself',
                excluded=['wavefunctions', 'binaries', 'build intermediates', 'dependency source distributions',
                          'PR_BODY*', 'pr-body*', '*-task.md', 'prior archives and archive receipts'])
manifest_path = root/'raw-file-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
selected[manifest_path.name] = (manifest_path, None)
archive = root/archive_name
with tarfile.open(archive, 'w:gz') as out:
    for name, (path, metadata) in sorted(selected.items()):
        out.add(path, arcname=name, recursive=False)
# Verify exact regular-file membership, safe relative paths, and every recorded payload hash.
with tarfile.open(archive, 'r:gz') as inp:
    members = inp.getmembers()
    names = [m.name for m in members]
    assert len(names) == len(set(names)) == len(selected)
    assert set(names) == set(selected)
    for member in members:
        assert member.isfile() and not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
        stream = inp.extractfile(member)
        actual = hashlib.sha256(stream.read()).hexdigest()
        metadata = selected[member.name][1]
        expected = metadata['sha256'] if metadata else sha256(manifest_path)
        assert actual == expected, member.name
receipt = dict(archive=archive_name, files=len(selected), bytes=archive.stat().st_size, sha256=sha256(archive),
               omitted=len(omitted), manifest_sha256=sha256(manifest_path), verified=True)
(root/'archive-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
(root/'archive.sha256').write_text(receipt['sha256']+'  '+archive_name+'\n')
print(json.dumps(receipt, indent=2))
