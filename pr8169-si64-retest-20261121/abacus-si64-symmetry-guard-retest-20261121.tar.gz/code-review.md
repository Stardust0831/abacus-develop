已完成只读独立评审。检出 HEAD 为 `f2667c6eed30e661a36bfb0ae1844802c99f171e`，工作区干净；本次范围为 `64b7ef6133bf1f36de2b87276889e67b5245177c..f2667c6` 的三个文件，参数来源对照完整 PR 基线 `5664ee7818f8da6c8dfe3c16e4bf0eb84d72967e`。已阅读父目录及源码根目录的 AGENTS.md、完整 agent_governance.md 和治理评审说明。

结论：对最终生效的参数，新限制满足要求：GPU EXX 的 `symmetry 1` 无论 realspace 为 true、false/0 或默认值都会报错，CPU RI 以及 GPU `symmetry 0/-1` 保持可用；本次没有新增 INPUT 参数。未发现本次新增的计算正确性阻塞项；“任何原始 INPUT 写了 symmetry 1 都拒绝且不改设置”的更强表述，有一项既有 reset 行为造成的边界，见下文 warning。

`exx_symmetry_realspace` **不是本 PR 引入的参数**：基线的 [read_inp_exx_dftu.cpp](https://github.com/deepmodeling/abacus-develop/blob/5664ee7818f8da6c8dfe3c16e4bf0eb84d72967e/source/source_io/module_parameter/read_inp_exx_dftu.cpp#L609) 已注册它，616 行默认 `True`，620–622 行已有非 symmetry 1 时重置为 false 的规则；基线 [input_parameter.h:695](https://github.com/deepmodeling/abacus-develop/blob/5664ee7818f8da6c8dfe3c16e4bf0eb84d72967e/source/source_io/module_parameter/input_parameter.h#L695) 也已有 `bool exx_symmetry_realspace = true`。完整 PR 的参数目录仅修改两份文件，逐版本比较 `Input_Item` 字面量名称，唯一净新增名称是 `device_exx`，本次提交净新增名称为空；后端选择最早由 `f07d8d14f39d26782490cc4bc15d0a58c5700e62`（2026-10-18，原名 `exx_device`）引入，`3fa1f972b60b95767c10f2a14b30fe237f96dedb`（2026-10-20）改名为 `device_exx`。

| 检查项 | 源码证据与判断 |
| --- | --- |
| 实际拒绝条件 | [read_inp_exx_dftu.cpp:259](/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-pr-ready-20261121/abacus/source/source_io/module_parameter/read_inp_exx_dftu.cpp:259)：264 行限定 `device_exx == "gpu"`，273 行只判断 `symmetry == "1"`，已去掉对 realspace 的依赖；回调接受 `const Parameter&`，只诊断退出，不修改设置。 |
| CPU/GPU 编译分支 | 同文件 266–279 行先检查 LCAO/device，再检查 `__GPU_RI`；未编入 GPU RI 时拒绝所有 `device_exx gpu`，编入后才执行 symmetry 限制。CPU 选择跳过这些 GPU 限制。 |
| 宏与构建开关 | [CMakeLists.txt:76](/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-pr-ready-20261121/abacus/CMakeLists.txt:76)：`ENABLE_LIBRI_GPU` 默认 OFF 且依赖 LibRI/CUDA；[FindLibRI.cmake:55](/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-pr-ready-20261121/abacus/cmake/modules/FindLibRI.cmake:55) 定义 `__GPU_RI`。`source/CMakeLists.txt:121,413,546` 将依赖的编译宏传给解析器及测试目标，serial 测试禁用 CUDA/MPI 宏不会取消 `__GPU_RI`。 |
| 默认值及顺序 | [input_parameter.h:681](/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-pr-ready-20261121/abacus/source/source_io/module_parameter/input_parameter.h:681) 与元数据一致，`device_exx` 默认 cpu；realspace 默认 true。[read_input.cpp:462](/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-pr-ready-20261121/abacus/source/source_io/module_parameter/read_input.cpp:462) 先读取全部显式值，再于 474–483 行执行所有 reset，最后在 253–265 行执行 check，且 check 遍历全部注册项。普通多 k SCF 的默认 symmetry 在系统 reset 中成为 1，随后被 guard 拒绝；realspace 的注册位置靠后不会造成漏检。 |
| 测试及文档 | [test_read_inp_exx_dftu.cpp:62](/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-pr-ready-20261121/abacus/source/source_io/unittests/test_read_inp_exx_dftu.cpp:62) 覆盖 GPU symmetry 1 的 true/false 拒绝、0/-1 接受及无 GPU RI 编译分支；28–38、80–85 行保留默认 CPU 和 CPU symmetry 1。两个参数的帮助文本及 [install.md:88](/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-pr-ready-20261121/abacus/docs/advanced/install.md:88) 均已说明新限制，无须提交生成的参数文档。 |

一项非阻塞评审提示：

Rule: INPUT behavior linkage / Documentation sync  
Severity: warning  
Location: `read_inp_exx_dftu.cpp:273`；`docs/advanced/install.md:93`  
Reason: guard 读取 reset 后的值。例如原始 INPUT 同时指定 `calculation md`、`device_exx gpu`、`symmetry 1` 时，[read_inp_sys.cpp:360](/home/stardust/orca/workspaces/sai-hpc-software/cp2k/.work/abacus-libri-pr-ready-20261121/abacus/source/source_io/module_parameter/read_inp_sys.cpp:360) 会先把 symmetry 改为 0，随后 realspace 也重置为 false，因此不会触发这个 symmetry 错误。该规则在 PR 基线已存在，最终执行的是 symmetry 0，没有证据表明危险的 GPU symmetry 1 路径因此可达；但安装说明的“不改变请求设置”不能不加范围地涵盖所有输入。  
Suggested action: 将说明限定为“最终生效的 symmetry 1”，或若严格要求所有显式 symmetry 1 请求均报错，在已有参数校验中使用 reset 前的显式值，并增加一个 MD 组合的针对性测试；两者均无需新增 INPUT 参数。现有单测直接调用 check 回调，所提供的八组 CLI 案例也未覆盖 MD/reset 组合。  
Exception: human approval required（输入语义范围由维护者裁定；不将既有 reset 自动视为本次合并阻塞项）。

本次实际验证包括 Git 差异/历史、调用顺序及编译宏传递检查、参数注册名称对比，以及三份变更文件与 `manifest.json` 的 SHA-256 对照（全部相符）；`git diff --check 64b7ef6133bf1f36de2b87276889e67b5245177c f2667c6eed30e661a36bfb0ae1844802c99f171e` 返回 0。任务提供的 SAI 作业 `2670062` 已通过构建、CPU/GPU INPUT 套件各 33/33 和 CLI 8/8；已核对本地 `check-input.py` 的八组定义覆盖 true/false/默认及允许路径，本次未独立读取远端原始运行日志、未重跑测试，也未进行数值/性能验证。该评审仅证明输入限制及参数来源，不能据此认定 LibRI GPU symmetry 已修复，或推广为所有 CPU/GPU 物理结果等价。

2026-11-21 文档澄清后续（本条关闭上面的 warning）：协调者已明确要求是阻止实际 GPU EXX 使用空间对称性，保留正常 INPUT reset 语义，现有有效值 guard 满足要求。仅修改源码树内 `docs/advanced/install.md`，说明检查发生在正常 INPUT 处理之后，拒绝有效 `symmetry 1`，不修改参数值的承诺仅属于此 GPU EXX 检查；补充 MD 会在检查前将 symmetry 重置为 0 的例子。无需改变代码、测试或增加 INPUT 参数，也无需治理例外。

验证：`git diff --check` 返回 0；源码树状态仅 `M docs/advanced/install.md`，HEAD 仍为 `f2667c6eed30e661a36bfb0ae1844802c99f171e`，未提交或推送。按任务要求，纯文案修改不重跑测试，原基准可执行文件的 f2667c6 来源记录保持不变。本次精确源码 diff 如下：

```diff
diff --git a/docs/advanced/install.md b/docs/advanced/install.md
index e89347535..00b45d514 100644
--- a/docs/advanced/install.md
+++ b/docs/advanced/install.md
@@ -87,11 +87,13 @@ build of DDLA. Like other dependent
 options, GPU RI is disabled when its LibRI/CUDA prerequisites are disabled.
 INPUT `device_exx` defaults to `cpu`, retaining CPU contractions even with
 `device gpu`. To use GPU contractions, set both `device gpu` and `device_exx gpu`.
-The latter requires GPU RI to be compiled in. GPU RI temporarily rejects
-`symmetry 1`, regardless of `exx_symmetry_realspace`, pending a validated LibRI
-GPU symmetry fix. Use `symmetry 0` (time reversal only) or `symmetry -1` (no
-symmetry), or select CPU RI when symmetry is needed. The INPUT checker reports
-an error instead of changing the requested settings.
+The latter requires GPU RI to be compiled in. After normal INPUT processing,
+GPU RI temporarily rejects an effective `symmetry 1`, regardless of
+`exx_symmetry_realspace`, pending a validated LibRI GPU symmetry fix. This GPU
+EXX check reports an error without modifying parameter values itself. Existing
+INPUT resets still apply; for example, `calculation md` sets `symmetry` to `0`
+before this check. Use `symmetry 0` (time reversal only) or `symmetry -1` (no
+symmetry), or select CPU RI when spatial symmetry is needed.
 
 The selector applies to the LCAO Kohn-Sham exchange engine. Independent LR and
 RDMFT exchange engines retain CPU contractions; LR inherits the selected backend
```
