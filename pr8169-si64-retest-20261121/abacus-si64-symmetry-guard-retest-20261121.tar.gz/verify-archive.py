#!/usr/bin/env python3
"""Verify the delivered archive and safely unpack regular files into this task."""
import hashlib
import json
from pathlib import Path,PurePosixPath
import sys
import tarfile

root=Path(__file__).resolve().parent
receipt=json.loads((root/'archive-receipt.json').read_text())
archive=root/receipt['archive']
if not archive.exists() and archive.with_name(archive.name+'.part').exists():
    archive=archive.with_name(archive.name+'.part')
actual=hashlib.sha256(archive.read_bytes()).hexdigest()
assert actual==receipt['sha256'] and archive.stat().st_size==receipt['bytes']
with tarfile.open(archive,'r:gz') as inp:
    members=inp.getmembers();names=[m.name for m in members]
    assert len(names)==len(set(names))==receipt['files']
    assert not any(Path(n).name.startswith('PR_BODY') or Path(n).name.lower().startswith('pr-body')
                   or Path(n).name.endswith('-task.md') for n in names)
    manifest_bytes=inp.extractfile('raw-file-manifest.json').read()
    assert hashlib.sha256(manifest_bytes).hexdigest()==receipt['manifest_sha256']
    manifest=json.loads(manifest_bytes)
    expected={item['path']:item for item in manifest['files']}
    assert 'raw-file-manifest.json' not in expected
    assert set(names)==set(expected)|{'raw-file-manifest.json'}
    for member in members:
        path=PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        dest=root/member.name
        assert dest.resolve().is_relative_to(root)
        data=inp.extractfile(member).read()
        if member.name in expected:
            assert hashlib.sha256(data).hexdigest()==expected[member.name]['sha256']
            assert len(data)==expected[member.name]['bytes']
        if '--extract' in sys.argv:
            # This file belongs to the independent reviewer. Verify it without editing.
            if member.name=='code-review.md' and dest.exists():
                assert hashlib.sha256(dest.read_bytes()).digest()==hashlib.sha256(data).digest()
                continue
            inp.extract(member,path=root,filter='data')
if archive.name.endswith('.part'):
    archive.rename(root/receipt['archive'])
result=dict(passed=True,archive=receipt['archive'],sha256=actual,files=len(members),
            payload_hashes_checked=len(expected),manifest_self_reference=False,
            coordinator_drafts_excluded=True,reviewer_file_unchanged=True)
(root/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
